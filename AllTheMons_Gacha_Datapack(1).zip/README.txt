ALL THE MONS - COBBLEMON GACHA DATAPACK
Minecraft: Java 1.21.1 / AllTheMons

INSTALL:
1. Put this ZIP into your world/server world/datapacks folder.
2. Run /reload.
3. Run /function gacha:admin/setup as an admin.
4. Place the Lodestone anywhere players can access it.
5. Admins can run /function gacha:admin/give_10 to receive 10 tickets.

PLAYER USE:
Right-click the Lodestone while holding a Gacha Ticket. No OP is required.

RARITIES:
Common 60%, Uncommon 25%, Rare 10%, Ultra Rare 4%, Legendary 1%.
Shiny is an independent 1% bonus roll, so a shiny can occur at any rarity.
PITY:
10 pulls: Rare+ guaranteed. 50 pulls: Ultra+ guaranteed. 100 pulls: Legendary guaranteed.
The pity counter resets after a Legendary/Mythical reward.

NOTES:
This pack targets the AllTheMons 1.21.1/Cobblemon environment. It includes all 1,025 National Dex species as the species pool, with rarity assignments designed for a gacha rather than official Cobblemon spawn rarity.

COMMANDS:
/function gacha:admin/setup
/function gacha:admin/give_10
/function gacha:admin/reset
