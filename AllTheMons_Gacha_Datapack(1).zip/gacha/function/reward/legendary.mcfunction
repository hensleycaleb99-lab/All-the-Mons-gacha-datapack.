scoreboard players set @s gacha_pick 0
execute store result score @s gacha_pick run random roll 1..94
execute if score @s gacha_pick matches 1 if score @s gacha_shiny matches 1 run givepokemon @s articuno shiny
execute if score @s gacha_pick matches 1 unless score @s gacha_shiny matches 1 run givepokemon @s articuno
execute if score @s gacha_pick matches 2 if score @s gacha_shiny matches 1 run givepokemon @s zapdos shiny
execute if score @s gacha_pick matches 2 unless score @s gacha_shiny matches 1 run givepokemon @s zapdos
execute if score @s gacha_pick matches 3 if score @s gacha_shiny matches 1 run givepokemon @s moltres shiny
execute if score @s gacha_pick matches 3 unless score @s gacha_shiny matches 1 run givepokemon @s moltres
execute if score @s gacha_pick matches 4 if score @s gacha_shiny matches 1 run givepokemon @s mewtwo shiny
execute if score @s gacha_pick matches 4 unless score @s gacha_shiny matches 1 run givepokemon @s mewtwo
execute if score @s gacha_pick matches 5 if score @s gacha_shiny matches 1 run givepokemon @s mew shiny
execute if score @s gacha_pick matches 5 unless score @s gacha_shiny matches 1 run givepokemon @s mew
execute if score @s gacha_pick matches 6 if score @s gacha_shiny matches 1 run givepokemon @s raikou shiny
execute if score @s gacha_pick matches 6 unless score @s gacha_shiny matches 1 run givepokemon @s raikou
execute if score @s gacha_pick matches 7 if score @s gacha_shiny matches 1 run givepokemon @s entei shiny
execute if score @s gacha_pick matches 7 unless score @s gacha_shiny matches 1 run givepokemon @s entei
execute if score @s gacha_pick matches 8 if score @s gacha_shiny matches 1 run givepokemon @s suicune shiny
execute if score @s gacha_pick matches 8 unless score @s gacha_shiny matches 1 run givepokemon @s suicune
execute if score @s gacha_pick matches 9 if score @s gacha_shiny matches 1 run givepokemon @s lugia shiny
execute if score @s gacha_pick matches 9 unless score @s gacha_shiny matches 1 run givepokemon @s lugia
execute if score @s gacha_pick matches 10 if score @s gacha_shiny matches 1 run givepokemon @s hooh shiny
execute if score @s gacha_pick matches 10 unless score @s gacha_shiny matches 1 run givepokemon @s hooh
execute if score @s gacha_pick matches 11 if score @s gacha_shiny matches 1 run givepokemon @s celebi shiny
execute if score @s gacha_pick matches 11 unless score @s gacha_shiny matches 1 run givepokemon @s celebi
execute if score @s gacha_pick matches 12 if score @s gacha_shiny matches 1 run givepokemon @s regirock shiny
execute if score @s gacha_pick matches 12 unless score @s gacha_shiny matches 1 run givepokemon @s regirock
execute if score @s gacha_pick matches 13 if score @s gacha_shiny matches 1 run givepokemon @s regice shiny
execute if score @s gacha_pick matches 13 unless score @s gacha_shiny matches 1 run givepokemon @s regice
execute if score @s gacha_pick matches 14 if score @s gacha_shiny matches 1 run givepokemon @s registeel shiny
execute if score @s gacha_pick matches 14 unless score @s gacha_shiny matches 1 run givepokemon @s registeel
execute if score @s gacha_pick matches 15 if score @s gacha_shiny matches 1 run givepokemon @s latias shiny
execute if score @s gacha_pick matches 15 unless score @s gacha_shiny matches 1 run givepokemon @s latias
execute if score @s gacha_pick matches 16 if score @s gacha_shiny matches 1 run givepokemon @s latios shiny
execute if score @s gacha_pick matches 16 unless score @s gacha_shiny matches 1 run givepokemon @s latios
execute if score @s gacha_pick matches 17 if score @s gacha_shiny matches 1 run givepokemon @s kyogre shiny
execute if score @s gacha_pick matches 17 unless score @s gacha_shiny matches 1 run givepokemon @s kyogre
execute if score @s gacha_pick matches 18 if score @s gacha_shiny matches 1 run givepokemon @s groudon shiny
execute if score @s gacha_pick matches 18 unless score @s gacha_shiny matches 1 run givepokemon @s groudon
execute if score @s gacha_pick matches 19 if score @s gacha_shiny matches 1 run givepokemon @s rayquaza shiny
execute if score @s gacha_pick matches 19 unless score @s gacha_shiny matches 1 run givepokemon @s rayquaza
execute if score @s gacha_pick matches 20 if score @s gacha_shiny matches 1 run givepokemon @s jirachi shiny
execute if score @s gacha_pick matches 20 unless score @s gacha_shiny matches 1 run givepokemon @s jirachi
execute if score @s gacha_pick matches 21 if score @s gacha_shiny matches 1 run givepokemon @s deoxys shiny
execute if score @s gacha_pick matches 21 unless score @s gacha_shiny matches 1 run givepokemon @s deoxys
execute if score @s gacha_pick matches 22 if score @s gacha_shiny matches 1 run givepokemon @s uxie shiny
execute if score @s gacha_pick matches 22 unless score @s gacha_shiny matches 1 run givepokemon @s uxie
execute if score @s gacha_pick matches 23 if score @s gacha_shiny matches 1 run givepokemon @s mesprit shiny
execute if score @s gacha_pick matches 23 unless score @s gacha_shiny matches 1 run givepokemon @s mesprit
execute if score @s gacha_pick matches 24 if score @s gacha_shiny matches 1 run givepokemon @s azelf shiny
execute if score @s gacha_pick matches 24 unless score @s gacha_shiny matches 1 run givepokemon @s azelf
execute if score @s gacha_pick matches 25 if score @s gacha_shiny matches 1 run givepokemon @s dialga shiny
execute if score @s gacha_pick matches 25 unless score @s gacha_shiny matches 1 run givepokemon @s dialga
execute if score @s gacha_pick matches 26 if score @s gacha_shiny matches 1 run givepokemon @s palkia shiny
execute if score @s gacha_pick matches 26 unless score @s gacha_shiny matches 1 run givepokemon @s palkia
execute if score @s gacha_pick matches 27 if score @s gacha_shiny matches 1 run givepokemon @s heatran shiny
execute if score @s gacha_pick matches 27 unless score @s gacha_shiny matches 1 run givepokemon @s heatran
execute if score @s gacha_pick matches 28 if score @s gacha_shiny matches 1 run givepokemon @s regigigas shiny
execute if score @s gacha_pick matches 28 unless score @s gacha_shiny matches 1 run givepokemon @s regigigas
execute if score @s gacha_pick matches 29 if score @s gacha_shiny matches 1 run givepokemon @s giratina shiny
execute if score @s gacha_pick matches 29 unless score @s gacha_shiny matches 1 run givepokemon @s giratina
execute if score @s gacha_pick matches 30 if score @s gacha_shiny matches 1 run givepokemon @s cresselia shiny
execute if score @s gacha_pick matches 30 unless score @s gacha_shiny matches 1 run givepokemon @s cresselia
execute if score @s gacha_pick matches 31 if score @s gacha_shiny matches 1 run givepokemon @s phione shiny
execute if score @s gacha_pick matches 31 unless score @s gacha_shiny matches 1 run givepokemon @s phione
execute if score @s gacha_pick matches 32 if score @s gacha_shiny matches 1 run givepokemon @s manaphy shiny
execute if score @s gacha_pick matches 32 unless score @s gacha_shiny matches 1 run givepokemon @s manaphy
execute if score @s gacha_pick matches 33 if score @s gacha_shiny matches 1 run givepokemon @s darkrai shiny
execute if score @s gacha_pick matches 33 unless score @s gacha_shiny matches 1 run givepokemon @s darkrai
execute if score @s gacha_pick matches 34 if score @s gacha_shiny matches 1 run givepokemon @s shaymin shiny
execute if score @s gacha_pick matches 34 unless score @s gacha_shiny matches 1 run givepokemon @s shaymin
execute if score @s gacha_pick matches 35 if score @s gacha_shiny matches 1 run givepokemon @s arceus shiny
execute if score @s gacha_pick matches 35 unless score @s gacha_shiny matches 1 run givepokemon @s arceus
execute if score @s gacha_pick matches 36 if score @s gacha_shiny matches 1 run givepokemon @s victini shiny
execute if score @s gacha_pick matches 36 unless score @s gacha_shiny matches 1 run givepokemon @s victini
execute if score @s gacha_pick matches 37 if score @s gacha_shiny matches 1 run givepokemon @s cobalion shiny
execute if score @s gacha_pick matches 37 unless score @s gacha_shiny matches 1 run givepokemon @s cobalion
execute if score @s gacha_pick matches 38 if score @s gacha_shiny matches 1 run givepokemon @s terrakion shiny
execute if score @s gacha_pick matches 38 unless score @s gacha_shiny matches 1 run givepokemon @s terrakion
execute if score @s gacha_pick matches 39 if score @s gacha_shiny matches 1 run givepokemon @s virizion shiny
execute if score @s gacha_pick matches 39 unless score @s gacha_shiny matches 1 run givepokemon @s virizion
execute if score @s gacha_pick matches 40 if score @s gacha_shiny matches 1 run givepokemon @s tornadus shiny
execute if score @s gacha_pick matches 40 unless score @s gacha_shiny matches 1 run givepokemon @s tornadus
execute if score @s gacha_pick matches 41 if score @s gacha_shiny matches 1 run givepokemon @s thundurus shiny
execute if score @s gacha_pick matches 41 unless score @s gacha_shiny matches 1 run givepokemon @s thundurus
execute if score @s gacha_pick matches 42 if score @s gacha_shiny matches 1 run givepokemon @s reshiram shiny
execute if score @s gacha_pick matches 42 unless score @s gacha_shiny matches 1 run givepokemon @s reshiram
execute if score @s gacha_pick matches 43 if score @s gacha_shiny matches 1 run givepokemon @s zekrom shiny
execute if score @s gacha_pick matches 43 unless score @s gacha_shiny matches 1 run givepokemon @s zekrom
execute if score @s gacha_pick matches 44 if score @s gacha_shiny matches 1 run givepokemon @s landorus shiny
execute if score @s gacha_pick matches 44 unless score @s gacha_shiny matches 1 run givepokemon @s landorus
execute if score @s gacha_pick matches 45 if score @s gacha_shiny matches 1 run givepokemon @s kyurem shiny
execute if score @s gacha_pick matches 45 unless score @s gacha_shiny matches 1 run givepokemon @s kyurem
execute if score @s gacha_pick matches 46 if score @s gacha_shiny matches 1 run givepokemon @s keldeo shiny
execute if score @s gacha_pick matches 46 unless score @s gacha_shiny matches 1 run givepokemon @s keldeo
execute if score @s gacha_pick matches 47 if score @s gacha_shiny matches 1 run givepokemon @s meloetta shiny
execute if score @s gacha_pick matches 47 unless score @s gacha_shiny matches 1 run givepokemon @s meloetta
execute if score @s gacha_pick matches 48 if score @s gacha_shiny matches 1 run givepokemon @s genesect shiny
execute if score @s gacha_pick matches 48 unless score @s gacha_shiny matches 1 run givepokemon @s genesect
execute if score @s gacha_pick matches 49 if score @s gacha_shiny matches 1 run givepokemon @s xerneas shiny
execute if score @s gacha_pick matches 49 unless score @s gacha_shiny matches 1 run givepokemon @s xerneas
execute if score @s gacha_pick matches 50 if score @s gacha_shiny matches 1 run givepokemon @s yveltal shiny
execute if score @s gacha_pick matches 50 unless score @s gacha_shiny matches 1 run givepokemon @s yveltal
execute if score @s gacha_pick matches 51 if score @s gacha_shiny matches 1 run givepokemon @s zygarde shiny
execute if score @s gacha_pick matches 51 unless score @s gacha_shiny matches 1 run givepokemon @s zygarde
execute if score @s gacha_pick matches 52 if score @s gacha_shiny matches 1 run givepokemon @s diancie shiny
execute if score @s gacha_pick matches 52 unless score @s gacha_shiny matches 1 run givepokemon @s diancie
execute if score @s gacha_pick matches 53 if score @s gacha_shiny matches 1 run givepokemon @s hoopa shiny
execute if score @s gacha_pick matches 53 unless score @s gacha_shiny matches 1 run givepokemon @s hoopa
execute if score @s gacha_pick matches 54 if score @s gacha_shiny matches 1 run givepokemon @s volcanion shiny
execute if score @s gacha_pick matches 54 unless score @s gacha_shiny matches 1 run givepokemon @s volcanion
execute if score @s gacha_pick matches 55 if score @s gacha_shiny matches 1 run givepokemon @s typenull shiny
execute if score @s gacha_pick matches 55 unless score @s gacha_shiny matches 1 run givepokemon @s typenull
execute if score @s gacha_pick matches 56 if score @s gacha_shiny matches 1 run givepokemon @s silvally shiny
execute if score @s gacha_pick matches 56 unless score @s gacha_shiny matches 1 run givepokemon @s silvally
execute if score @s gacha_pick matches 57 if score @s gacha_shiny matches 1 run givepokemon @s tapukoko shiny
execute if score @s gacha_pick matches 57 unless score @s gacha_shiny matches 1 run givepokemon @s tapukoko
execute if score @s gacha_pick matches 58 if score @s gacha_shiny matches 1 run givepokemon @s tapulele shiny
execute if score @s gacha_pick matches 58 unless score @s gacha_shiny matches 1 run givepokemon @s tapulele
execute if score @s gacha_pick matches 59 if score @s gacha_shiny matches 1 run givepokemon @s tapubulu shiny
execute if score @s gacha_pick matches 59 unless score @s gacha_shiny matches 1 run givepokemon @s tapubulu
execute if score @s gacha_pick matches 60 if score @s gacha_shiny matches 1 run givepokemon @s tapufini shiny
execute if score @s gacha_pick matches 60 unless score @s gacha_shiny matches 1 run givepokemon @s tapufini
execute if score @s gacha_pick matches 61 if score @s gacha_shiny matches 1 run givepokemon @s cosmog shiny
execute if score @s gacha_pick matches 61 unless score @s gacha_shiny matches 1 run givepokemon @s cosmog
execute if score @s gacha_pick matches 62 if score @s gacha_shiny matches 1 run givepokemon @s cosmoem shiny
execute if score @s gacha_pick matches 62 unless score @s gacha_shiny matches 1 run givepokemon @s cosmoem
execute if score @s gacha_pick matches 63 if score @s gacha_shiny matches 1 run givepokemon @s solgaleo shiny
execute if score @s gacha_pick matches 63 unless score @s gacha_shiny matches 1 run givepokemon @s solgaleo
execute if score @s gacha_pick matches 64 if score @s gacha_shiny matches 1 run givepokemon @s lunala shiny
execute if score @s gacha_pick matches 64 unless score @s gacha_shiny matches 1 run givepokemon @s lunala
execute if score @s gacha_pick matches 65 if score @s gacha_shiny matches 1 run givepokemon @s necrozma shiny
execute if score @s gacha_pick matches 65 unless score @s gacha_shiny matches 1 run givepokemon @s necrozma
execute if score @s gacha_pick matches 66 if score @s gacha_shiny matches 1 run givepokemon @s magearna shiny
execute if score @s gacha_pick matches 66 unless score @s gacha_shiny matches 1 run givepokemon @s magearna
execute if score @s gacha_pick matches 67 if score @s gacha_shiny matches 1 run givepokemon @s marshadow shiny
execute if score @s gacha_pick matches 67 unless score @s gacha_shiny matches 1 run givepokemon @s marshadow
execute if score @s gacha_pick matches 68 if score @s gacha_shiny matches 1 run givepokemon @s zeraora shiny
execute if score @s gacha_pick matches 68 unless score @s gacha_shiny matches 1 run givepokemon @s zeraora
execute if score @s gacha_pick matches 69 if score @s gacha_shiny matches 1 run givepokemon @s meltan shiny
execute if score @s gacha_pick matches 69 unless score @s gacha_shiny matches 1 run givepokemon @s meltan
execute if score @s gacha_pick matches 70 if score @s gacha_shiny matches 1 run givepokemon @s melmetal shiny
execute if score @s gacha_pick matches 70 unless score @s gacha_shiny matches 1 run givepokemon @s melmetal
execute if score @s gacha_pick matches 71 if score @s gacha_shiny matches 1 run givepokemon @s zacian shiny
execute if score @s gacha_pick matches 71 unless score @s gacha_shiny matches 1 run givepokemon @s zacian
execute if score @s gacha_pick matches 72 if score @s gacha_shiny matches 1 run givepokemon @s zamazenta shiny
execute if score @s gacha_pick matches 72 unless score @s gacha_shiny matches 1 run givepokemon @s zamazenta
execute if score @s gacha_pick matches 73 if score @s gacha_shiny matches 1 run givepokemon @s eternatus shiny
execute if score @s gacha_pick matches 73 unless score @s gacha_shiny matches 1 run givepokemon @s eternatus
execute if score @s gacha_pick matches 74 if score @s gacha_shiny matches 1 run givepokemon @s kubfu shiny
execute if score @s gacha_pick matches 74 unless score @s gacha_shiny matches 1 run givepokemon @s kubfu
execute if score @s gacha_pick matches 75 if score @s gacha_shiny matches 1 run givepokemon @s urshifu shiny
execute if score @s gacha_pick matches 75 unless score @s gacha_shiny matches 1 run givepokemon @s urshifu
execute if score @s gacha_pick matches 76 if score @s gacha_shiny matches 1 run givepokemon @s zarude shiny
execute if score @s gacha_pick matches 76 unless score @s gacha_shiny matches 1 run givepokemon @s zarude
execute if score @s gacha_pick matches 77 if score @s gacha_shiny matches 1 run givepokemon @s regieleki shiny
execute if score @s gacha_pick matches 77 unless score @s gacha_shiny matches 1 run givepokemon @s regieleki
execute if score @s gacha_pick matches 78 if score @s gacha_shiny matches 1 run givepokemon @s regidrago shiny
execute if score @s gacha_pick matches 78 unless score @s gacha_shiny matches 1 run givepokemon @s regidrago
execute if score @s gacha_pick matches 79 if score @s gacha_shiny matches 1 run givepokemon @s glastrier shiny
execute if score @s gacha_pick matches 79 unless score @s gacha_shiny matches 1 run givepokemon @s glastrier
execute if score @s gacha_pick matches 80 if score @s gacha_shiny matches 1 run givepokemon @s spectrier shiny
execute if score @s gacha_pick matches 80 unless score @s gacha_shiny matches 1 run givepokemon @s spectrier
execute if score @s gacha_pick matches 81 if score @s gacha_shiny matches 1 run givepokemon @s calyrex shiny
execute if score @s gacha_pick matches 81 unless score @s gacha_shiny matches 1 run givepokemon @s calyrex
execute if score @s gacha_pick matches 82 if score @s gacha_shiny matches 1 run givepokemon @s enamorus shiny
execute if score @s gacha_pick matches 82 unless score @s gacha_shiny matches 1 run givepokemon @s enamorus
execute if score @s gacha_pick matches 83 if score @s gacha_shiny matches 1 run givepokemon @s wo-chien shiny
execute if score @s gacha_pick matches 83 unless score @s gacha_shiny matches 1 run givepokemon @s wo-chien
execute if score @s gacha_pick matches 84 if score @s gacha_shiny matches 1 run givepokemon @s chien-pao shiny
execute if score @s gacha_pick matches 84 unless score @s gacha_shiny matches 1 run givepokemon @s chien-pao
execute if score @s gacha_pick matches 85 if score @s gacha_shiny matches 1 run givepokemon @s ting-lu shiny
execute if score @s gacha_pick matches 85 unless score @s gacha_shiny matches 1 run givepokemon @s ting-lu
execute if score @s gacha_pick matches 86 if score @s gacha_shiny matches 1 run givepokemon @s chi-yu shiny
execute if score @s gacha_pick matches 86 unless score @s gacha_shiny matches 1 run givepokemon @s chi-yu
execute if score @s gacha_pick matches 87 if score @s gacha_shiny matches 1 run givepokemon @s koraidon shiny
execute if score @s gacha_pick matches 87 unless score @s gacha_shiny matches 1 run givepokemon @s koraidon
execute if score @s gacha_pick matches 88 if score @s gacha_shiny matches 1 run givepokemon @s miraidon shiny
execute if score @s gacha_pick matches 88 unless score @s gacha_shiny matches 1 run givepokemon @s miraidon
execute if score @s gacha_pick matches 89 if score @s gacha_shiny matches 1 run givepokemon @s okidogi shiny
execute if score @s gacha_pick matches 89 unless score @s gacha_shiny matches 1 run givepokemon @s okidogi
execute if score @s gacha_pick matches 90 if score @s gacha_shiny matches 1 run givepokemon @s munkidori shiny
execute if score @s gacha_pick matches 90 unless score @s gacha_shiny matches 1 run givepokemon @s munkidori
execute if score @s gacha_pick matches 91 if score @s gacha_shiny matches 1 run givepokemon @s fezandipiti shiny
execute if score @s gacha_pick matches 91 unless score @s gacha_shiny matches 1 run givepokemon @s fezandipiti
execute if score @s gacha_pick matches 92 if score @s gacha_shiny matches 1 run givepokemon @s ogerpon shiny
execute if score @s gacha_pick matches 92 unless score @s gacha_shiny matches 1 run givepokemon @s ogerpon
execute if score @s gacha_pick matches 93 if score @s gacha_shiny matches 1 run givepokemon @s terapagos shiny
execute if score @s gacha_pick matches 93 unless score @s gacha_shiny matches 1 run givepokemon @s terapagos
execute if score @s gacha_pick matches 94 if score @s gacha_shiny matches 1 run givepokemon @s pecharunt shiny
execute if score @s gacha_pick matches 94 unless score @s gacha_shiny matches 1 run givepokemon @s pecharunt
tellraw @s {"text":"🎁 LEGENDARY reward!","color":"white"}
