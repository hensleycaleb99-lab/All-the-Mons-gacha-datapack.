scoreboard players set @s gacha_pick 0
execute store result score @s gacha_pick run random roll 1..376
execute if score @s gacha_pick matches 1 if score @s gacha_shiny matches 1 run givepokemon @s charmander shiny
execute if score @s gacha_pick matches 1 unless score @s gacha_shiny matches 1 run givepokemon @s charmander
execute if score @s gacha_pick matches 2 if score @s gacha_shiny matches 1 run givepokemon @s charmeleon shiny
execute if score @s gacha_pick matches 2 unless score @s gacha_shiny matches 1 run givepokemon @s charmeleon
execute if score @s gacha_pick matches 3 if score @s gacha_shiny matches 1 run givepokemon @s squirtle shiny
execute if score @s gacha_pick matches 3 unless score @s gacha_shiny matches 1 run givepokemon @s squirtle
execute if score @s gacha_pick matches 4 if score @s gacha_shiny matches 1 run givepokemon @s caterpie shiny
execute if score @s gacha_pick matches 4 unless score @s gacha_shiny matches 1 run givepokemon @s caterpie
execute if score @s gacha_pick matches 5 if score @s gacha_shiny matches 1 run givepokemon @s metapod shiny
execute if score @s gacha_pick matches 5 unless score @s gacha_shiny matches 1 run givepokemon @s metapod
execute if score @s gacha_pick matches 6 if score @s gacha_shiny matches 1 run givepokemon @s kakuna shiny
execute if score @s gacha_pick matches 6 unless score @s gacha_shiny matches 1 run givepokemon @s kakuna
execute if score @s gacha_pick matches 7 if score @s gacha_shiny matches 1 run givepokemon @s spearow shiny
execute if score @s gacha_pick matches 7 unless score @s gacha_shiny matches 1 run givepokemon @s spearow
execute if score @s gacha_pick matches 8 if score @s gacha_shiny matches 1 run givepokemon @s ekans shiny
execute if score @s gacha_pick matches 8 unless score @s gacha_shiny matches 1 run givepokemon @s ekans
execute if score @s gacha_pick matches 9 if score @s gacha_shiny matches 1 run givepokemon @s nidoranm shiny
execute if score @s gacha_pick matches 9 unless score @s gacha_shiny matches 1 run givepokemon @s nidoranm
execute if score @s gacha_pick matches 10 if score @s gacha_shiny matches 1 run givepokemon @s nidorino shiny
execute if score @s gacha_pick matches 10 unless score @s gacha_shiny matches 1 run givepokemon @s nidorino
execute if score @s gacha_pick matches 11 if score @s gacha_shiny matches 1 run givepokemon @s clefairy shiny
execute if score @s gacha_pick matches 11 unless score @s gacha_shiny matches 1 run givepokemon @s clefairy
execute if score @s gacha_pick matches 12 if score @s gacha_shiny matches 1 run givepokemon @s vulpix shiny
execute if score @s gacha_pick matches 12 unless score @s gacha_shiny matches 1 run givepokemon @s vulpix
execute if score @s gacha_pick matches 13 if score @s gacha_shiny matches 1 run givepokemon @s jigglypuff shiny
execute if score @s gacha_pick matches 13 unless score @s gacha_shiny matches 1 run givepokemon @s jigglypuff
execute if score @s gacha_pick matches 14 if score @s gacha_shiny matches 1 run givepokemon @s zubat shiny
execute if score @s gacha_pick matches 14 unless score @s gacha_shiny matches 1 run givepokemon @s zubat
execute if score @s gacha_pick matches 15 if score @s gacha_shiny matches 1 run givepokemon @s oddish shiny
execute if score @s gacha_pick matches 15 unless score @s gacha_shiny matches 1 run givepokemon @s oddish
execute if score @s gacha_pick matches 16 if score @s gacha_shiny matches 1 run givepokemon @s gloom shiny
execute if score @s gacha_pick matches 16 unless score @s gacha_shiny matches 1 run givepokemon @s gloom
execute if score @s gacha_pick matches 17 if score @s gacha_shiny matches 1 run givepokemon @s paras shiny
execute if score @s gacha_pick matches 17 unless score @s gacha_shiny matches 1 run givepokemon @s paras
execute if score @s gacha_pick matches 18 if score @s gacha_shiny matches 1 run givepokemon @s venonat shiny
execute if score @s gacha_pick matches 18 unless score @s gacha_shiny matches 1 run givepokemon @s venonat
execute if score @s gacha_pick matches 19 if score @s gacha_shiny matches 1 run givepokemon @s diglett shiny
execute if score @s gacha_pick matches 19 unless score @s gacha_shiny matches 1 run givepokemon @s diglett
execute if score @s gacha_pick matches 20 if score @s gacha_shiny matches 1 run givepokemon @s poliwag shiny
execute if score @s gacha_pick matches 20 unless score @s gacha_shiny matches 1 run givepokemon @s poliwag
execute if score @s gacha_pick matches 21 if score @s gacha_shiny matches 1 run givepokemon @s poliwhirl shiny
execute if score @s gacha_pick matches 21 unless score @s gacha_shiny matches 1 run givepokemon @s poliwhirl
execute if score @s gacha_pick matches 22 if score @s gacha_shiny matches 1 run givepokemon @s abra shiny
execute if score @s gacha_pick matches 22 unless score @s gacha_shiny matches 1 run givepokemon @s abra
execute if score @s gacha_pick matches 23 if score @s gacha_shiny matches 1 run givepokemon @s kadabra shiny
execute if score @s gacha_pick matches 23 unless score @s gacha_shiny matches 1 run givepokemon @s kadabra
execute if score @s gacha_pick matches 24 if score @s gacha_shiny matches 1 run givepokemon @s machop shiny
execute if score @s gacha_pick matches 24 unless score @s gacha_shiny matches 1 run givepokemon @s machop
execute if score @s gacha_pick matches 25 if score @s gacha_shiny matches 1 run givepokemon @s machoke shiny
execute if score @s gacha_pick matches 25 unless score @s gacha_shiny matches 1 run givepokemon @s machoke
execute if score @s gacha_pick matches 26 if score @s gacha_shiny matches 1 run givepokemon @s bellsprout shiny
execute if score @s gacha_pick matches 26 unless score @s gacha_shiny matches 1 run givepokemon @s bellsprout
execute if score @s gacha_pick matches 27 if score @s gacha_shiny matches 1 run givepokemon @s weepinbell shiny
execute if score @s gacha_pick matches 27 unless score @s gacha_shiny matches 1 run givepokemon @s weepinbell
execute if score @s gacha_pick matches 28 if score @s gacha_shiny matches 1 run givepokemon @s geodude shiny
execute if score @s gacha_pick matches 28 unless score @s gacha_shiny matches 1 run givepokemon @s geodude
execute if score @s gacha_pick matches 29 if score @s gacha_shiny matches 1 run givepokemon @s graveler shiny
execute if score @s gacha_pick matches 29 unless score @s gacha_shiny matches 1 run givepokemon @s graveler
execute if score @s gacha_pick matches 30 if score @s gacha_shiny matches 1 run givepokemon @s ponyta shiny
execute if score @s gacha_pick matches 30 unless score @s gacha_shiny matches 1 run givepokemon @s ponyta
execute if score @s gacha_pick matches 31 if score @s gacha_shiny matches 1 run givepokemon @s slowpoke shiny
execute if score @s gacha_pick matches 31 unless score @s gacha_shiny matches 1 run givepokemon @s slowpoke
execute if score @s gacha_pick matches 32 if score @s gacha_shiny matches 1 run givepokemon @s farfetchd shiny
execute if score @s gacha_pick matches 32 unless score @s gacha_shiny matches 1 run givepokemon @s farfetchd
execute if score @s gacha_pick matches 33 if score @s gacha_shiny matches 1 run givepokemon @s doduo shiny
execute if score @s gacha_pick matches 33 unless score @s gacha_shiny matches 1 run givepokemon @s doduo
execute if score @s gacha_pick matches 34 if score @s gacha_shiny matches 1 run givepokemon @s seel shiny
execute if score @s gacha_pick matches 34 unless score @s gacha_shiny matches 1 run givepokemon @s seel
execute if score @s gacha_pick matches 35 if score @s gacha_shiny matches 1 run givepokemon @s grimer shiny
execute if score @s gacha_pick matches 35 unless score @s gacha_shiny matches 1 run givepokemon @s grimer
execute if score @s gacha_pick matches 36 if score @s gacha_shiny matches 1 run givepokemon @s shellder shiny
execute if score @s gacha_pick matches 36 unless score @s gacha_shiny matches 1 run givepokemon @s shellder
execute if score @s gacha_pick matches 37 if score @s gacha_shiny matches 1 run givepokemon @s onix shiny
execute if score @s gacha_pick matches 37 unless score @s gacha_shiny matches 1 run givepokemon @s onix
execute if score @s gacha_pick matches 38 if score @s gacha_shiny matches 1 run givepokemon @s krabby shiny
execute if score @s gacha_pick matches 38 unless score @s gacha_shiny matches 1 run givepokemon @s krabby
execute if score @s gacha_pick matches 39 if score @s gacha_shiny matches 1 run givepokemon @s voltorb shiny
execute if score @s gacha_pick matches 39 unless score @s gacha_shiny matches 1 run givepokemon @s voltorb
execute if score @s gacha_pick matches 40 if score @s gacha_shiny matches 1 run givepokemon @s exeggcute shiny
execute if score @s gacha_pick matches 40 unless score @s gacha_shiny matches 1 run givepokemon @s exeggcute
execute if score @s gacha_pick matches 41 if score @s gacha_shiny matches 1 run givepokemon @s hitmonlee shiny
execute if score @s gacha_pick matches 41 unless score @s gacha_shiny matches 1 run givepokemon @s hitmonlee
execute if score @s gacha_pick matches 42 if score @s gacha_shiny matches 1 run givepokemon @s lickitung shiny
execute if score @s gacha_pick matches 42 unless score @s gacha_shiny matches 1 run givepokemon @s lickitung
execute if score @s gacha_pick matches 43 if score @s gacha_shiny matches 1 run givepokemon @s koffing shiny
execute if score @s gacha_pick matches 43 unless score @s gacha_shiny matches 1 run givepokemon @s koffing
execute if score @s gacha_pick matches 44 if score @s gacha_shiny matches 1 run givepokemon @s rhyhorn shiny
execute if score @s gacha_pick matches 44 unless score @s gacha_shiny matches 1 run givepokemon @s rhyhorn
execute if score @s gacha_pick matches 45 if score @s gacha_shiny matches 1 run givepokemon @s goldeen shiny
execute if score @s gacha_pick matches 45 unless score @s gacha_shiny matches 1 run givepokemon @s goldeen
execute if score @s gacha_pick matches 46 if score @s gacha_shiny matches 1 run givepokemon @s staryu shiny
execute if score @s gacha_pick matches 46 unless score @s gacha_shiny matches 1 run givepokemon @s staryu
execute if score @s gacha_pick matches 47 if score @s gacha_shiny matches 1 run givepokemon @s mrmime shiny
execute if score @s gacha_pick matches 47 unless score @s gacha_shiny matches 1 run givepokemon @s mrmime
execute if score @s gacha_pick matches 48 if score @s gacha_shiny matches 1 run givepokemon @s scyther shiny
execute if score @s gacha_pick matches 48 unless score @s gacha_shiny matches 1 run givepokemon @s scyther
execute if score @s gacha_pick matches 49 if score @s gacha_shiny matches 1 run givepokemon @s jynx shiny
execute if score @s gacha_pick matches 49 unless score @s gacha_shiny matches 1 run givepokemon @s jynx
execute if score @s gacha_pick matches 50 if score @s gacha_shiny matches 1 run givepokemon @s electabuzz shiny
execute if score @s gacha_pick matches 50 unless score @s gacha_shiny matches 1 run givepokemon @s electabuzz
execute if score @s gacha_pick matches 51 if score @s gacha_shiny matches 1 run givepokemon @s magmar shiny
execute if score @s gacha_pick matches 51 unless score @s gacha_shiny matches 1 run givepokemon @s magmar
execute if score @s gacha_pick matches 52 if score @s gacha_shiny matches 1 run givepokemon @s pinsir shiny
execute if score @s gacha_pick matches 52 unless score @s gacha_shiny matches 1 run givepokemon @s pinsir
execute if score @s gacha_pick matches 53 if score @s gacha_shiny matches 1 run givepokemon @s tauros shiny
execute if score @s gacha_pick matches 53 unless score @s gacha_shiny matches 1 run givepokemon @s tauros
execute if score @s gacha_pick matches 54 if score @s gacha_shiny matches 1 run givepokemon @s magikarp shiny
execute if score @s gacha_pick matches 54 unless score @s gacha_shiny matches 1 run givepokemon @s magikarp
execute if score @s gacha_pick matches 55 if score @s gacha_shiny matches 1 run givepokemon @s ditto shiny
execute if score @s gacha_pick matches 55 unless score @s gacha_shiny matches 1 run givepokemon @s ditto
execute if score @s gacha_pick matches 56 if score @s gacha_shiny matches 1 run givepokemon @s vaporeon shiny
execute if score @s gacha_pick matches 56 unless score @s gacha_shiny matches 1 run givepokemon @s vaporeon
execute if score @s gacha_pick matches 57 if score @s gacha_shiny matches 1 run givepokemon @s jolteon shiny
execute if score @s gacha_pick matches 57 unless score @s gacha_shiny matches 1 run givepokemon @s jolteon
execute if score @s gacha_pick matches 58 if score @s gacha_shiny matches 1 run givepokemon @s flareon shiny
execute if score @s gacha_pick matches 58 unless score @s gacha_shiny matches 1 run givepokemon @s flareon
execute if score @s gacha_pick matches 59 if score @s gacha_shiny matches 1 run givepokemon @s porygon shiny
execute if score @s gacha_pick matches 59 unless score @s gacha_shiny matches 1 run givepokemon @s porygon
execute if score @s gacha_pick matches 60 if score @s gacha_shiny matches 1 run givepokemon @s kabuto shiny
execute if score @s gacha_pick matches 60 unless score @s gacha_shiny matches 1 run givepokemon @s kabuto
execute if score @s gacha_pick matches 61 if score @s gacha_shiny matches 1 run givepokemon @s aerodactyl shiny
execute if score @s gacha_pick matches 61 unless score @s gacha_shiny matches 1 run givepokemon @s aerodactyl
execute if score @s gacha_pick matches 62 if score @s gacha_shiny matches 1 run givepokemon @s chikorita shiny
execute if score @s gacha_pick matches 62 unless score @s gacha_shiny matches 1 run givepokemon @s chikorita
execute if score @s gacha_pick matches 63 if score @s gacha_shiny matches 1 run givepokemon @s bayleef shiny
execute if score @s gacha_pick matches 63 unless score @s gacha_shiny matches 1 run givepokemon @s bayleef
execute if score @s gacha_pick matches 64 if score @s gacha_shiny matches 1 run givepokemon @s cyndaquil shiny
execute if score @s gacha_pick matches 64 unless score @s gacha_shiny matches 1 run givepokemon @s cyndaquil
execute if score @s gacha_pick matches 65 if score @s gacha_shiny matches 1 run givepokemon @s quilava shiny
execute if score @s gacha_pick matches 65 unless score @s gacha_shiny matches 1 run givepokemon @s quilava
execute if score @s gacha_pick matches 66 if score @s gacha_shiny matches 1 run givepokemon @s totodile shiny
execute if score @s gacha_pick matches 66 unless score @s gacha_shiny matches 1 run givepokemon @s totodile
execute if score @s gacha_pick matches 67 if score @s gacha_shiny matches 1 run givepokemon @s croconaw shiny
execute if score @s gacha_pick matches 67 unless score @s gacha_shiny matches 1 run givepokemon @s croconaw
execute if score @s gacha_pick matches 68 if score @s gacha_shiny matches 1 run givepokemon @s sentret shiny
execute if score @s gacha_pick matches 68 unless score @s gacha_shiny matches 1 run givepokemon @s sentret
execute if score @s gacha_pick matches 69 if score @s gacha_shiny matches 1 run givepokemon @s furret shiny
execute if score @s gacha_pick matches 69 unless score @s gacha_shiny matches 1 run givepokemon @s furret
execute if score @s gacha_pick matches 70 if score @s gacha_shiny matches 1 run givepokemon @s hoothoot shiny
execute if score @s gacha_pick matches 70 unless score @s gacha_shiny matches 1 run givepokemon @s hoothoot
execute if score @s gacha_pick matches 71 if score @s gacha_shiny matches 1 run givepokemon @s ledyba shiny
execute if score @s gacha_pick matches 71 unless score @s gacha_shiny matches 1 run givepokemon @s ledyba
execute if score @s gacha_pick matches 72 if score @s gacha_shiny matches 1 run givepokemon @s spinarak shiny
execute if score @s gacha_pick matches 72 unless score @s gacha_shiny matches 1 run givepokemon @s spinarak
execute if score @s gacha_pick matches 73 if score @s gacha_shiny matches 1 run givepokemon @s crobat shiny
execute if score @s gacha_pick matches 73 unless score @s gacha_shiny matches 1 run givepokemon @s crobat
execute if score @s gacha_pick matches 74 if score @s gacha_shiny matches 1 run givepokemon @s igglybuff shiny
execute if score @s gacha_pick matches 74 unless score @s gacha_shiny matches 1 run givepokemon @s igglybuff
execute if score @s gacha_pick matches 75 if score @s gacha_shiny matches 1 run givepokemon @s natu shiny
execute if score @s gacha_pick matches 75 unless score @s gacha_shiny matches 1 run givepokemon @s natu
execute if score @s gacha_pick matches 76 if score @s gacha_shiny matches 1 run givepokemon @s mareep shiny
execute if score @s gacha_pick matches 76 unless score @s gacha_shiny matches 1 run givepokemon @s mareep
execute if score @s gacha_pick matches 77 if score @s gacha_shiny matches 1 run givepokemon @s marill shiny
execute if score @s gacha_pick matches 77 unless score @s gacha_shiny matches 1 run givepokemon @s marill
execute if score @s gacha_pick matches 78 if score @s gacha_shiny matches 1 run givepokemon @s sudowoodo shiny
execute if score @s gacha_pick matches 78 unless score @s gacha_shiny matches 1 run givepokemon @s sudowoodo
execute if score @s gacha_pick matches 79 if score @s gacha_shiny matches 1 run givepokemon @s hoppip shiny
execute if score @s gacha_pick matches 79 unless score @s gacha_shiny matches 1 run givepokemon @s hoppip
execute if score @s gacha_pick matches 80 if score @s gacha_shiny matches 1 run givepokemon @s skiploom shiny
execute if score @s gacha_pick matches 80 unless score @s gacha_shiny matches 1 run givepokemon @s skiploom
execute if score @s gacha_pick matches 81 if score @s gacha_shiny matches 1 run givepokemon @s wooper shiny
execute if score @s gacha_pick matches 81 unless score @s gacha_shiny matches 1 run givepokemon @s wooper
execute if score @s gacha_pick matches 82 if score @s gacha_shiny matches 1 run givepokemon @s misdreavus shiny
execute if score @s gacha_pick matches 82 unless score @s gacha_shiny matches 1 run givepokemon @s misdreavus
execute if score @s gacha_pick matches 83 if score @s gacha_shiny matches 1 run givepokemon @s wobbuffet shiny
execute if score @s gacha_pick matches 83 unless score @s gacha_shiny matches 1 run givepokemon @s wobbuffet
execute if score @s gacha_pick matches 84 if score @s gacha_shiny matches 1 run givepokemon @s girafarig shiny
execute if score @s gacha_pick matches 84 unless score @s gacha_shiny matches 1 run givepokemon @s girafarig
execute if score @s gacha_pick matches 85 if score @s gacha_shiny matches 1 run givepokemon @s pineco shiny
execute if score @s gacha_pick matches 85 unless score @s gacha_shiny matches 1 run givepokemon @s pineco
execute if score @s gacha_pick matches 86 if score @s gacha_shiny matches 1 run givepokemon @s dunsparce shiny
execute if score @s gacha_pick matches 86 unless score @s gacha_shiny matches 1 run givepokemon @s dunsparce
execute if score @s gacha_pick matches 87 if score @s gacha_shiny matches 1 run givepokemon @s snubbull shiny
execute if score @s gacha_pick matches 87 unless score @s gacha_shiny matches 1 run givepokemon @s snubbull
execute if score @s gacha_pick matches 88 if score @s gacha_shiny matches 1 run givepokemon @s teddiursa shiny
execute if score @s gacha_pick matches 88 unless score @s gacha_shiny matches 1 run givepokemon @s teddiursa
execute if score @s gacha_pick matches 89 if score @s gacha_shiny matches 1 run givepokemon @s slugma shiny
execute if score @s gacha_pick matches 89 unless score @s gacha_shiny matches 1 run givepokemon @s slugma
execute if score @s gacha_pick matches 90 if score @s gacha_shiny matches 1 run givepokemon @s swinub shiny
execute if score @s gacha_pick matches 90 unless score @s gacha_shiny matches 1 run givepokemon @s swinub
execute if score @s gacha_pick matches 91 if score @s gacha_shiny matches 1 run givepokemon @s corsola shiny
execute if score @s gacha_pick matches 91 unless score @s gacha_shiny matches 1 run givepokemon @s corsola
execute if score @s gacha_pick matches 92 if score @s gacha_shiny matches 1 run givepokemon @s remoraid shiny
execute if score @s gacha_pick matches 92 unless score @s gacha_shiny matches 1 run givepokemon @s remoraid
execute if score @s gacha_pick matches 93 if score @s gacha_shiny matches 1 run givepokemon @s mantine shiny
execute if score @s gacha_pick matches 93 unless score @s gacha_shiny matches 1 run givepokemon @s mantine
execute if score @s gacha_pick matches 94 if score @s gacha_shiny matches 1 run givepokemon @s houndour shiny
execute if score @s gacha_pick matches 94 unless score @s gacha_shiny matches 1 run givepokemon @s houndour
execute if score @s gacha_pick matches 95 if score @s gacha_shiny matches 1 run givepokemon @s phanpy shiny
execute if score @s gacha_pick matches 95 unless score @s gacha_shiny matches 1 run givepokemon @s phanpy
execute if score @s gacha_pick matches 96 if score @s gacha_shiny matches 1 run givepokemon @s porygon2 shiny
execute if score @s gacha_pick matches 96 unless score @s gacha_shiny matches 1 run givepokemon @s porygon2
execute if score @s gacha_pick matches 97 if score @s gacha_shiny matches 1 run givepokemon @s stantler shiny
execute if score @s gacha_pick matches 97 unless score @s gacha_shiny matches 1 run givepokemon @s stantler
execute if score @s gacha_pick matches 98 if score @s gacha_shiny matches 1 run givepokemon @s smeargle shiny
execute if score @s gacha_pick matches 98 unless score @s gacha_shiny matches 1 run givepokemon @s smeargle
execute if score @s gacha_pick matches 99 if score @s gacha_shiny matches 1 run givepokemon @s hitmontop shiny
execute if score @s gacha_pick matches 99 unless score @s gacha_shiny matches 1 run givepokemon @s hitmontop
execute if score @s gacha_pick matches 100 if score @s gacha_shiny matches 1 run givepokemon @s smoochum shiny
execute if score @s gacha_pick matches 100 unless score @s gacha_shiny matches 1 run givepokemon @s smoochum
execute if score @s gacha_pick matches 101 if score @s gacha_shiny matches 1 run givepokemon @s elekid shiny
execute if score @s gacha_pick matches 101 unless score @s gacha_shiny matches 1 run givepokemon @s elekid
execute if score @s gacha_pick matches 102 if score @s gacha_shiny matches 1 run givepokemon @s miltank shiny
execute if score @s gacha_pick matches 102 unless score @s gacha_shiny matches 1 run givepokemon @s miltank
execute if score @s gacha_pick matches 103 if score @s gacha_shiny matches 1 run givepokemon @s larvitar shiny
execute if score @s gacha_pick matches 103 unless score @s gacha_shiny matches 1 run givepokemon @s larvitar
execute if score @s gacha_pick matches 104 if score @s gacha_shiny matches 1 run givepokemon @s pupitar shiny
execute if score @s gacha_pick matches 104 unless score @s gacha_shiny matches 1 run givepokemon @s pupitar
execute if score @s gacha_pick matches 105 if score @s gacha_shiny matches 1 run givepokemon @s treecko shiny
execute if score @s gacha_pick matches 105 unless score @s gacha_shiny matches 1 run givepokemon @s treecko
execute if score @s gacha_pick matches 106 if score @s gacha_shiny matches 1 run givepokemon @s grovyle shiny
execute if score @s gacha_pick matches 106 unless score @s gacha_shiny matches 1 run givepokemon @s grovyle
execute if score @s gacha_pick matches 107 if score @s gacha_shiny matches 1 run givepokemon @s torchic shiny
execute if score @s gacha_pick matches 107 unless score @s gacha_shiny matches 1 run givepokemon @s torchic
execute if score @s gacha_pick matches 108 if score @s gacha_shiny matches 1 run givepokemon @s combusken shiny
execute if score @s gacha_pick matches 108 unless score @s gacha_shiny matches 1 run givepokemon @s combusken
execute if score @s gacha_pick matches 109 if score @s gacha_shiny matches 1 run givepokemon @s mudkip shiny
execute if score @s gacha_pick matches 109 unless score @s gacha_shiny matches 1 run givepokemon @s mudkip
execute if score @s gacha_pick matches 110 if score @s gacha_shiny matches 1 run givepokemon @s cascoon shiny
execute if score @s gacha_pick matches 110 unless score @s gacha_shiny matches 1 run givepokemon @s cascoon
execute if score @s gacha_pick matches 111 if score @s gacha_shiny matches 1 run givepokemon @s lotad shiny
execute if score @s gacha_pick matches 111 unless score @s gacha_shiny matches 1 run givepokemon @s lotad
execute if score @s gacha_pick matches 112 if score @s gacha_shiny matches 1 run givepokemon @s lombre shiny
execute if score @s gacha_pick matches 112 unless score @s gacha_shiny matches 1 run givepokemon @s lombre
execute if score @s gacha_pick matches 113 if score @s gacha_shiny matches 1 run givepokemon @s seedot shiny
execute if score @s gacha_pick matches 113 unless score @s gacha_shiny matches 1 run givepokemon @s seedot
execute if score @s gacha_pick matches 114 if score @s gacha_shiny matches 1 run givepokemon @s nuzleaf shiny
execute if score @s gacha_pick matches 114 unless score @s gacha_shiny matches 1 run givepokemon @s nuzleaf
execute if score @s gacha_pick matches 115 if score @s gacha_shiny matches 1 run givepokemon @s taillow shiny
execute if score @s gacha_pick matches 115 unless score @s gacha_shiny matches 1 run givepokemon @s taillow
execute if score @s gacha_pick matches 116 if score @s gacha_shiny matches 1 run givepokemon @s wingull shiny
execute if score @s gacha_pick matches 116 unless score @s gacha_shiny matches 1 run givepokemon @s wingull
execute if score @s gacha_pick matches 117 if score @s gacha_shiny matches 1 run givepokemon @s ralts shiny
execute if score @s gacha_pick matches 117 unless score @s gacha_shiny matches 1 run givepokemon @s ralts
execute if score @s gacha_pick matches 118 if score @s gacha_shiny matches 1 run givepokemon @s shroomish shiny
execute if score @s gacha_pick matches 118 unless score @s gacha_shiny matches 1 run givepokemon @s shroomish
execute if score @s gacha_pick matches 119 if score @s gacha_shiny matches 1 run givepokemon @s slakoth shiny
execute if score @s gacha_pick matches 119 unless score @s gacha_shiny matches 1 run givepokemon @s slakoth
execute if score @s gacha_pick matches 120 if score @s gacha_shiny matches 1 run givepokemon @s nincada shiny
execute if score @s gacha_pick matches 120 unless score @s gacha_shiny matches 1 run givepokemon @s nincada
execute if score @s gacha_pick matches 121 if score @s gacha_shiny matches 1 run givepokemon @s loudred shiny
execute if score @s gacha_pick matches 121 unless score @s gacha_shiny matches 1 run givepokemon @s loudred
execute if score @s gacha_pick matches 122 if score @s gacha_shiny matches 1 run givepokemon @s skitty shiny
execute if score @s gacha_pick matches 122 unless score @s gacha_shiny matches 1 run givepokemon @s skitty
execute if score @s gacha_pick matches 123 if score @s gacha_shiny matches 1 run givepokemon @s meditite shiny
execute if score @s gacha_pick matches 123 unless score @s gacha_shiny matches 1 run givepokemon @s meditite
execute if score @s gacha_pick matches 124 if score @s gacha_shiny matches 1 run givepokemon @s electrike shiny
execute if score @s gacha_pick matches 124 unless score @s gacha_shiny matches 1 run givepokemon @s electrike
execute if score @s gacha_pick matches 125 if score @s gacha_shiny matches 1 run givepokemon @s plusle shiny
execute if score @s gacha_pick matches 125 unless score @s gacha_shiny matches 1 run givepokemon @s plusle
execute if score @s gacha_pick matches 126 if score @s gacha_shiny matches 1 run givepokemon @s minun shiny
execute if score @s gacha_pick matches 126 unless score @s gacha_shiny matches 1 run givepokemon @s minun
execute if score @s gacha_pick matches 127 if score @s gacha_shiny matches 1 run givepokemon @s volbeat shiny
execute if score @s gacha_pick matches 127 unless score @s gacha_shiny matches 1 run givepokemon @s volbeat
execute if score @s gacha_pick matches 128 if score @s gacha_shiny matches 1 run givepokemon @s illumise shiny
execute if score @s gacha_pick matches 128 unless score @s gacha_shiny matches 1 run givepokemon @s illumise
execute if score @s gacha_pick matches 129 if score @s gacha_shiny matches 1 run givepokemon @s roselia shiny
execute if score @s gacha_pick matches 129 unless score @s gacha_shiny matches 1 run givepokemon @s roselia
execute if score @s gacha_pick matches 130 if score @s gacha_shiny matches 1 run givepokemon @s gulpin shiny
execute if score @s gacha_pick matches 130 unless score @s gacha_shiny matches 1 run givepokemon @s gulpin
execute if score @s gacha_pick matches 131 if score @s gacha_shiny matches 1 run givepokemon @s carvanha shiny
execute if score @s gacha_pick matches 131 unless score @s gacha_shiny matches 1 run givepokemon @s carvanha
execute if score @s gacha_pick matches 132 if score @s gacha_shiny matches 1 run givepokemon @s numel shiny
execute if score @s gacha_pick matches 132 unless score @s gacha_shiny matches 1 run givepokemon @s numel
execute if score @s gacha_pick matches 133 if score @s gacha_shiny matches 1 run givepokemon @s torkoal shiny
execute if score @s gacha_pick matches 133 unless score @s gacha_shiny matches 1 run givepokemon @s torkoal
execute if score @s gacha_pick matches 134 if score @s gacha_shiny matches 1 run givepokemon @s trapinch shiny
execute if score @s gacha_pick matches 134 unless score @s gacha_shiny matches 1 run givepokemon @s trapinch
execute if score @s gacha_pick matches 135 if score @s gacha_shiny matches 1 run givepokemon @s seviper shiny
execute if score @s gacha_pick matches 135 unless score @s gacha_shiny matches 1 run givepokemon @s seviper
execute if score @s gacha_pick matches 136 if score @s gacha_shiny matches 1 run givepokemon @s barboach shiny
execute if score @s gacha_pick matches 136 unless score @s gacha_shiny matches 1 run givepokemon @s barboach
execute if score @s gacha_pick matches 137 if score @s gacha_shiny matches 1 run givepokemon @s lileep shiny
execute if score @s gacha_pick matches 137 unless score @s gacha_shiny matches 1 run givepokemon @s lileep
execute if score @s gacha_pick matches 138 if score @s gacha_shiny matches 1 run givepokemon @s anorith shiny
execute if score @s gacha_pick matches 138 unless score @s gacha_shiny matches 1 run givepokemon @s anorith
execute if score @s gacha_pick matches 139 if score @s gacha_shiny matches 1 run givepokemon @s feebas shiny
execute if score @s gacha_pick matches 139 unless score @s gacha_shiny matches 1 run givepokemon @s feebas
execute if score @s gacha_pick matches 140 if score @s gacha_shiny matches 1 run givepokemon @s castform shiny
execute if score @s gacha_pick matches 140 unless score @s gacha_shiny matches 1 run givepokemon @s castform
execute if score @s gacha_pick matches 141 if score @s gacha_shiny matches 1 run givepokemon @s kecleon shiny
execute if score @s gacha_pick matches 141 unless score @s gacha_shiny matches 1 run givepokemon @s kecleon
execute if score @s gacha_pick matches 142 if score @s gacha_shiny matches 1 run givepokemon @s duskull shiny
execute if score @s gacha_pick matches 142 unless score @s gacha_shiny matches 1 run givepokemon @s duskull
execute if score @s gacha_pick matches 143 if score @s gacha_shiny matches 1 run givepokemon @s tropius shiny
execute if score @s gacha_pick matches 143 unless score @s gacha_shiny matches 1 run givepokemon @s tropius
execute if score @s gacha_pick matches 144 if score @s gacha_shiny matches 1 run givepokemon @s chimecho shiny
execute if score @s gacha_pick matches 144 unless score @s gacha_shiny matches 1 run givepokemon @s chimecho
execute if score @s gacha_pick matches 145 if score @s gacha_shiny matches 1 run givepokemon @s absol shiny
execute if score @s gacha_pick matches 145 unless score @s gacha_shiny matches 1 run givepokemon @s absol
execute if score @s gacha_pick matches 146 if score @s gacha_shiny matches 1 run givepokemon @s wynaut shiny
execute if score @s gacha_pick matches 146 unless score @s gacha_shiny matches 1 run givepokemon @s wynaut
execute if score @s gacha_pick matches 147 if score @s gacha_shiny matches 1 run givepokemon @s snorunt shiny
execute if score @s gacha_pick matches 147 unless score @s gacha_shiny matches 1 run givepokemon @s snorunt
execute if score @s gacha_pick matches 148 if score @s gacha_shiny matches 1 run givepokemon @s spheal shiny
execute if score @s gacha_pick matches 148 unless score @s gacha_shiny matches 1 run givepokemon @s spheal
execute if score @s gacha_pick matches 149 if score @s gacha_shiny matches 1 run givepokemon @s clamperl shiny
execute if score @s gacha_pick matches 149 unless score @s gacha_shiny matches 1 run givepokemon @s clamperl
execute if score @s gacha_pick matches 150 if score @s gacha_shiny matches 1 run givepokemon @s huntail shiny
execute if score @s gacha_pick matches 150 unless score @s gacha_shiny matches 1 run givepokemon @s huntail
execute if score @s gacha_pick matches 151 if score @s gacha_shiny matches 1 run givepokemon @s shelgon shiny
execute if score @s gacha_pick matches 151 unless score @s gacha_shiny matches 1 run givepokemon @s shelgon
execute if score @s gacha_pick matches 152 if score @s gacha_shiny matches 1 run givepokemon @s turtwig shiny
execute if score @s gacha_pick matches 152 unless score @s gacha_shiny matches 1 run givepokemon @s turtwig
execute if score @s gacha_pick matches 153 if score @s gacha_shiny matches 1 run givepokemon @s grotle shiny
execute if score @s gacha_pick matches 153 unless score @s gacha_shiny matches 1 run givepokemon @s grotle
execute if score @s gacha_pick matches 154 if score @s gacha_shiny matches 1 run givepokemon @s monferno shiny
execute if score @s gacha_pick matches 154 unless score @s gacha_shiny matches 1 run givepokemon @s monferno
execute if score @s gacha_pick matches 155 if score @s gacha_shiny matches 1 run givepokemon @s prinplup shiny
execute if score @s gacha_pick matches 155 unless score @s gacha_shiny matches 1 run givepokemon @s prinplup
execute if score @s gacha_pick matches 156 if score @s gacha_shiny matches 1 run givepokemon @s starly shiny
execute if score @s gacha_pick matches 156 unless score @s gacha_shiny matches 1 run givepokemon @s starly
execute if score @s gacha_pick matches 157 if score @s gacha_shiny matches 1 run givepokemon @s staravia shiny
execute if score @s gacha_pick matches 157 unless score @s gacha_shiny matches 1 run givepokemon @s staravia
execute if score @s gacha_pick matches 158 if score @s gacha_shiny matches 1 run givepokemon @s kricketot shiny
execute if score @s gacha_pick matches 158 unless score @s gacha_shiny matches 1 run givepokemon @s kricketot
execute if score @s gacha_pick matches 159 if score @s gacha_shiny matches 1 run givepokemon @s shinx shiny
execute if score @s gacha_pick matches 159 unless score @s gacha_shiny matches 1 run givepokemon @s shinx
execute if score @s gacha_pick matches 160 if score @s gacha_shiny matches 1 run givepokemon @s budew shiny
execute if score @s gacha_pick matches 160 unless score @s gacha_shiny matches 1 run givepokemon @s budew
execute if score @s gacha_pick matches 161 if score @s gacha_shiny matches 1 run givepokemon @s cranidos shiny
execute if score @s gacha_pick matches 161 unless score @s gacha_shiny matches 1 run givepokemon @s cranidos
execute if score @s gacha_pick matches 162 if score @s gacha_shiny matches 1 run givepokemon @s shieldon shiny
execute if score @s gacha_pick matches 162 unless score @s gacha_shiny matches 1 run givepokemon @s shieldon
execute if score @s gacha_pick matches 163 if score @s gacha_shiny matches 1 run givepokemon @s burmy shiny
execute if score @s gacha_pick matches 163 unless score @s gacha_shiny matches 1 run givepokemon @s burmy
execute if score @s gacha_pick matches 164 if score @s gacha_shiny matches 1 run givepokemon @s combee shiny
execute if score @s gacha_pick matches 164 unless score @s gacha_shiny matches 1 run givepokemon @s combee
execute if score @s gacha_pick matches 165 if score @s gacha_shiny matches 1 run givepokemon @s pachirisu shiny
execute if score @s gacha_pick matches 165 unless score @s gacha_shiny matches 1 run givepokemon @s pachirisu
execute if score @s gacha_pick matches 166 if score @s gacha_shiny matches 1 run givepokemon @s buneary shiny
execute if score @s gacha_pick matches 166 unless score @s gacha_shiny matches 1 run givepokemon @s buneary
execute if score @s gacha_pick matches 167 if score @s gacha_shiny matches 1 run givepokemon @s glameow shiny
execute if score @s gacha_pick matches 167 unless score @s gacha_shiny matches 1 run givepokemon @s glameow
execute if score @s gacha_pick matches 168 if score @s gacha_shiny matches 1 run givepokemon @s chingling shiny
execute if score @s gacha_pick matches 168 unless score @s gacha_shiny matches 1 run givepokemon @s chingling
execute if score @s gacha_pick matches 169 if score @s gacha_shiny matches 1 run givepokemon @s stunky shiny
execute if score @s gacha_pick matches 169 unless score @s gacha_shiny matches 1 run givepokemon @s stunky
execute if score @s gacha_pick matches 170 if score @s gacha_shiny matches 1 run givepokemon @s mimejr shiny
execute if score @s gacha_pick matches 170 unless score @s gacha_shiny matches 1 run givepokemon @s mimejr
execute if score @s gacha_pick matches 171 if score @s gacha_shiny matches 1 run givepokemon @s happiny shiny
execute if score @s gacha_pick matches 171 unless score @s gacha_shiny matches 1 run givepokemon @s happiny
execute if score @s gacha_pick matches 172 if score @s gacha_shiny matches 1 run givepokemon @s gible shiny
execute if score @s gacha_pick matches 172 unless score @s gacha_shiny matches 1 run givepokemon @s gible
execute if score @s gacha_pick matches 173 if score @s gacha_shiny matches 1 run givepokemon @s gabite shiny
execute if score @s gacha_pick matches 173 unless score @s gacha_shiny matches 1 run givepokemon @s gabite
execute if score @s gacha_pick matches 174 if score @s gacha_shiny matches 1 run givepokemon @s skorupi shiny
execute if score @s gacha_pick matches 174 unless score @s gacha_shiny matches 1 run givepokemon @s skorupi
execute if score @s gacha_pick matches 175 if score @s gacha_shiny matches 1 run givepokemon @s carnivine shiny
execute if score @s gacha_pick matches 175 unless score @s gacha_shiny matches 1 run givepokemon @s carnivine
execute if score @s gacha_pick matches 176 if score @s gacha_shiny matches 1 run givepokemon @s finneon shiny
execute if score @s gacha_pick matches 176 unless score @s gacha_shiny matches 1 run givepokemon @s finneon
execute if score @s gacha_pick matches 177 if score @s gacha_shiny matches 1 run givepokemon @s mantyke shiny
execute if score @s gacha_pick matches 177 unless score @s gacha_shiny matches 1 run givepokemon @s mantyke
execute if score @s gacha_pick matches 178 if score @s gacha_shiny matches 1 run givepokemon @s leafeon shiny
execute if score @s gacha_pick matches 178 unless score @s gacha_shiny matches 1 run givepokemon @s leafeon
execute if score @s gacha_pick matches 179 if score @s gacha_shiny matches 1 run givepokemon @s snivy shiny
execute if score @s gacha_pick matches 179 unless score @s gacha_shiny matches 1 run givepokemon @s snivy
execute if score @s gacha_pick matches 180 if score @s gacha_shiny matches 1 run givepokemon @s servine shiny
execute if score @s gacha_pick matches 180 unless score @s gacha_shiny matches 1 run givepokemon @s servine
execute if score @s gacha_pick matches 181 if score @s gacha_shiny matches 1 run givepokemon @s pignite shiny
execute if score @s gacha_pick matches 181 unless score @s gacha_shiny matches 1 run givepokemon @s pignite
execute if score @s gacha_pick matches 182 if score @s gacha_shiny matches 1 run givepokemon @s oshawott shiny
execute if score @s gacha_pick matches 182 unless score @s gacha_shiny matches 1 run givepokemon @s oshawott
execute if score @s gacha_pick matches 183 if score @s gacha_shiny matches 1 run givepokemon @s patrat shiny
execute if score @s gacha_pick matches 183 unless score @s gacha_shiny matches 1 run givepokemon @s patrat
execute if score @s gacha_pick matches 184 if score @s gacha_shiny matches 1 run givepokemon @s watchog shiny
execute if score @s gacha_pick matches 184 unless score @s gacha_shiny matches 1 run givepokemon @s watchog
execute if score @s gacha_pick matches 185 if score @s gacha_shiny matches 1 run givepokemon @s lillipup shiny
execute if score @s gacha_pick matches 185 unless score @s gacha_shiny matches 1 run givepokemon @s lillipup
execute if score @s gacha_pick matches 186 if score @s gacha_shiny matches 1 run givepokemon @s herdier shiny
execute if score @s gacha_pick matches 186 unless score @s gacha_shiny matches 1 run givepokemon @s herdier
execute if score @s gacha_pick matches 187 if score @s gacha_shiny matches 1 run givepokemon @s pansear shiny
execute if score @s gacha_pick matches 187 unless score @s gacha_shiny matches 1 run givepokemon @s pansear
execute if score @s gacha_pick matches 188 if score @s gacha_shiny matches 1 run givepokemon @s panpour shiny
execute if score @s gacha_pick matches 188 unless score @s gacha_shiny matches 1 run givepokemon @s panpour
execute if score @s gacha_pick matches 189 if score @s gacha_shiny matches 1 run givepokemon @s pidove shiny
execute if score @s gacha_pick matches 189 unless score @s gacha_shiny matches 1 run givepokemon @s pidove
execute if score @s gacha_pick matches 190 if score @s gacha_shiny matches 1 run givepokemon @s tranquill shiny
execute if score @s gacha_pick matches 190 unless score @s gacha_shiny matches 1 run givepokemon @s tranquill
execute if score @s gacha_pick matches 191 if score @s gacha_shiny matches 1 run givepokemon @s blitzle shiny
execute if score @s gacha_pick matches 191 unless score @s gacha_shiny matches 1 run givepokemon @s blitzle
execute if score @s gacha_pick matches 192 if score @s gacha_shiny matches 1 run givepokemon @s roggenrola shiny
execute if score @s gacha_pick matches 192 unless score @s gacha_shiny matches 1 run givepokemon @s roggenrola
execute if score @s gacha_pick matches 193 if score @s gacha_shiny matches 1 run givepokemon @s boldore shiny
execute if score @s gacha_pick matches 193 unless score @s gacha_shiny matches 1 run givepokemon @s boldore
execute if score @s gacha_pick matches 194 if score @s gacha_shiny matches 1 run givepokemon @s woobat shiny
execute if score @s gacha_pick matches 194 unless score @s gacha_shiny matches 1 run givepokemon @s woobat
execute if score @s gacha_pick matches 195 if score @s gacha_shiny matches 1 run givepokemon @s swoobat shiny
execute if score @s gacha_pick matches 195 unless score @s gacha_shiny matches 1 run givepokemon @s swoobat
execute if score @s gacha_pick matches 196 if score @s gacha_shiny matches 1 run givepokemon @s audino shiny
execute if score @s gacha_pick matches 196 unless score @s gacha_shiny matches 1 run givepokemon @s audino
execute if score @s gacha_pick matches 197 if score @s gacha_shiny matches 1 run givepokemon @s timburr shiny
execute if score @s gacha_pick matches 197 unless score @s gacha_shiny matches 1 run givepokemon @s timburr
execute if score @s gacha_pick matches 198 if score @s gacha_shiny matches 1 run givepokemon @s gurdurr shiny
execute if score @s gacha_pick matches 198 unless score @s gacha_shiny matches 1 run givepokemon @s gurdurr
execute if score @s gacha_pick matches 199 if score @s gacha_shiny matches 1 run givepokemon @s tympole shiny
execute if score @s gacha_pick matches 199 unless score @s gacha_shiny matches 1 run givepokemon @s tympole
execute if score @s gacha_pick matches 200 if score @s gacha_shiny matches 1 run givepokemon @s palpitoad shiny
execute if score @s gacha_pick matches 200 unless score @s gacha_shiny matches 1 run givepokemon @s palpitoad
execute if score @s gacha_pick matches 201 if score @s gacha_shiny matches 1 run givepokemon @s sewaddle shiny
execute if score @s gacha_pick matches 201 unless score @s gacha_shiny matches 1 run givepokemon @s sewaddle
execute if score @s gacha_pick matches 202 if score @s gacha_shiny matches 1 run givepokemon @s swadloon shiny
execute if score @s gacha_pick matches 202 unless score @s gacha_shiny matches 1 run givepokemon @s swadloon
execute if score @s gacha_pick matches 203 if score @s gacha_shiny matches 1 run givepokemon @s venipede shiny
execute if score @s gacha_pick matches 203 unless score @s gacha_shiny matches 1 run givepokemon @s venipede
execute if score @s gacha_pick matches 204 if score @s gacha_shiny matches 1 run givepokemon @s whirlipede shiny
execute if score @s gacha_pick matches 204 unless score @s gacha_shiny matches 1 run givepokemon @s whirlipede
execute if score @s gacha_pick matches 205 if score @s gacha_shiny matches 1 run givepokemon @s cottonee shiny
execute if score @s gacha_pick matches 205 unless score @s gacha_shiny matches 1 run givepokemon @s cottonee
execute if score @s gacha_pick matches 206 if score @s gacha_shiny matches 1 run givepokemon @s petilil shiny
execute if score @s gacha_pick matches 206 unless score @s gacha_shiny matches 1 run givepokemon @s petilil
execute if score @s gacha_pick matches 207 if score @s gacha_shiny matches 1 run givepokemon @s sandile shiny
execute if score @s gacha_pick matches 207 unless score @s gacha_shiny matches 1 run givepokemon @s sandile
execute if score @s gacha_pick matches 208 if score @s gacha_shiny matches 1 run givepokemon @s darumaka shiny
execute if score @s gacha_pick matches 208 unless score @s gacha_shiny matches 1 run givepokemon @s darumaka
execute if score @s gacha_pick matches 209 if score @s gacha_shiny matches 1 run givepokemon @s dwebble shiny
execute if score @s gacha_pick matches 209 unless score @s gacha_shiny matches 1 run givepokemon @s dwebble
execute if score @s gacha_pick matches 210 if score @s gacha_shiny matches 1 run givepokemon @s scraggy shiny
execute if score @s gacha_pick matches 210 unless score @s gacha_shiny matches 1 run givepokemon @s scraggy
execute if score @s gacha_pick matches 211 if score @s gacha_shiny matches 1 run givepokemon @s yamask shiny
execute if score @s gacha_pick matches 211 unless score @s gacha_shiny matches 1 run givepokemon @s yamask
execute if score @s gacha_pick matches 212 if score @s gacha_shiny matches 1 run givepokemon @s archen shiny
execute if score @s gacha_pick matches 212 unless score @s gacha_shiny matches 1 run givepokemon @s archen
execute if score @s gacha_pick matches 213 if score @s gacha_shiny matches 1 run givepokemon @s minccino shiny
execute if score @s gacha_pick matches 213 unless score @s gacha_shiny matches 1 run givepokemon @s minccino
execute if score @s gacha_pick matches 214 if score @s gacha_shiny matches 1 run givepokemon @s gothita shiny
execute if score @s gacha_pick matches 214 unless score @s gacha_shiny matches 1 run givepokemon @s gothita
execute if score @s gacha_pick matches 215 if score @s gacha_shiny matches 1 run givepokemon @s gothorita shiny
execute if score @s gacha_pick matches 215 unless score @s gacha_shiny matches 1 run givepokemon @s gothorita
execute if score @s gacha_pick matches 216 if score @s gacha_shiny matches 1 run givepokemon @s duosion shiny
execute if score @s gacha_pick matches 216 unless score @s gacha_shiny matches 1 run givepokemon @s duosion
execute if score @s gacha_pick matches 217 if score @s gacha_shiny matches 1 run givepokemon @s vanillite shiny
execute if score @s gacha_pick matches 217 unless score @s gacha_shiny matches 1 run givepokemon @s vanillite
execute if score @s gacha_pick matches 218 if score @s gacha_shiny matches 1 run givepokemon @s vanillish shiny
execute if score @s gacha_pick matches 218 unless score @s gacha_shiny matches 1 run givepokemon @s vanillish
execute if score @s gacha_pick matches 219 if score @s gacha_shiny matches 1 run givepokemon @s deerling shiny
execute if score @s gacha_pick matches 219 unless score @s gacha_shiny matches 1 run givepokemon @s deerling
execute if score @s gacha_pick matches 220 if score @s gacha_shiny matches 1 run givepokemon @s emolga shiny
execute if score @s gacha_pick matches 220 unless score @s gacha_shiny matches 1 run givepokemon @s emolga
execute if score @s gacha_pick matches 221 if score @s gacha_shiny matches 1 run givepokemon @s foongus shiny
execute if score @s gacha_pick matches 221 unless score @s gacha_shiny matches 1 run givepokemon @s foongus
execute if score @s gacha_pick matches 222 if score @s gacha_shiny matches 1 run givepokemon @s alomomola shiny
execute if score @s gacha_pick matches 222 unless score @s gacha_shiny matches 1 run givepokemon @s alomomola
execute if score @s gacha_pick matches 223 if score @s gacha_shiny matches 1 run givepokemon @s joltik shiny
execute if score @s gacha_pick matches 223 unless score @s gacha_shiny matches 1 run givepokemon @s joltik
execute if score @s gacha_pick matches 224 if score @s gacha_shiny matches 1 run givepokemon @s ferroseed shiny
execute if score @s gacha_pick matches 224 unless score @s gacha_shiny matches 1 run givepokemon @s ferroseed
execute if score @s gacha_pick matches 225 if score @s gacha_shiny matches 1 run givepokemon @s klinklang shiny
execute if score @s gacha_pick matches 225 unless score @s gacha_shiny matches 1 run givepokemon @s klinklang
execute if score @s gacha_pick matches 226 if score @s gacha_shiny matches 1 run givepokemon @s tynamo shiny
execute if score @s gacha_pick matches 226 unless score @s gacha_shiny matches 1 run givepokemon @s tynamo
execute if score @s gacha_pick matches 227 if score @s gacha_shiny matches 1 run givepokemon @s elgyem shiny
execute if score @s gacha_pick matches 227 unless score @s gacha_shiny matches 1 run givepokemon @s elgyem
execute if score @s gacha_pick matches 228 if score @s gacha_shiny matches 1 run givepokemon @s axew shiny
execute if score @s gacha_pick matches 228 unless score @s gacha_shiny matches 1 run givepokemon @s axew
execute if score @s gacha_pick matches 229 if score @s gacha_shiny matches 1 run givepokemon @s cubchoo shiny
execute if score @s gacha_pick matches 229 unless score @s gacha_shiny matches 1 run givepokemon @s cubchoo
execute if score @s gacha_pick matches 230 if score @s gacha_shiny matches 1 run givepokemon @s cryogonal shiny
execute if score @s gacha_pick matches 230 unless score @s gacha_shiny matches 1 run givepokemon @s cryogonal
execute if score @s gacha_pick matches 231 if score @s gacha_shiny matches 1 run givepokemon @s shelmet shiny
execute if score @s gacha_pick matches 231 unless score @s gacha_shiny matches 1 run givepokemon @s shelmet
execute if score @s gacha_pick matches 232 if score @s gacha_shiny matches 1 run givepokemon @s stunfisk shiny
execute if score @s gacha_pick matches 232 unless score @s gacha_shiny matches 1 run givepokemon @s stunfisk
execute if score @s gacha_pick matches 233 if score @s gacha_shiny matches 1 run givepokemon @s mienfoo shiny
execute if score @s gacha_pick matches 233 unless score @s gacha_shiny matches 1 run givepokemon @s mienfoo
execute if score @s gacha_pick matches 234 if score @s gacha_shiny matches 1 run givepokemon @s golett shiny
execute if score @s gacha_pick matches 234 unless score @s gacha_shiny matches 1 run givepokemon @s golett
execute if score @s gacha_pick matches 235 if score @s gacha_shiny matches 1 run givepokemon @s pawniard shiny
execute if score @s gacha_pick matches 235 unless score @s gacha_shiny matches 1 run givepokemon @s pawniard
execute if score @s gacha_pick matches 236 if score @s gacha_shiny matches 1 run givepokemon @s bouffalant shiny
execute if score @s gacha_pick matches 236 unless score @s gacha_shiny matches 1 run givepokemon @s bouffalant
execute if score @s gacha_pick matches 237 if score @s gacha_shiny matches 1 run givepokemon @s rufflet shiny
execute if score @s gacha_pick matches 237 unless score @s gacha_shiny matches 1 run givepokemon @s rufflet
execute if score @s gacha_pick matches 238 if score @s gacha_shiny matches 1 run givepokemon @s vullaby shiny
execute if score @s gacha_pick matches 238 unless score @s gacha_shiny matches 1 run givepokemon @s vullaby
execute if score @s gacha_pick matches 239 if score @s gacha_shiny matches 1 run givepokemon @s heatmor shiny
execute if score @s gacha_pick matches 239 unless score @s gacha_shiny matches 1 run givepokemon @s heatmor
execute if score @s gacha_pick matches 240 if score @s gacha_shiny matches 1 run givepokemon @s deino shiny
execute if score @s gacha_pick matches 240 unless score @s gacha_shiny matches 1 run givepokemon @s deino
execute if score @s gacha_pick matches 241 if score @s gacha_shiny matches 1 run givepokemon @s zweilous shiny
execute if score @s gacha_pick matches 241 unless score @s gacha_shiny matches 1 run givepokemon @s zweilous
execute if score @s gacha_pick matches 242 if score @s gacha_shiny matches 1 run givepokemon @s larvesta shiny
execute if score @s gacha_pick matches 242 unless score @s gacha_shiny matches 1 run givepokemon @s larvesta
execute if score @s gacha_pick matches 243 if score @s gacha_shiny matches 1 run givepokemon @s chespin shiny
execute if score @s gacha_pick matches 243 unless score @s gacha_shiny matches 1 run givepokemon @s chespin
execute if score @s gacha_pick matches 244 if score @s gacha_shiny matches 1 run givepokemon @s braixen shiny
execute if score @s gacha_pick matches 244 unless score @s gacha_shiny matches 1 run givepokemon @s braixen
execute if score @s gacha_pick matches 245 if score @s gacha_shiny matches 1 run givepokemon @s froakie shiny
execute if score @s gacha_pick matches 245 unless score @s gacha_shiny matches 1 run givepokemon @s froakie
execute if score @s gacha_pick matches 246 if score @s gacha_shiny matches 1 run givepokemon @s frogadier shiny
execute if score @s gacha_pick matches 246 unless score @s gacha_shiny matches 1 run givepokemon @s frogadier
execute if score @s gacha_pick matches 247 if score @s gacha_shiny matches 1 run givepokemon @s bunnelby shiny
execute if score @s gacha_pick matches 247 unless score @s gacha_shiny matches 1 run givepokemon @s bunnelby
execute if score @s gacha_pick matches 248 if score @s gacha_shiny matches 1 run givepokemon @s fletchinder shiny
execute if score @s gacha_pick matches 248 unless score @s gacha_shiny matches 1 run givepokemon @s fletchinder
execute if score @s gacha_pick matches 249 if score @s gacha_shiny matches 1 run givepokemon @s scatterbug shiny
execute if score @s gacha_pick matches 249 unless score @s gacha_shiny matches 1 run givepokemon @s scatterbug
execute if score @s gacha_pick matches 250 if score @s gacha_shiny matches 1 run givepokemon @s spewpa shiny
execute if score @s gacha_pick matches 250 unless score @s gacha_shiny matches 1 run givepokemon @s spewpa
execute if score @s gacha_pick matches 251 if score @s gacha_shiny matches 1 run givepokemon @s litleo shiny
execute if score @s gacha_pick matches 251 unless score @s gacha_shiny matches 1 run givepokemon @s litleo
execute if score @s gacha_pick matches 252 if score @s gacha_shiny matches 1 run givepokemon @s floette shiny
execute if score @s gacha_pick matches 252 unless score @s gacha_shiny matches 1 run givepokemon @s floette
execute if score @s gacha_pick matches 253 if score @s gacha_shiny matches 1 run givepokemon @s skiddo shiny
execute if score @s gacha_pick matches 253 unless score @s gacha_shiny matches 1 run givepokemon @s skiddo
execute if score @s gacha_pick matches 254 if score @s gacha_shiny matches 1 run givepokemon @s pancham shiny
execute if score @s gacha_pick matches 254 unless score @s gacha_shiny matches 1 run givepokemon @s pancham
execute if score @s gacha_pick matches 255 if score @s gacha_shiny matches 1 run givepokemon @s espurr shiny
execute if score @s gacha_pick matches 255 unless score @s gacha_shiny matches 1 run givepokemon @s espurr
execute if score @s gacha_pick matches 256 if score @s gacha_shiny matches 1 run givepokemon @s honedge shiny
execute if score @s gacha_pick matches 256 unless score @s gacha_shiny matches 1 run givepokemon @s honedge
execute if score @s gacha_pick matches 257 if score @s gacha_shiny matches 1 run givepokemon @s doublade shiny
execute if score @s gacha_pick matches 257 unless score @s gacha_shiny matches 1 run givepokemon @s doublade
execute if score @s gacha_pick matches 258 if score @s gacha_shiny matches 1 run givepokemon @s spritzee shiny
execute if score @s gacha_pick matches 258 unless score @s gacha_shiny matches 1 run givepokemon @s spritzee
execute if score @s gacha_pick matches 259 if score @s gacha_shiny matches 1 run givepokemon @s binacle shiny
execute if score @s gacha_pick matches 259 unless score @s gacha_shiny matches 1 run givepokemon @s binacle
execute if score @s gacha_pick matches 260 if score @s gacha_shiny matches 1 run givepokemon @s clauncher shiny
execute if score @s gacha_pick matches 260 unless score @s gacha_shiny matches 1 run givepokemon @s clauncher
execute if score @s gacha_pick matches 261 if score @s gacha_shiny matches 1 run givepokemon @s tyrunt shiny
execute if score @s gacha_pick matches 261 unless score @s gacha_shiny matches 1 run givepokemon @s tyrunt
execute if score @s gacha_pick matches 262 if score @s gacha_shiny matches 1 run givepokemon @s amaura shiny
execute if score @s gacha_pick matches 262 unless score @s gacha_shiny matches 1 run givepokemon @s amaura
execute if score @s gacha_pick matches 263 if score @s gacha_shiny matches 1 run givepokemon @s phantump shiny
execute if score @s gacha_pick matches 263 unless score @s gacha_shiny matches 1 run givepokemon @s phantump
execute if score @s gacha_pick matches 264 if score @s gacha_shiny matches 1 run givepokemon @s pumpkaboo shiny
execute if score @s gacha_pick matches 264 unless score @s gacha_shiny matches 1 run givepokemon @s pumpkaboo
execute if score @s gacha_pick matches 265 if score @s gacha_shiny matches 1 run givepokemon @s bergmite shiny
execute if score @s gacha_pick matches 265 unless score @s gacha_shiny matches 1 run givepokemon @s bergmite
execute if score @s gacha_pick matches 266 if score @s gacha_shiny matches 1 run givepokemon @s noibat shiny
execute if score @s gacha_pick matches 266 unless score @s gacha_shiny matches 1 run givepokemon @s noibat
execute if score @s gacha_pick matches 267 if score @s gacha_shiny matches 1 run givepokemon @s dartrix shiny
execute if score @s gacha_pick matches 267 unless score @s gacha_shiny matches 1 run givepokemon @s dartrix
execute if score @s gacha_pick matches 268 if score @s gacha_shiny matches 1 run givepokemon @s litten shiny
execute if score @s gacha_pick matches 268 unless score @s gacha_shiny matches 1 run givepokemon @s litten
execute if score @s gacha_pick matches 269 if score @s gacha_shiny matches 1 run givepokemon @s brionne shiny
execute if score @s gacha_pick matches 269 unless score @s gacha_shiny matches 1 run givepokemon @s brionne
execute if score @s gacha_pick matches 270 if score @s gacha_shiny matches 1 run givepokemon @s pikipek shiny
execute if score @s gacha_pick matches 270 unless score @s gacha_shiny matches 1 run givepokemon @s pikipek
execute if score @s gacha_pick matches 271 if score @s gacha_shiny matches 1 run givepokemon @s trumbeak shiny
execute if score @s gacha_pick matches 271 unless score @s gacha_shiny matches 1 run givepokemon @s trumbeak
execute if score @s gacha_pick matches 272 if score @s gacha_shiny matches 1 run givepokemon @s yungoos shiny
execute if score @s gacha_pick matches 272 unless score @s gacha_shiny matches 1 run givepokemon @s yungoos
execute if score @s gacha_pick matches 273 if score @s gacha_shiny matches 1 run givepokemon @s grubbin shiny
execute if score @s gacha_pick matches 273 unless score @s gacha_shiny matches 1 run givepokemon @s grubbin
execute if score @s gacha_pick matches 274 if score @s gacha_shiny matches 1 run givepokemon @s charjabug shiny
execute if score @s gacha_pick matches 274 unless score @s gacha_shiny matches 1 run givepokemon @s charjabug
execute if score @s gacha_pick matches 275 if score @s gacha_shiny matches 1 run givepokemon @s crabrawler shiny
execute if score @s gacha_pick matches 275 unless score @s gacha_shiny matches 1 run givepokemon @s crabrawler
execute if score @s gacha_pick matches 276 if score @s gacha_shiny matches 1 run givepokemon @s cutiefly shiny
execute if score @s gacha_pick matches 276 unless score @s gacha_shiny matches 1 run givepokemon @s cutiefly
execute if score @s gacha_pick matches 277 if score @s gacha_shiny matches 1 run givepokemon @s rockruff shiny
execute if score @s gacha_pick matches 277 unless score @s gacha_shiny matches 1 run givepokemon @s rockruff
execute if score @s gacha_pick matches 278 if score @s gacha_shiny matches 1 run givepokemon @s wishiwashi shiny
execute if score @s gacha_pick matches 278 unless score @s gacha_shiny matches 1 run givepokemon @s wishiwashi
execute if score @s gacha_pick matches 279 if score @s gacha_shiny matches 1 run givepokemon @s fomantis shiny
execute if score @s gacha_pick matches 279 unless score @s gacha_shiny matches 1 run givepokemon @s fomantis
execute if score @s gacha_pick matches 280 if score @s gacha_shiny matches 1 run givepokemon @s salandit shiny
execute if score @s gacha_pick matches 280 unless score @s gacha_shiny matches 1 run givepokemon @s salandit
execute if score @s gacha_pick matches 281 if score @s gacha_shiny matches 1 run givepokemon @s bounsweet shiny
execute if score @s gacha_pick matches 281 unless score @s gacha_shiny matches 1 run givepokemon @s bounsweet
execute if score @s gacha_pick matches 282 if score @s gacha_shiny matches 1 run givepokemon @s steenee shiny
execute if score @s gacha_pick matches 282 unless score @s gacha_shiny matches 1 run givepokemon @s steenee
execute if score @s gacha_pick matches 283 if score @s gacha_shiny matches 1 run givepokemon @s oranguru shiny
execute if score @s gacha_pick matches 283 unless score @s gacha_shiny matches 1 run givepokemon @s oranguru
execute if score @s gacha_pick matches 284 if score @s gacha_shiny matches 1 run givepokemon @s passimian shiny
execute if score @s gacha_pick matches 284 unless score @s gacha_shiny matches 1 run givepokemon @s passimian
execute if score @s gacha_pick matches 285 if score @s gacha_shiny matches 1 run givepokemon @s wimpod shiny
execute if score @s gacha_pick matches 285 unless score @s gacha_shiny matches 1 run givepokemon @s wimpod
execute if score @s gacha_pick matches 286 if score @s gacha_shiny matches 1 run givepokemon @s sandygast shiny
execute if score @s gacha_pick matches 286 unless score @s gacha_shiny matches 1 run givepokemon @s sandygast
execute if score @s gacha_pick matches 287 if score @s gacha_shiny matches 1 run givepokemon @s pyukumuku shiny
execute if score @s gacha_pick matches 287 unless score @s gacha_shiny matches 1 run givepokemon @s pyukumuku
execute if score @s gacha_pick matches 288 if score @s gacha_shiny matches 1 run givepokemon @s komala shiny
execute if score @s gacha_pick matches 288 unless score @s gacha_shiny matches 1 run givepokemon @s komala
execute if score @s gacha_pick matches 289 if score @s gacha_shiny matches 1 run givepokemon @s togedemaru shiny
execute if score @s gacha_pick matches 289 unless score @s gacha_shiny matches 1 run givepokemon @s togedemaru
execute if score @s gacha_pick matches 290 if score @s gacha_shiny matches 1 run givepokemon @s bruxish shiny
execute if score @s gacha_pick matches 290 unless score @s gacha_shiny matches 1 run givepokemon @s bruxish
execute if score @s gacha_pick matches 291 if score @s gacha_shiny matches 1 run givepokemon @s drampa shiny
execute if score @s gacha_pick matches 291 unless score @s gacha_shiny matches 1 run givepokemon @s drampa
execute if score @s gacha_pick matches 292 if score @s gacha_shiny matches 1 run givepokemon @s hakamo-o shiny
execute if score @s gacha_pick matches 292 unless score @s gacha_shiny matches 1 run givepokemon @s hakamo-o
execute if score @s gacha_pick matches 293 if score @s gacha_shiny matches 1 run givepokemon @s scorbunny shiny
execute if score @s gacha_pick matches 293 unless score @s gacha_shiny matches 1 run givepokemon @s scorbunny
execute if score @s gacha_pick matches 294 if score @s gacha_shiny matches 1 run givepokemon @s raboot shiny
execute if score @s gacha_pick matches 294 unless score @s gacha_shiny matches 1 run givepokemon @s raboot
execute if score @s gacha_pick matches 295 if score @s gacha_shiny matches 1 run givepokemon @s sobble shiny
execute if score @s gacha_pick matches 295 unless score @s gacha_shiny matches 1 run givepokemon @s sobble
execute if score @s gacha_pick matches 296 if score @s gacha_shiny matches 1 run givepokemon @s drizzile shiny
execute if score @s gacha_pick matches 296 unless score @s gacha_shiny matches 1 run givepokemon @s drizzile
execute if score @s gacha_pick matches 297 if score @s gacha_shiny matches 1 run givepokemon @s skwovet shiny
execute if score @s gacha_pick matches 297 unless score @s gacha_shiny matches 1 run givepokemon @s skwovet
execute if score @s gacha_pick matches 298 if score @s gacha_shiny matches 1 run givepokemon @s rookidee shiny
execute if score @s gacha_pick matches 298 unless score @s gacha_shiny matches 1 run givepokemon @s rookidee
execute if score @s gacha_pick matches 299 if score @s gacha_shiny matches 1 run givepokemon @s dottler shiny
execute if score @s gacha_pick matches 299 unless score @s gacha_shiny matches 1 run givepokemon @s dottler
execute if score @s gacha_pick matches 300 if score @s gacha_shiny matches 1 run givepokemon @s gossifleur shiny
execute if score @s gacha_pick matches 300 unless score @s gacha_shiny matches 1 run givepokemon @s gossifleur
execute if score @s gacha_pick matches 301 if score @s gacha_shiny matches 1 run givepokemon @s wooloo shiny
execute if score @s gacha_pick matches 301 unless score @s gacha_shiny matches 1 run givepokemon @s wooloo
execute if score @s gacha_pick matches 302 if score @s gacha_shiny matches 1 run givepokemon @s chewtle shiny
execute if score @s gacha_pick matches 302 unless score @s gacha_shiny matches 1 run givepokemon @s chewtle
execute if score @s gacha_pick matches 303 if score @s gacha_shiny matches 1 run givepokemon @s rolycoly shiny
execute if score @s gacha_pick matches 303 unless score @s gacha_shiny matches 1 run givepokemon @s rolycoly
execute if score @s gacha_pick matches 304 if score @s gacha_shiny matches 1 run givepokemon @s applin shiny
execute if score @s gacha_pick matches 304 unless score @s gacha_shiny matches 1 run givepokemon @s applin
execute if score @s gacha_pick matches 305 if score @s gacha_shiny matches 1 run givepokemon @s flapple shiny
execute if score @s gacha_pick matches 305 unless score @s gacha_shiny matches 1 run givepokemon @s flapple
execute if score @s gacha_pick matches 306 if score @s gacha_shiny matches 1 run givepokemon @s silicobra shiny
execute if score @s gacha_pick matches 306 unless score @s gacha_shiny matches 1 run givepokemon @s silicobra
execute if score @s gacha_pick matches 307 if score @s gacha_shiny matches 1 run givepokemon @s cramorant shiny
execute if score @s gacha_pick matches 307 unless score @s gacha_shiny matches 1 run givepokemon @s cramorant
execute if score @s gacha_pick matches 308 if score @s gacha_shiny matches 1 run givepokemon @s arrokuda shiny
execute if score @s gacha_pick matches 308 unless score @s gacha_shiny matches 1 run givepokemon @s arrokuda
execute if score @s gacha_pick matches 309 if score @s gacha_shiny matches 1 run givepokemon @s toxel shiny
execute if score @s gacha_pick matches 309 unless score @s gacha_shiny matches 1 run givepokemon @s toxel
execute if score @s gacha_pick matches 310 if score @s gacha_shiny matches 1 run givepokemon @s sizzlipede shiny
execute if score @s gacha_pick matches 310 unless score @s gacha_shiny matches 1 run givepokemon @s sizzlipede
execute if score @s gacha_pick matches 311 if score @s gacha_shiny matches 1 run givepokemon @s hattrem shiny
execute if score @s gacha_pick matches 311 unless score @s gacha_shiny matches 1 run givepokemon @s hattrem
execute if score @s gacha_pick matches 312 if score @s gacha_shiny matches 1 run givepokemon @s impidimp shiny
execute if score @s gacha_pick matches 312 unless score @s gacha_shiny matches 1 run givepokemon @s impidimp
execute if score @s gacha_pick matches 313 if score @s gacha_shiny matches 1 run givepokemon @s morgrem shiny
execute if score @s gacha_pick matches 313 unless score @s gacha_shiny matches 1 run givepokemon @s morgrem
execute if score @s gacha_pick matches 314 if score @s gacha_shiny matches 1 run givepokemon @s cursola shiny
execute if score @s gacha_pick matches 314 unless score @s gacha_shiny matches 1 run givepokemon @s cursola
execute if score @s gacha_pick matches 315 if score @s gacha_shiny matches 1 run givepokemon @s sirfetchd shiny
execute if score @s gacha_pick matches 315 unless score @s gacha_shiny matches 1 run givepokemon @s sirfetchd
execute if score @s gacha_pick matches 316 if score @s gacha_shiny matches 1 run givepokemon @s mrrime shiny
execute if score @s gacha_pick matches 316 unless score @s gacha_shiny matches 1 run givepokemon @s mrrime
execute if score @s gacha_pick matches 317 if score @s gacha_shiny matches 1 run givepokemon @s milcery shiny
execute if score @s gacha_pick matches 317 unless score @s gacha_shiny matches 1 run givepokemon @s milcery
execute if score @s gacha_pick matches 318 if score @s gacha_shiny matches 1 run givepokemon @s pincurchin shiny
execute if score @s gacha_pick matches 318 unless score @s gacha_shiny matches 1 run givepokemon @s pincurchin
execute if score @s gacha_pick matches 319 if score @s gacha_shiny matches 1 run givepokemon @s snom shiny
execute if score @s gacha_pick matches 319 unless score @s gacha_shiny matches 1 run givepokemon @s snom
execute if score @s gacha_pick matches 320 if score @s gacha_shiny matches 1 run givepokemon @s stonjourner shiny
execute if score @s gacha_pick matches 320 unless score @s gacha_shiny matches 1 run givepokemon @s stonjourner
execute if score @s gacha_pick matches 321 if score @s gacha_shiny matches 1 run givepokemon @s eiscue shiny
execute if score @s gacha_pick matches 321 unless score @s gacha_shiny matches 1 run givepokemon @s eiscue
execute if score @s gacha_pick matches 322 if score @s gacha_shiny matches 1 run givepokemon @s cufant shiny
execute if score @s gacha_pick matches 322 unless score @s gacha_shiny matches 1 run givepokemon @s cufant
execute if score @s gacha_pick matches 323 if score @s gacha_shiny matches 1 run givepokemon @s arctozolt shiny
execute if score @s gacha_pick matches 323 unless score @s gacha_shiny matches 1 run givepokemon @s arctozolt
execute if score @s gacha_pick matches 324 if score @s gacha_shiny matches 1 run givepokemon @s arctovish shiny
execute if score @s gacha_pick matches 324 unless score @s gacha_shiny matches 1 run givepokemon @s arctovish
execute if score @s gacha_pick matches 325 if score @s gacha_shiny matches 1 run givepokemon @s dreepy shiny
execute if score @s gacha_pick matches 325 unless score @s gacha_shiny matches 1 run givepokemon @s dreepy
execute if score @s gacha_pick matches 326 if score @s gacha_shiny matches 1 run givepokemon @s drakloak shiny
execute if score @s gacha_pick matches 326 unless score @s gacha_shiny matches 1 run givepokemon @s drakloak
execute if score @s gacha_pick matches 327 if score @s gacha_shiny matches 1 run givepokemon @s wyrdeer shiny
execute if score @s gacha_pick matches 327 unless score @s gacha_shiny matches 1 run givepokemon @s wyrdeer
execute if score @s gacha_pick matches 328 if score @s gacha_shiny matches 1 run givepokemon @s sprigatito shiny
execute if score @s gacha_pick matches 328 unless score @s gacha_shiny matches 1 run givepokemon @s sprigatito
execute if score @s gacha_pick matches 329 if score @s gacha_shiny matches 1 run givepokemon @s floragato shiny
execute if score @s gacha_pick matches 329 unless score @s gacha_shiny matches 1 run givepokemon @s floragato
execute if score @s gacha_pick matches 330 if score @s gacha_shiny matches 1 run givepokemon @s fuecoco shiny
execute if score @s gacha_pick matches 330 unless score @s gacha_shiny matches 1 run givepokemon @s fuecoco
execute if score @s gacha_pick matches 331 if score @s gacha_shiny matches 1 run givepokemon @s crocalor shiny
execute if score @s gacha_pick matches 331 unless score @s gacha_shiny matches 1 run givepokemon @s crocalor
execute if score @s gacha_pick matches 332 if score @s gacha_shiny matches 1 run givepokemon @s quaxly shiny
execute if score @s gacha_pick matches 332 unless score @s gacha_shiny matches 1 run givepokemon @s quaxly
execute if score @s gacha_pick matches 333 if score @s gacha_shiny matches 1 run givepokemon @s quaxwell shiny
execute if score @s gacha_pick matches 333 unless score @s gacha_shiny matches 1 run givepokemon @s quaxwell
execute if score @s gacha_pick matches 334 if score @s gacha_shiny matches 1 run givepokemon @s lechonk shiny
execute if score @s gacha_pick matches 334 unless score @s gacha_shiny matches 1 run givepokemon @s lechonk
execute if score @s gacha_pick matches 335 if score @s gacha_shiny matches 1 run givepokemon @s tarountula shiny
execute if score @s gacha_pick matches 335 unless score @s gacha_shiny matches 1 run givepokemon @s tarountula
execute if score @s gacha_pick matches 336 if score @s gacha_shiny matches 1 run givepokemon @s spidops shiny
execute if score @s gacha_pick matches 336 unless score @s gacha_shiny matches 1 run givepokemon @s spidops
execute if score @s gacha_pick matches 337 if score @s gacha_shiny matches 1 run givepokemon @s nymble shiny
execute if score @s gacha_pick matches 337 unless score @s gacha_shiny matches 1 run givepokemon @s nymble
execute if score @s gacha_pick matches 338 if score @s gacha_shiny matches 1 run givepokemon @s lokix shiny
execute if score @s gacha_pick matches 338 unless score @s gacha_shiny matches 1 run givepokemon @s lokix
execute if score @s gacha_pick matches 339 if score @s gacha_shiny matches 1 run givepokemon @s pawmi shiny
execute if score @s gacha_pick matches 339 unless score @s gacha_shiny matches 1 run givepokemon @s pawmi
execute if score @s gacha_pick matches 340 if score @s gacha_shiny matches 1 run givepokemon @s pawmo shiny
execute if score @s gacha_pick matches 340 unless score @s gacha_shiny matches 1 run givepokemon @s pawmo
execute if score @s gacha_pick matches 341 if score @s gacha_shiny matches 1 run givepokemon @s pawmot shiny
execute if score @s gacha_pick matches 341 unless score @s gacha_shiny matches 1 run givepokemon @s pawmot
execute if score @s gacha_pick matches 342 if score @s gacha_shiny matches 1 run givepokemon @s tandemaus shiny
execute if score @s gacha_pick matches 342 unless score @s gacha_shiny matches 1 run givepokemon @s tandemaus
execute if score @s gacha_pick matches 343 if score @s gacha_shiny matches 1 run givepokemon @s fidough shiny
execute if score @s gacha_pick matches 343 unless score @s gacha_shiny matches 1 run givepokemon @s fidough
execute if score @s gacha_pick matches 344 if score @s gacha_shiny matches 1 run givepokemon @s dolliv shiny
execute if score @s gacha_pick matches 344 unless score @s gacha_shiny matches 1 run givepokemon @s dolliv
execute if score @s gacha_pick matches 345 if score @s gacha_shiny matches 1 run givepokemon @s arboliva shiny
execute if score @s gacha_pick matches 345 unless score @s gacha_shiny matches 1 run givepokemon @s arboliva
execute if score @s gacha_pick matches 346 if score @s gacha_shiny matches 1 run givepokemon @s garganacl shiny
execute if score @s gacha_pick matches 346 unless score @s gacha_shiny matches 1 run givepokemon @s garganacl
execute if score @s gacha_pick matches 347 if score @s gacha_shiny matches 1 run givepokemon @s tadbulb shiny
execute if score @s gacha_pick matches 347 unless score @s gacha_shiny matches 1 run givepokemon @s tadbulb
execute if score @s gacha_pick matches 348 if score @s gacha_shiny matches 1 run givepokemon @s bellibolt shiny
execute if score @s gacha_pick matches 348 unless score @s gacha_shiny matches 1 run givepokemon @s bellibolt
execute if score @s gacha_pick matches 349 if score @s gacha_shiny matches 1 run givepokemon @s kilowattrel shiny
execute if score @s gacha_pick matches 349 unless score @s gacha_shiny matches 1 run givepokemon @s kilowattrel
execute if score @s gacha_pick matches 350 if score @s gacha_shiny matches 1 run givepokemon @s maschiff shiny
execute if score @s gacha_pick matches 350 unless score @s gacha_shiny matches 1 run givepokemon @s maschiff
execute if score @s gacha_pick matches 351 if score @s gacha_shiny matches 1 run givepokemon @s mabosstiff shiny
execute if score @s gacha_pick matches 351 unless score @s gacha_shiny matches 1 run givepokemon @s mabosstiff
execute if score @s gacha_pick matches 352 if score @s gacha_shiny matches 1 run givepokemon @s grafaiai shiny
execute if score @s gacha_pick matches 352 unless score @s gacha_shiny matches 1 run givepokemon @s grafaiai
execute if score @s gacha_pick matches 353 if score @s gacha_shiny matches 1 run givepokemon @s bramblin shiny
execute if score @s gacha_pick matches 353 unless score @s gacha_shiny matches 1 run givepokemon @s bramblin
execute if score @s gacha_pick matches 354 if score @s gacha_shiny matches 1 run givepokemon @s toedscruel shiny
execute if score @s gacha_pick matches 354 unless score @s gacha_shiny matches 1 run givepokemon @s toedscruel
execute if score @s gacha_pick matches 355 if score @s gacha_shiny matches 1 run givepokemon @s klawf shiny
execute if score @s gacha_pick matches 355 unless score @s gacha_shiny matches 1 run givepokemon @s klawf
execute if score @s gacha_pick matches 356 if score @s gacha_shiny matches 1 run givepokemon @s capsakid shiny
execute if score @s gacha_pick matches 356 unless score @s gacha_shiny matches 1 run givepokemon @s capsakid
execute if score @s gacha_pick matches 357 if score @s gacha_shiny matches 1 run givepokemon @s scovillain shiny
execute if score @s gacha_pick matches 357 unless score @s gacha_shiny matches 1 run givepokemon @s scovillain
execute if score @s gacha_pick matches 358 if score @s gacha_shiny matches 1 run givepokemon @s rellor shiny
execute if score @s gacha_pick matches 358 unless score @s gacha_shiny matches 1 run givepokemon @s rellor
execute if score @s gacha_pick matches 359 if score @s gacha_shiny matches 1 run givepokemon @s rabsca shiny
execute if score @s gacha_pick matches 359 unless score @s gacha_shiny matches 1 run givepokemon @s rabsca
execute if score @s gacha_pick matches 360 if score @s gacha_shiny matches 1 run givepokemon @s espathra shiny
execute if score @s gacha_pick matches 360 unless score @s gacha_shiny matches 1 run givepokemon @s espathra
execute if score @s gacha_pick matches 361 if score @s gacha_shiny matches 1 run givepokemon @s tinkatink shiny
execute if score @s gacha_pick matches 361 unless score @s gacha_shiny matches 1 run givepokemon @s tinkatink
execute if score @s gacha_pick matches 362 if score @s gacha_shiny matches 1 run givepokemon @s tinkaton shiny
execute if score @s gacha_pick matches 362 unless score @s gacha_shiny matches 1 run givepokemon @s tinkaton
execute if score @s gacha_pick matches 363 if score @s gacha_shiny matches 1 run givepokemon @s wugtrio shiny
execute if score @s gacha_pick matches 363 unless score @s gacha_shiny matches 1 run givepokemon @s wugtrio
execute if score @s gacha_pick matches 364 if score @s gacha_shiny matches 1 run givepokemon @s bombirdier shiny
execute if score @s gacha_pick matches 364 unless score @s gacha_shiny matches 1 run givepokemon @s bombirdier
execute if score @s gacha_pick matches 365 if score @s gacha_shiny matches 1 run givepokemon @s finizen shiny
execute if score @s gacha_pick matches 365 unless score @s gacha_shiny matches 1 run givepokemon @s finizen
execute if score @s gacha_pick matches 366 if score @s gacha_shiny matches 1 run givepokemon @s cyclizar shiny
execute if score @s gacha_pick matches 366 unless score @s gacha_shiny matches 1 run givepokemon @s cyclizar
execute if score @s gacha_pick matches 367 if score @s gacha_shiny matches 1 run givepokemon @s orthworm shiny
execute if score @s gacha_pick matches 367 unless score @s gacha_shiny matches 1 run givepokemon @s orthworm
execute if score @s gacha_pick matches 368 if score @s gacha_shiny matches 1 run givepokemon @s glimmet shiny
execute if score @s gacha_pick matches 368 unless score @s gacha_shiny matches 1 run givepokemon @s glimmet
execute if score @s gacha_pick matches 369 if score @s gacha_shiny matches 1 run givepokemon @s glimmora shiny
execute if score @s gacha_pick matches 369 unless score @s gacha_shiny matches 1 run givepokemon @s glimmora
execute if score @s gacha_pick matches 370 if score @s gacha_shiny matches 1 run givepokemon @s greavard shiny
execute if score @s gacha_pick matches 370 unless score @s gacha_shiny matches 1 run givepokemon @s greavard
execute if score @s gacha_pick matches 371 if score @s gacha_shiny matches 1 run givepokemon @s cetoddle shiny
execute if score @s gacha_pick matches 371 unless score @s gacha_shiny matches 1 run givepokemon @s cetoddle
execute if score @s gacha_pick matches 372 if score @s gacha_shiny matches 1 run givepokemon @s tatsugiri shiny
execute if score @s gacha_pick matches 372 unless score @s gacha_shiny matches 1 run givepokemon @s tatsugiri
execute if score @s gacha_pick matches 373 if score @s gacha_shiny matches 1 run givepokemon @s clodsire shiny
execute if score @s gacha_pick matches 373 unless score @s gacha_shiny matches 1 run givepokemon @s clodsire
execute if score @s gacha_pick matches 374 if score @s gacha_shiny matches 1 run givepokemon @s frigibax shiny
execute if score @s gacha_pick matches 374 unless score @s gacha_shiny matches 1 run givepokemon @s frigibax
execute if score @s gacha_pick matches 375 if score @s gacha_shiny matches 1 run givepokemon @s dipplin shiny
execute if score @s gacha_pick matches 375 unless score @s gacha_shiny matches 1 run givepokemon @s dipplin
execute if score @s gacha_pick matches 376 if score @s gacha_shiny matches 1 run givepokemon @s archaludon shiny
execute if score @s gacha_pick matches 376 unless score @s gacha_shiny matches 1 run givepokemon @s archaludon
tellraw @s {"text":"🎁 COMMON reward!","color":"white"}
