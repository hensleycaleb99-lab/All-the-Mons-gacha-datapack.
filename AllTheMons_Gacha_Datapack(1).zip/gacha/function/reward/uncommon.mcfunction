scoreboard players set @s gacha_pick 0
execute store result score @s gacha_pick run random roll 1..195
execute if score @s gacha_pick matches 1 if score @s gacha_shiny matches 1 run givepokemon @s wartortle shiny
execute if score @s gacha_pick matches 1 unless score @s gacha_shiny matches 1 run givepokemon @s wartortle
execute if score @s gacha_pick matches 2 if score @s gacha_shiny matches 1 run givepokemon @s weedle shiny
execute if score @s gacha_pick matches 2 unless score @s gacha_shiny matches 1 run givepokemon @s weedle
execute if score @s gacha_pick matches 3 if score @s gacha_shiny matches 1 run givepokemon @s pidgey shiny
execute if score @s gacha_pick matches 3 unless score @s gacha_shiny matches 1 run givepokemon @s pidgey
execute if score @s gacha_pick matches 4 if score @s gacha_shiny matches 1 run givepokemon @s pidgeotto shiny
execute if score @s gacha_pick matches 4 unless score @s gacha_shiny matches 1 run givepokemon @s pidgeotto
execute if score @s gacha_pick matches 5 if score @s gacha_shiny matches 1 run givepokemon @s rattata shiny
execute if score @s gacha_pick matches 5 unless score @s gacha_shiny matches 1 run givepokemon @s rattata
execute if score @s gacha_pick matches 6 if score @s gacha_shiny matches 1 run givepokemon @s pikachu shiny
execute if score @s gacha_pick matches 6 unless score @s gacha_shiny matches 1 run givepokemon @s pikachu
execute if score @s gacha_pick matches 7 if score @s gacha_shiny matches 1 run givepokemon @s sandshrew shiny
execute if score @s gacha_pick matches 7 unless score @s gacha_shiny matches 1 run givepokemon @s sandshrew
execute if score @s gacha_pick matches 8 if score @s gacha_shiny matches 1 run givepokemon @s nidoranf shiny
execute if score @s gacha_pick matches 8 unless score @s gacha_shiny matches 1 run givepokemon @s nidoranf
execute if score @s gacha_pick matches 9 if score @s gacha_shiny matches 1 run givepokemon @s nidorina shiny
execute if score @s gacha_pick matches 9 unless score @s gacha_shiny matches 1 run givepokemon @s nidorina
execute if score @s gacha_pick matches 10 if score @s gacha_shiny matches 1 run givepokemon @s meowth shiny
execute if score @s gacha_pick matches 10 unless score @s gacha_shiny matches 1 run givepokemon @s meowth
execute if score @s gacha_pick matches 11 if score @s gacha_shiny matches 1 run givepokemon @s psyduck shiny
execute if score @s gacha_pick matches 11 unless score @s gacha_shiny matches 1 run givepokemon @s psyduck
execute if score @s gacha_pick matches 12 if score @s gacha_shiny matches 1 run givepokemon @s mankey shiny
execute if score @s gacha_pick matches 12 unless score @s gacha_shiny matches 1 run givepokemon @s mankey
execute if score @s gacha_pick matches 13 if score @s gacha_shiny matches 1 run givepokemon @s growlithe shiny
execute if score @s gacha_pick matches 13 unless score @s gacha_shiny matches 1 run givepokemon @s growlithe
execute if score @s gacha_pick matches 14 if score @s gacha_shiny matches 1 run givepokemon @s tentacool shiny
execute if score @s gacha_pick matches 14 unless score @s gacha_shiny matches 1 run givepokemon @s tentacool
execute if score @s gacha_pick matches 15 if score @s gacha_shiny matches 1 run givepokemon @s magnemite shiny
execute if score @s gacha_pick matches 15 unless score @s gacha_shiny matches 1 run givepokemon @s magnemite
execute if score @s gacha_pick matches 16 if score @s gacha_shiny matches 1 run givepokemon @s gastly shiny
execute if score @s gacha_pick matches 16 unless score @s gacha_shiny matches 1 run givepokemon @s gastly
execute if score @s gacha_pick matches 17 if score @s gacha_shiny matches 1 run givepokemon @s haunter shiny
execute if score @s gacha_pick matches 17 unless score @s gacha_shiny matches 1 run givepokemon @s haunter
execute if score @s gacha_pick matches 18 if score @s gacha_shiny matches 1 run givepokemon @s drowzee shiny
execute if score @s gacha_pick matches 18 unless score @s gacha_shiny matches 1 run givepokemon @s drowzee
execute if score @s gacha_pick matches 19 if score @s gacha_shiny matches 1 run givepokemon @s cubone shiny
execute if score @s gacha_pick matches 19 unless score @s gacha_shiny matches 1 run givepokemon @s cubone
execute if score @s gacha_pick matches 20 if score @s gacha_shiny matches 1 run givepokemon @s hitmonchan shiny
execute if score @s gacha_pick matches 20 unless score @s gacha_shiny matches 1 run givepokemon @s hitmonchan
execute if score @s gacha_pick matches 21 if score @s gacha_shiny matches 1 run givepokemon @s tangela shiny
execute if score @s gacha_pick matches 21 unless score @s gacha_shiny matches 1 run givepokemon @s tangela
execute if score @s gacha_pick matches 22 if score @s gacha_shiny matches 1 run givepokemon @s kangaskhan shiny
execute if score @s gacha_pick matches 22 unless score @s gacha_shiny matches 1 run givepokemon @s kangaskhan
execute if score @s gacha_pick matches 23 if score @s gacha_shiny matches 1 run givepokemon @s horsea shiny
execute if score @s gacha_pick matches 23 unless score @s gacha_shiny matches 1 run givepokemon @s horsea
execute if score @s gacha_pick matches 24 if score @s gacha_shiny matches 1 run givepokemon @s seadra shiny
execute if score @s gacha_pick matches 24 unless score @s gacha_shiny matches 1 run givepokemon @s seadra
execute if score @s gacha_pick matches 25 if score @s gacha_shiny matches 1 run givepokemon @s eevee shiny
execute if score @s gacha_pick matches 25 unless score @s gacha_shiny matches 1 run givepokemon @s eevee
execute if score @s gacha_pick matches 26 if score @s gacha_shiny matches 1 run givepokemon @s omanyte shiny
execute if score @s gacha_pick matches 26 unless score @s gacha_shiny matches 1 run givepokemon @s omanyte
execute if score @s gacha_pick matches 27 if score @s gacha_shiny matches 1 run givepokemon @s omastar shiny
execute if score @s gacha_pick matches 27 unless score @s gacha_shiny matches 1 run givepokemon @s omastar
execute if score @s gacha_pick matches 28 if score @s gacha_shiny matches 1 run givepokemon @s kabutops shiny
execute if score @s gacha_pick matches 28 unless score @s gacha_shiny matches 1 run givepokemon @s kabutops
execute if score @s gacha_pick matches 29 if score @s gacha_shiny matches 1 run givepokemon @s dratini shiny
execute if score @s gacha_pick matches 29 unless score @s gacha_shiny matches 1 run givepokemon @s dratini
execute if score @s gacha_pick matches 30 if score @s gacha_shiny matches 1 run givepokemon @s dragonair shiny
execute if score @s gacha_pick matches 30 unless score @s gacha_shiny matches 1 run givepokemon @s dragonair
execute if score @s gacha_pick matches 31 if score @s gacha_shiny matches 1 run givepokemon @s chinchou shiny
execute if score @s gacha_pick matches 31 unless score @s gacha_shiny matches 1 run givepokemon @s chinchou
execute if score @s gacha_pick matches 32 if score @s gacha_shiny matches 1 run givepokemon @s pichu shiny
execute if score @s gacha_pick matches 32 unless score @s gacha_shiny matches 1 run givepokemon @s pichu
execute if score @s gacha_pick matches 33 if score @s gacha_shiny matches 1 run givepokemon @s cleffa shiny
execute if score @s gacha_pick matches 33 unless score @s gacha_shiny matches 1 run givepokemon @s cleffa
execute if score @s gacha_pick matches 34 if score @s gacha_shiny matches 1 run givepokemon @s togepi shiny
execute if score @s gacha_pick matches 34 unless score @s gacha_shiny matches 1 run givepokemon @s togepi
execute if score @s gacha_pick matches 35 if score @s gacha_shiny matches 1 run givepokemon @s xatu shiny
execute if score @s gacha_pick matches 35 unless score @s gacha_shiny matches 1 run givepokemon @s xatu
execute if score @s gacha_pick matches 36 if score @s gacha_shiny matches 1 run givepokemon @s flaaffy shiny
execute if score @s gacha_pick matches 36 unless score @s gacha_shiny matches 1 run givepokemon @s flaaffy
execute if score @s gacha_pick matches 37 if score @s gacha_shiny matches 1 run givepokemon @s aipom shiny
execute if score @s gacha_pick matches 37 unless score @s gacha_shiny matches 1 run givepokemon @s aipom
execute if score @s gacha_pick matches 38 if score @s gacha_shiny matches 1 run givepokemon @s sunkern shiny
execute if score @s gacha_pick matches 38 unless score @s gacha_shiny matches 1 run givepokemon @s sunkern
execute if score @s gacha_pick matches 39 if score @s gacha_shiny matches 1 run givepokemon @s yanma shiny
execute if score @s gacha_pick matches 39 unless score @s gacha_shiny matches 1 run givepokemon @s yanma
execute if score @s gacha_pick matches 40 if score @s gacha_shiny matches 1 run givepokemon @s unown shiny
execute if score @s gacha_pick matches 40 unless score @s gacha_shiny matches 1 run givepokemon @s unown
execute if score @s gacha_pick matches 41 if score @s gacha_shiny matches 1 run givepokemon @s gligar shiny
execute if score @s gacha_pick matches 41 unless score @s gacha_shiny matches 1 run givepokemon @s gligar
execute if score @s gacha_pick matches 42 if score @s gacha_shiny matches 1 run givepokemon @s sneasel shiny
execute if score @s gacha_pick matches 42 unless score @s gacha_shiny matches 1 run givepokemon @s sneasel
execute if score @s gacha_pick matches 43 if score @s gacha_shiny matches 1 run givepokemon @s delibird shiny
execute if score @s gacha_pick matches 43 unless score @s gacha_shiny matches 1 run givepokemon @s delibird
execute if score @s gacha_pick matches 44 if score @s gacha_shiny matches 1 run givepokemon @s skarmory shiny
execute if score @s gacha_pick matches 44 unless score @s gacha_shiny matches 1 run givepokemon @s skarmory
execute if score @s gacha_pick matches 45 if score @s gacha_shiny matches 1 run givepokemon @s tyrogue shiny
execute if score @s gacha_pick matches 45 unless score @s gacha_shiny matches 1 run givepokemon @s tyrogue
execute if score @s gacha_pick matches 46 if score @s gacha_shiny matches 1 run givepokemon @s magby shiny
execute if score @s gacha_pick matches 46 unless score @s gacha_shiny matches 1 run givepokemon @s magby
execute if score @s gacha_pick matches 47 if score @s gacha_shiny matches 1 run givepokemon @s marshtomp shiny
execute if score @s gacha_pick matches 47 unless score @s gacha_shiny matches 1 run givepokemon @s marshtomp
execute if score @s gacha_pick matches 48 if score @s gacha_shiny matches 1 run givepokemon @s poochyena shiny
execute if score @s gacha_pick matches 48 unless score @s gacha_shiny matches 1 run givepokemon @s poochyena
execute if score @s gacha_pick matches 49 if score @s gacha_shiny matches 1 run givepokemon @s zigzagoon shiny
execute if score @s gacha_pick matches 49 unless score @s gacha_shiny matches 1 run givepokemon @s zigzagoon
execute if score @s gacha_pick matches 50 if score @s gacha_shiny matches 1 run givepokemon @s wurmple shiny
execute if score @s gacha_pick matches 50 unless score @s gacha_shiny matches 1 run givepokemon @s wurmple
execute if score @s gacha_pick matches 51 if score @s gacha_shiny matches 1 run givepokemon @s silcoon shiny
execute if score @s gacha_pick matches 51 unless score @s gacha_shiny matches 1 run givepokemon @s silcoon
execute if score @s gacha_pick matches 52 if score @s gacha_shiny matches 1 run givepokemon @s kirlia shiny
execute if score @s gacha_pick matches 52 unless score @s gacha_shiny matches 1 run givepokemon @s kirlia
execute if score @s gacha_pick matches 53 if score @s gacha_shiny matches 1 run givepokemon @s surskit shiny
execute if score @s gacha_pick matches 53 unless score @s gacha_shiny matches 1 run givepokemon @s surskit
execute if score @s gacha_pick matches 54 if score @s gacha_shiny matches 1 run givepokemon @s vigoroth shiny
execute if score @s gacha_pick matches 54 unless score @s gacha_shiny matches 1 run givepokemon @s vigoroth
execute if score @s gacha_pick matches 55 if score @s gacha_shiny matches 1 run givepokemon @s ninjask shiny
execute if score @s gacha_pick matches 55 unless score @s gacha_shiny matches 1 run givepokemon @s ninjask
execute if score @s gacha_pick matches 56 if score @s gacha_shiny matches 1 run givepokemon @s whismur shiny
execute if score @s gacha_pick matches 56 unless score @s gacha_shiny matches 1 run givepokemon @s whismur
execute if score @s gacha_pick matches 57 if score @s gacha_shiny matches 1 run givepokemon @s makuhita shiny
execute if score @s gacha_pick matches 57 unless score @s gacha_shiny matches 1 run givepokemon @s makuhita
execute if score @s gacha_pick matches 58 if score @s gacha_shiny matches 1 run givepokemon @s azurill shiny
execute if score @s gacha_pick matches 58 unless score @s gacha_shiny matches 1 run givepokemon @s azurill
execute if score @s gacha_pick matches 59 if score @s gacha_shiny matches 1 run givepokemon @s nosepass shiny
execute if score @s gacha_pick matches 59 unless score @s gacha_shiny matches 1 run givepokemon @s nosepass
execute if score @s gacha_pick matches 60 if score @s gacha_shiny matches 1 run givepokemon @s sableye shiny
execute if score @s gacha_pick matches 60 unless score @s gacha_shiny matches 1 run givepokemon @s sableye
execute if score @s gacha_pick matches 61 if score @s gacha_shiny matches 1 run givepokemon @s mawile shiny
execute if score @s gacha_pick matches 61 unless score @s gacha_shiny matches 1 run givepokemon @s mawile
execute if score @s gacha_pick matches 62 if score @s gacha_shiny matches 1 run givepokemon @s aron shiny
execute if score @s gacha_pick matches 62 unless score @s gacha_shiny matches 1 run givepokemon @s aron
execute if score @s gacha_pick matches 63 if score @s gacha_shiny matches 1 run givepokemon @s lairon shiny
execute if score @s gacha_pick matches 63 unless score @s gacha_shiny matches 1 run givepokemon @s lairon
execute if score @s gacha_pick matches 64 if score @s gacha_shiny matches 1 run givepokemon @s swalot shiny
execute if score @s gacha_pick matches 64 unless score @s gacha_shiny matches 1 run givepokemon @s swalot
execute if score @s gacha_pick matches 65 if score @s gacha_shiny matches 1 run givepokemon @s wailmer shiny
execute if score @s gacha_pick matches 65 unless score @s gacha_shiny matches 1 run givepokemon @s wailmer
execute if score @s gacha_pick matches 66 if score @s gacha_shiny matches 1 run givepokemon @s spoink shiny
execute if score @s gacha_pick matches 66 unless score @s gacha_shiny matches 1 run givepokemon @s spoink
execute if score @s gacha_pick matches 67 if score @s gacha_shiny matches 1 run givepokemon @s spinda shiny
execute if score @s gacha_pick matches 67 unless score @s gacha_shiny matches 1 run givepokemon @s spinda
execute if score @s gacha_pick matches 68 if score @s gacha_shiny matches 1 run givepokemon @s vibrava shiny
execute if score @s gacha_pick matches 68 unless score @s gacha_shiny matches 1 run givepokemon @s vibrava
execute if score @s gacha_pick matches 69 if score @s gacha_shiny matches 1 run givepokemon @s cacnea shiny
execute if score @s gacha_pick matches 69 unless score @s gacha_shiny matches 1 run givepokemon @s cacnea
execute if score @s gacha_pick matches 70 if score @s gacha_shiny matches 1 run givepokemon @s swablu shiny
execute if score @s gacha_pick matches 70 unless score @s gacha_shiny matches 1 run givepokemon @s swablu
execute if score @s gacha_pick matches 71 if score @s gacha_shiny matches 1 run givepokemon @s zangoose shiny
execute if score @s gacha_pick matches 71 unless score @s gacha_shiny matches 1 run givepokemon @s zangoose
execute if score @s gacha_pick matches 72 if score @s gacha_shiny matches 1 run givepokemon @s lunatone shiny
execute if score @s gacha_pick matches 72 unless score @s gacha_shiny matches 1 run givepokemon @s lunatone
execute if score @s gacha_pick matches 73 if score @s gacha_shiny matches 1 run givepokemon @s solrock shiny
execute if score @s gacha_pick matches 73 unless score @s gacha_shiny matches 1 run givepokemon @s solrock
execute if score @s gacha_pick matches 74 if score @s gacha_shiny matches 1 run givepokemon @s corphish shiny
execute if score @s gacha_pick matches 74 unless score @s gacha_shiny matches 1 run givepokemon @s corphish
execute if score @s gacha_pick matches 75 if score @s gacha_shiny matches 1 run givepokemon @s baltoy shiny
execute if score @s gacha_pick matches 75 unless score @s gacha_shiny matches 1 run givepokemon @s baltoy
execute if score @s gacha_pick matches 76 if score @s gacha_shiny matches 1 run givepokemon @s shuppet shiny
execute if score @s gacha_pick matches 76 unless score @s gacha_shiny matches 1 run givepokemon @s shuppet
execute if score @s gacha_pick matches 77 if score @s gacha_shiny matches 1 run givepokemon @s sealeo shiny
execute if score @s gacha_pick matches 77 unless score @s gacha_shiny matches 1 run givepokemon @s sealeo
execute if score @s gacha_pick matches 78 if score @s gacha_shiny matches 1 run givepokemon @s luvdisc shiny
execute if score @s gacha_pick matches 78 unless score @s gacha_shiny matches 1 run givepokemon @s luvdisc
execute if score @s gacha_pick matches 79 if score @s gacha_shiny matches 1 run givepokemon @s bagon shiny
execute if score @s gacha_pick matches 79 unless score @s gacha_shiny matches 1 run givepokemon @s bagon
execute if score @s gacha_pick matches 80 if score @s gacha_shiny matches 1 run givepokemon @s beldum shiny
execute if score @s gacha_pick matches 80 unless score @s gacha_shiny matches 1 run givepokemon @s beldum
execute if score @s gacha_pick matches 81 if score @s gacha_shiny matches 1 run givepokemon @s metang shiny
execute if score @s gacha_pick matches 81 unless score @s gacha_shiny matches 1 run givepokemon @s metang
execute if score @s gacha_pick matches 82 if score @s gacha_shiny matches 1 run givepokemon @s chimchar shiny
execute if score @s gacha_pick matches 82 unless score @s gacha_shiny matches 1 run givepokemon @s chimchar
execute if score @s gacha_pick matches 83 if score @s gacha_shiny matches 1 run givepokemon @s piplup shiny
execute if score @s gacha_pick matches 83 unless score @s gacha_shiny matches 1 run givepokemon @s piplup
execute if score @s gacha_pick matches 84 if score @s gacha_shiny matches 1 run givepokemon @s bidoof shiny
execute if score @s gacha_pick matches 84 unless score @s gacha_shiny matches 1 run givepokemon @s bidoof
execute if score @s gacha_pick matches 85 if score @s gacha_shiny matches 1 run givepokemon @s kricketune shiny
execute if score @s gacha_pick matches 85 unless score @s gacha_shiny matches 1 run givepokemon @s kricketune
execute if score @s gacha_pick matches 86 if score @s gacha_shiny matches 1 run givepokemon @s luxio shiny
execute if score @s gacha_pick matches 86 unless score @s gacha_shiny matches 1 run givepokemon @s luxio
execute if score @s gacha_pick matches 87 if score @s gacha_shiny matches 1 run givepokemon @s buizel shiny
execute if score @s gacha_pick matches 87 unless score @s gacha_shiny matches 1 run givepokemon @s buizel
execute if score @s gacha_pick matches 88 if score @s gacha_shiny matches 1 run givepokemon @s cherubi shiny
execute if score @s gacha_pick matches 88 unless score @s gacha_shiny matches 1 run givepokemon @s cherubi
execute if score @s gacha_pick matches 89 if score @s gacha_shiny matches 1 run givepokemon @s shellos shiny
execute if score @s gacha_pick matches 89 unless score @s gacha_shiny matches 1 run givepokemon @s shellos
execute if score @s gacha_pick matches 90 if score @s gacha_shiny matches 1 run givepokemon @s drifloon shiny
execute if score @s gacha_pick matches 90 unless score @s gacha_shiny matches 1 run givepokemon @s drifloon
execute if score @s gacha_pick matches 91 if score @s gacha_shiny matches 1 run givepokemon @s mismagius shiny
execute if score @s gacha_pick matches 91 unless score @s gacha_shiny matches 1 run givepokemon @s mismagius
execute if score @s gacha_pick matches 92 if score @s gacha_shiny matches 1 run givepokemon @s bronzor shiny
execute if score @s gacha_pick matches 92 unless score @s gacha_shiny matches 1 run givepokemon @s bronzor
execute if score @s gacha_pick matches 93 if score @s gacha_shiny matches 1 run givepokemon @s bonsly shiny
execute if score @s gacha_pick matches 93 unless score @s gacha_shiny matches 1 run givepokemon @s bonsly
execute if score @s gacha_pick matches 94 if score @s gacha_shiny matches 1 run givepokemon @s munchlax shiny
execute if score @s gacha_pick matches 94 unless score @s gacha_shiny matches 1 run givepokemon @s munchlax
execute if score @s gacha_pick matches 95 if score @s gacha_shiny matches 1 run givepokemon @s riolu shiny
execute if score @s gacha_pick matches 95 unless score @s gacha_shiny matches 1 run givepokemon @s riolu
execute if score @s gacha_pick matches 96 if score @s gacha_shiny matches 1 run givepokemon @s hippopotas shiny
execute if score @s gacha_pick matches 96 unless score @s gacha_shiny matches 1 run givepokemon @s hippopotas
execute if score @s gacha_pick matches 97 if score @s gacha_shiny matches 1 run givepokemon @s croagunk shiny
execute if score @s gacha_pick matches 97 unless score @s gacha_shiny matches 1 run givepokemon @s croagunk
execute if score @s gacha_pick matches 98 if score @s gacha_shiny matches 1 run givepokemon @s snover shiny
execute if score @s gacha_pick matches 98 unless score @s gacha_shiny matches 1 run givepokemon @s snover
execute if score @s gacha_pick matches 99 if score @s gacha_shiny matches 1 run givepokemon @s glaceon shiny
execute if score @s gacha_pick matches 99 unless score @s gacha_shiny matches 1 run givepokemon @s glaceon
execute if score @s gacha_pick matches 100 if score @s gacha_shiny matches 1 run givepokemon @s tepig shiny
execute if score @s gacha_pick matches 100 unless score @s gacha_shiny matches 1 run givepokemon @s tepig
execute if score @s gacha_pick matches 101 if score @s gacha_shiny matches 1 run givepokemon @s dewott shiny
execute if score @s gacha_pick matches 101 unless score @s gacha_shiny matches 1 run givepokemon @s dewott
execute if score @s gacha_pick matches 102 if score @s gacha_shiny matches 1 run givepokemon @s purrloin shiny
execute if score @s gacha_pick matches 102 unless score @s gacha_shiny matches 1 run givepokemon @s purrloin
execute if score @s gacha_pick matches 103 if score @s gacha_shiny matches 1 run givepokemon @s pansage shiny
execute if score @s gacha_pick matches 103 unless score @s gacha_shiny matches 1 run givepokemon @s pansage
execute if score @s gacha_pick matches 104 if score @s gacha_shiny matches 1 run givepokemon @s munna shiny
execute if score @s gacha_pick matches 104 unless score @s gacha_shiny matches 1 run givepokemon @s munna
execute if score @s gacha_pick matches 105 if score @s gacha_shiny matches 1 run givepokemon @s drilbur shiny
execute if score @s gacha_pick matches 105 unless score @s gacha_shiny matches 1 run givepokemon @s drilbur
execute if score @s gacha_pick matches 106 if score @s gacha_shiny matches 1 run givepokemon @s throh shiny
execute if score @s gacha_pick matches 106 unless score @s gacha_shiny matches 1 run givepokemon @s throh
execute if score @s gacha_pick matches 107 if score @s gacha_shiny matches 1 run givepokemon @s sawk shiny
execute if score @s gacha_pick matches 107 unless score @s gacha_shiny matches 1 run givepokemon @s sawk
execute if score @s gacha_pick matches 108 if score @s gacha_shiny matches 1 run givepokemon @s basculin shiny
execute if score @s gacha_pick matches 108 unless score @s gacha_shiny matches 1 run givepokemon @s basculin
execute if score @s gacha_pick matches 109 if score @s gacha_shiny matches 1 run givepokemon @s krokorok shiny
execute if score @s gacha_pick matches 109 unless score @s gacha_shiny matches 1 run givepokemon @s krokorok
execute if score @s gacha_pick matches 110 if score @s gacha_shiny matches 1 run givepokemon @s maractus shiny
execute if score @s gacha_pick matches 110 unless score @s gacha_shiny matches 1 run givepokemon @s maractus
execute if score @s gacha_pick matches 111 if score @s gacha_shiny matches 1 run givepokemon @s sigilyph shiny
execute if score @s gacha_pick matches 111 unless score @s gacha_shiny matches 1 run givepokemon @s sigilyph
execute if score @s gacha_pick matches 112 if score @s gacha_shiny matches 1 run givepokemon @s tirtouga shiny
execute if score @s gacha_pick matches 112 unless score @s gacha_shiny matches 1 run givepokemon @s tirtouga
execute if score @s gacha_pick matches 113 if score @s gacha_shiny matches 1 run givepokemon @s trubbish shiny
execute if score @s gacha_pick matches 113 unless score @s gacha_shiny matches 1 run givepokemon @s trubbish
execute if score @s gacha_pick matches 114 if score @s gacha_shiny matches 1 run givepokemon @s zorua shiny
execute if score @s gacha_pick matches 114 unless score @s gacha_shiny matches 1 run givepokemon @s zorua
execute if score @s gacha_pick matches 115 if score @s gacha_shiny matches 1 run givepokemon @s solosis shiny
execute if score @s gacha_pick matches 115 unless score @s gacha_shiny matches 1 run givepokemon @s solosis
execute if score @s gacha_pick matches 116 if score @s gacha_shiny matches 1 run givepokemon @s ducklett shiny
execute if score @s gacha_pick matches 116 unless score @s gacha_shiny matches 1 run givepokemon @s ducklett
execute if score @s gacha_pick matches 117 if score @s gacha_shiny matches 1 run givepokemon @s frillish shiny
execute if score @s gacha_pick matches 117 unless score @s gacha_shiny matches 1 run givepokemon @s frillish
execute if score @s gacha_pick matches 118 if score @s gacha_shiny matches 1 run givepokemon @s klink shiny
execute if score @s gacha_pick matches 118 unless score @s gacha_shiny matches 1 run givepokemon @s klink
execute if score @s gacha_pick matches 119 if score @s gacha_shiny matches 1 run givepokemon @s klang shiny
execute if score @s gacha_pick matches 119 unless score @s gacha_shiny matches 1 run givepokemon @s klang
execute if score @s gacha_pick matches 120 if score @s gacha_shiny matches 1 run givepokemon @s eelektrik shiny
execute if score @s gacha_pick matches 120 unless score @s gacha_shiny matches 1 run givepokemon @s eelektrik
execute if score @s gacha_pick matches 121 if score @s gacha_shiny matches 1 run givepokemon @s litwick shiny
execute if score @s gacha_pick matches 121 unless score @s gacha_shiny matches 1 run givepokemon @s litwick
execute if score @s gacha_pick matches 122 if score @s gacha_shiny matches 1 run givepokemon @s lampent shiny
execute if score @s gacha_pick matches 122 unless score @s gacha_shiny matches 1 run givepokemon @s lampent
execute if score @s gacha_pick matches 123 if score @s gacha_shiny matches 1 run givepokemon @s fraxure shiny
execute if score @s gacha_pick matches 123 unless score @s gacha_shiny matches 1 run givepokemon @s fraxure
execute if score @s gacha_pick matches 124 if score @s gacha_shiny matches 1 run givepokemon @s druddigon shiny
execute if score @s gacha_pick matches 124 unless score @s gacha_shiny matches 1 run givepokemon @s druddigon
execute if score @s gacha_pick matches 125 if score @s gacha_shiny matches 1 run givepokemon @s durant shiny
execute if score @s gacha_pick matches 125 unless score @s gacha_shiny matches 1 run givepokemon @s durant
execute if score @s gacha_pick matches 126 if score @s gacha_shiny matches 1 run givepokemon @s quilladin shiny
execute if score @s gacha_pick matches 126 unless score @s gacha_shiny matches 1 run givepokemon @s quilladin
execute if score @s gacha_pick matches 127 if score @s gacha_shiny matches 1 run givepokemon @s fennekin shiny
execute if score @s gacha_pick matches 127 unless score @s gacha_shiny matches 1 run givepokemon @s fennekin
execute if score @s gacha_pick matches 128 if score @s gacha_shiny matches 1 run givepokemon @s fletchling shiny
execute if score @s gacha_pick matches 128 unless score @s gacha_shiny matches 1 run givepokemon @s fletchling
execute if score @s gacha_pick matches 129 if score @s gacha_shiny matches 1 run givepokemon @s flabebe shiny
execute if score @s gacha_pick matches 129 unless score @s gacha_shiny matches 1 run givepokemon @s flabebe
execute if score @s gacha_pick matches 130 if score @s gacha_shiny matches 1 run givepokemon @s furfrou shiny
execute if score @s gacha_pick matches 130 unless score @s gacha_shiny matches 1 run givepokemon @s furfrou
execute if score @s gacha_pick matches 131 if score @s gacha_shiny matches 1 run givepokemon @s swirlix shiny
execute if score @s gacha_pick matches 131 unless score @s gacha_shiny matches 1 run givepokemon @s swirlix
execute if score @s gacha_pick matches 132 if score @s gacha_shiny matches 1 run givepokemon @s inkay shiny
execute if score @s gacha_pick matches 132 unless score @s gacha_shiny matches 1 run givepokemon @s inkay
execute if score @s gacha_pick matches 133 if score @s gacha_shiny matches 1 run givepokemon @s skrelp shiny
execute if score @s gacha_pick matches 133 unless score @s gacha_shiny matches 1 run givepokemon @s skrelp
execute if score @s gacha_pick matches 134 if score @s gacha_shiny matches 1 run givepokemon @s helioptile shiny
execute if score @s gacha_pick matches 134 unless score @s gacha_shiny matches 1 run givepokemon @s helioptile
execute if score @s gacha_pick matches 135 if score @s gacha_shiny matches 1 run givepokemon @s dedenne shiny
execute if score @s gacha_pick matches 135 unless score @s gacha_shiny matches 1 run givepokemon @s dedenne
execute if score @s gacha_pick matches 136 if score @s gacha_shiny matches 1 run givepokemon @s goomy shiny
execute if score @s gacha_pick matches 136 unless score @s gacha_shiny matches 1 run givepokemon @s goomy
execute if score @s gacha_pick matches 137 if score @s gacha_shiny matches 1 run givepokemon @s sliggoo shiny
execute if score @s gacha_pick matches 137 unless score @s gacha_shiny matches 1 run givepokemon @s sliggoo
execute if score @s gacha_pick matches 138 if score @s gacha_shiny matches 1 run givepokemon @s rowlet shiny
execute if score @s gacha_pick matches 138 unless score @s gacha_shiny matches 1 run givepokemon @s rowlet
execute if score @s gacha_pick matches 139 if score @s gacha_shiny matches 1 run givepokemon @s torracat shiny
execute if score @s gacha_pick matches 139 unless score @s gacha_shiny matches 1 run givepokemon @s torracat
execute if score @s gacha_pick matches 140 if score @s gacha_shiny matches 1 run givepokemon @s popplio shiny
execute if score @s gacha_pick matches 140 unless score @s gacha_shiny matches 1 run givepokemon @s popplio
execute if score @s gacha_pick matches 141 if score @s gacha_shiny matches 1 run givepokemon @s oricorio shiny
execute if score @s gacha_pick matches 141 unless score @s gacha_shiny matches 1 run givepokemon @s oricorio
execute if score @s gacha_pick matches 142 if score @s gacha_shiny matches 1 run givepokemon @s ribombee shiny
execute if score @s gacha_pick matches 142 unless score @s gacha_shiny matches 1 run givepokemon @s ribombee
execute if score @s gacha_pick matches 143 if score @s gacha_shiny matches 1 run givepokemon @s mareanie shiny
execute if score @s gacha_pick matches 143 unless score @s gacha_shiny matches 1 run givepokemon @s mareanie
execute if score @s gacha_pick matches 144 if score @s gacha_shiny matches 1 run givepokemon @s mudbray shiny
execute if score @s gacha_pick matches 144 unless score @s gacha_shiny matches 1 run givepokemon @s mudbray
execute if score @s gacha_pick matches 145 if score @s gacha_shiny matches 1 run givepokemon @s dewpider shiny
execute if score @s gacha_pick matches 145 unless score @s gacha_shiny matches 1 run givepokemon @s dewpider
execute if score @s gacha_pick matches 146 if score @s gacha_shiny matches 1 run givepokemon @s morelull shiny
execute if score @s gacha_pick matches 146 unless score @s gacha_shiny matches 1 run givepokemon @s morelull
execute if score @s gacha_pick matches 147 if score @s gacha_shiny matches 1 run givepokemon @s stufful shiny
execute if score @s gacha_pick matches 147 unless score @s gacha_shiny matches 1 run givepokemon @s stufful
execute if score @s gacha_pick matches 148 if score @s gacha_shiny matches 1 run givepokemon @s minior shiny
execute if score @s gacha_pick matches 148 unless score @s gacha_shiny matches 1 run givepokemon @s minior
execute if score @s gacha_pick matches 149 if score @s gacha_shiny matches 1 run givepokemon @s turtonator shiny
execute if score @s gacha_pick matches 149 unless score @s gacha_shiny matches 1 run givepokemon @s turtonator
execute if score @s gacha_pick matches 150 if score @s gacha_shiny matches 1 run givepokemon @s jangmo-o shiny
execute if score @s gacha_pick matches 150 unless score @s gacha_shiny matches 1 run givepokemon @s jangmo-o
execute if score @s gacha_pick matches 151 if score @s gacha_shiny matches 1 run givepokemon @s grookey shiny
execute if score @s gacha_pick matches 151 unless score @s gacha_shiny matches 1 run givepokemon @s grookey
execute if score @s gacha_pick matches 152 if score @s gacha_shiny matches 1 run givepokemon @s thwackey shiny
execute if score @s gacha_pick matches 152 unless score @s gacha_shiny matches 1 run givepokemon @s thwackey
execute if score @s gacha_pick matches 153 if score @s gacha_shiny matches 1 run givepokemon @s corvisquire shiny
execute if score @s gacha_pick matches 153 unless score @s gacha_shiny matches 1 run givepokemon @s corvisquire
execute if score @s gacha_pick matches 154 if score @s gacha_shiny matches 1 run givepokemon @s blipbug shiny
execute if score @s gacha_pick matches 154 unless score @s gacha_shiny matches 1 run givepokemon @s blipbug
execute if score @s gacha_pick matches 155 if score @s gacha_shiny matches 1 run givepokemon @s nickit shiny
execute if score @s gacha_pick matches 155 unless score @s gacha_shiny matches 1 run givepokemon @s nickit
execute if score @s gacha_pick matches 156 if score @s gacha_shiny matches 1 run givepokemon @s yamper shiny
execute if score @s gacha_pick matches 156 unless score @s gacha_shiny matches 1 run givepokemon @s yamper
execute if score @s gacha_pick matches 157 if score @s gacha_shiny matches 1 run givepokemon @s carkol shiny
execute if score @s gacha_pick matches 157 unless score @s gacha_shiny matches 1 run givepokemon @s carkol
execute if score @s gacha_pick matches 158 if score @s gacha_shiny matches 1 run givepokemon @s clobbopus shiny
execute if score @s gacha_pick matches 158 unless score @s gacha_shiny matches 1 run givepokemon @s clobbopus
execute if score @s gacha_pick matches 159 if score @s gacha_shiny matches 1 run givepokemon @s sinistea shiny
execute if score @s gacha_pick matches 159 unless score @s gacha_shiny matches 1 run givepokemon @s sinistea
execute if score @s gacha_pick matches 160 if score @s gacha_shiny matches 1 run givepokemon @s hatenna shiny
execute if score @s gacha_pick matches 160 unless score @s gacha_shiny matches 1 run givepokemon @s hatenna
execute if score @s gacha_pick matches 161 if score @s gacha_shiny matches 1 run givepokemon @s falinks shiny
execute if score @s gacha_pick matches 161 unless score @s gacha_shiny matches 1 run givepokemon @s falinks
execute if score @s gacha_pick matches 162 if score @s gacha_shiny matches 1 run givepokemon @s indeedee shiny
execute if score @s gacha_pick matches 162 unless score @s gacha_shiny matches 1 run givepokemon @s indeedee
execute if score @s gacha_pick matches 163 if score @s gacha_shiny matches 1 run givepokemon @s morpeko shiny
execute if score @s gacha_pick matches 163 unless score @s gacha_shiny matches 1 run givepokemon @s morpeko
execute if score @s gacha_pick matches 164 if score @s gacha_shiny matches 1 run givepokemon @s dracozolt shiny
execute if score @s gacha_pick matches 164 unless score @s gacha_shiny matches 1 run givepokemon @s dracozolt
execute if score @s gacha_pick matches 165 if score @s gacha_shiny matches 1 run givepokemon @s dracovish shiny
execute if score @s gacha_pick matches 165 unless score @s gacha_shiny matches 1 run givepokemon @s dracovish
execute if score @s gacha_pick matches 166 if score @s gacha_shiny matches 1 run givepokemon @s kleavor shiny
execute if score @s gacha_pick matches 166 unless score @s gacha_shiny matches 1 run givepokemon @s kleavor
execute if score @s gacha_pick matches 167 if score @s gacha_shiny matches 1 run givepokemon @s oinkologne shiny
execute if score @s gacha_pick matches 167 unless score @s gacha_shiny matches 1 run givepokemon @s oinkologne
execute if score @s gacha_pick matches 168 if score @s gacha_shiny matches 1 run givepokemon @s maushold shiny
execute if score @s gacha_pick matches 168 unless score @s gacha_shiny matches 1 run givepokemon @s maushold
execute if score @s gacha_pick matches 169 if score @s gacha_shiny matches 1 run givepokemon @s dachsbun shiny
execute if score @s gacha_pick matches 169 unless score @s gacha_shiny matches 1 run givepokemon @s dachsbun
execute if score @s gacha_pick matches 170 if score @s gacha_shiny matches 1 run givepokemon @s smoliv shiny
execute if score @s gacha_pick matches 170 unless score @s gacha_shiny matches 1 run givepokemon @s smoliv
execute if score @s gacha_pick matches 171 if score @s gacha_shiny matches 1 run givepokemon @s squawkabilly shiny
execute if score @s gacha_pick matches 171 unless score @s gacha_shiny matches 1 run givepokemon @s squawkabilly
execute if score @s gacha_pick matches 172 if score @s gacha_shiny matches 1 run givepokemon @s nacli shiny
execute if score @s gacha_pick matches 172 unless score @s gacha_shiny matches 1 run givepokemon @s nacli
execute if score @s gacha_pick matches 173 if score @s gacha_shiny matches 1 run givepokemon @s naclstack shiny
execute if score @s gacha_pick matches 173 unless score @s gacha_shiny matches 1 run givepokemon @s naclstack
execute if score @s gacha_pick matches 174 if score @s gacha_shiny matches 1 run givepokemon @s charcadet shiny
execute if score @s gacha_pick matches 174 unless score @s gacha_shiny matches 1 run givepokemon @s charcadet
execute if score @s gacha_pick matches 175 if score @s gacha_shiny matches 1 run givepokemon @s wattrel shiny
execute if score @s gacha_pick matches 175 unless score @s gacha_shiny matches 1 run givepokemon @s wattrel
execute if score @s gacha_pick matches 176 if score @s gacha_shiny matches 1 run givepokemon @s shroodle shiny
execute if score @s gacha_pick matches 176 unless score @s gacha_shiny matches 1 run givepokemon @s shroodle
execute if score @s gacha_pick matches 177 if score @s gacha_shiny matches 1 run givepokemon @s brambleghast shiny
execute if score @s gacha_pick matches 177 unless score @s gacha_shiny matches 1 run givepokemon @s brambleghast
execute if score @s gacha_pick matches 178 if score @s gacha_shiny matches 1 run givepokemon @s toedscool shiny
execute if score @s gacha_pick matches 178 unless score @s gacha_shiny matches 1 run givepokemon @s toedscool
execute if score @s gacha_pick matches 179 if score @s gacha_shiny matches 1 run givepokemon @s flittle shiny
execute if score @s gacha_pick matches 179 unless score @s gacha_shiny matches 1 run givepokemon @s flittle
execute if score @s gacha_pick matches 180 if score @s gacha_shiny matches 1 run givepokemon @s tinkatuff shiny
execute if score @s gacha_pick matches 180 unless score @s gacha_shiny matches 1 run givepokemon @s tinkatuff
execute if score @s gacha_pick matches 181 if score @s gacha_shiny matches 1 run givepokemon @s wiglett shiny
execute if score @s gacha_pick matches 181 unless score @s gacha_shiny matches 1 run givepokemon @s wiglett
execute if score @s gacha_pick matches 182 if score @s gacha_shiny matches 1 run givepokemon @s varoom shiny
execute if score @s gacha_pick matches 182 unless score @s gacha_shiny matches 1 run givepokemon @s varoom
execute if score @s gacha_pick matches 183 if score @s gacha_shiny matches 1 run givepokemon @s revavroom shiny
execute if score @s gacha_pick matches 183 unless score @s gacha_shiny matches 1 run givepokemon @s revavroom
execute if score @s gacha_pick matches 184 if score @s gacha_shiny matches 1 run givepokemon @s houndstone shiny
execute if score @s gacha_pick matches 184 unless score @s gacha_shiny matches 1 run givepokemon @s houndstone
execute if score @s gacha_pick matches 185 if score @s gacha_shiny matches 1 run givepokemon @s flamigo shiny
execute if score @s gacha_pick matches 185 unless score @s gacha_shiny matches 1 run givepokemon @s flamigo
execute if score @s gacha_pick matches 186 if score @s gacha_shiny matches 1 run givepokemon @s cetitan shiny
execute if score @s gacha_pick matches 186 unless score @s gacha_shiny matches 1 run givepokemon @s cetitan
execute if score @s gacha_pick matches 187 if score @s gacha_shiny matches 1 run givepokemon @s veluza shiny
execute if score @s gacha_pick matches 187 unless score @s gacha_shiny matches 1 run givepokemon @s veluza
execute if score @s gacha_pick matches 188 if score @s gacha_shiny matches 1 run givepokemon @s dondozo shiny
execute if score @s gacha_pick matches 188 unless score @s gacha_shiny matches 1 run givepokemon @s dondozo
execute if score @s gacha_pick matches 189 if score @s gacha_shiny matches 1 run givepokemon @s farigiraf shiny
execute if score @s gacha_pick matches 189 unless score @s gacha_shiny matches 1 run givepokemon @s farigiraf
execute if score @s gacha_pick matches 190 if score @s gacha_shiny matches 1 run givepokemon @s dudunsparce shiny
execute if score @s gacha_pick matches 190 unless score @s gacha_shiny matches 1 run givepokemon @s dudunsparce
execute if score @s gacha_pick matches 191 if score @s gacha_shiny matches 1 run givepokemon @s arctibax shiny
execute if score @s gacha_pick matches 191 unless score @s gacha_shiny matches 1 run givepokemon @s arctibax
execute if score @s gacha_pick matches 192 if score @s gacha_shiny matches 1 run givepokemon @s gimmighoul shiny
execute if score @s gacha_pick matches 192 unless score @s gacha_shiny matches 1 run givepokemon @s gimmighoul
execute if score @s gacha_pick matches 193 if score @s gacha_shiny matches 1 run givepokemon @s poltchageist shiny
execute if score @s gacha_pick matches 193 unless score @s gacha_shiny matches 1 run givepokemon @s poltchageist
execute if score @s gacha_pick matches 194 if score @s gacha_shiny matches 1 run givepokemon @s sinistcha shiny
execute if score @s gacha_pick matches 194 unless score @s gacha_shiny matches 1 run givepokemon @s sinistcha
execute if score @s gacha_pick matches 195 if score @s gacha_shiny matches 1 run givepokemon @s hydrapple shiny
execute if score @s gacha_pick matches 195 unless score @s gacha_shiny matches 1 run givepokemon @s hydrapple
tellraw @s {"text":"🎁 UNCOMMON reward!","color":"white"}
