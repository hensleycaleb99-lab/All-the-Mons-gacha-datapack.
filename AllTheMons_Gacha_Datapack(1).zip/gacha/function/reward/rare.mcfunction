scoreboard players set @s gacha_pick 0
execute store result score @s gacha_pick run random roll 1..291
execute if score @s gacha_pick matches 1 if score @s gacha_shiny matches 1 run givepokemon @s bulbasaur shiny
execute if score @s gacha_pick matches 1 unless score @s gacha_shiny matches 1 run givepokemon @s bulbasaur
execute if score @s gacha_pick matches 2 if score @s gacha_shiny matches 1 run givepokemon @s ivysaur shiny
execute if score @s gacha_pick matches 2 unless score @s gacha_shiny matches 1 run givepokemon @s ivysaur
execute if score @s gacha_pick matches 3 if score @s gacha_shiny matches 1 run givepokemon @s venusaur shiny
execute if score @s gacha_pick matches 3 unless score @s gacha_shiny matches 1 run givepokemon @s venusaur
execute if score @s gacha_pick matches 4 if score @s gacha_shiny matches 1 run givepokemon @s charizard shiny
execute if score @s gacha_pick matches 4 unless score @s gacha_shiny matches 1 run givepokemon @s charizard
execute if score @s gacha_pick matches 5 if score @s gacha_shiny matches 1 run givepokemon @s blastoise shiny
execute if score @s gacha_pick matches 5 unless score @s gacha_shiny matches 1 run givepokemon @s blastoise
execute if score @s gacha_pick matches 6 if score @s gacha_shiny matches 1 run givepokemon @s butterfree shiny
execute if score @s gacha_pick matches 6 unless score @s gacha_shiny matches 1 run givepokemon @s butterfree
execute if score @s gacha_pick matches 7 if score @s gacha_shiny matches 1 run givepokemon @s beedrill shiny
execute if score @s gacha_pick matches 7 unless score @s gacha_shiny matches 1 run givepokemon @s beedrill
execute if score @s gacha_pick matches 8 if score @s gacha_shiny matches 1 run givepokemon @s pidgeot shiny
execute if score @s gacha_pick matches 8 unless score @s gacha_shiny matches 1 run givepokemon @s pidgeot
execute if score @s gacha_pick matches 9 if score @s gacha_shiny matches 1 run givepokemon @s raticate shiny
execute if score @s gacha_pick matches 9 unless score @s gacha_shiny matches 1 run givepokemon @s raticate
execute if score @s gacha_pick matches 10 if score @s gacha_shiny matches 1 run givepokemon @s fearow shiny
execute if score @s gacha_pick matches 10 unless score @s gacha_shiny matches 1 run givepokemon @s fearow
execute if score @s gacha_pick matches 11 if score @s gacha_shiny matches 1 run givepokemon @s arbok shiny
execute if score @s gacha_pick matches 11 unless score @s gacha_shiny matches 1 run givepokemon @s arbok
execute if score @s gacha_pick matches 12 if score @s gacha_shiny matches 1 run givepokemon @s raichu shiny
execute if score @s gacha_pick matches 12 unless score @s gacha_shiny matches 1 run givepokemon @s raichu
execute if score @s gacha_pick matches 13 if score @s gacha_shiny matches 1 run givepokemon @s sandslash shiny
execute if score @s gacha_pick matches 13 unless score @s gacha_shiny matches 1 run givepokemon @s sandslash
execute if score @s gacha_pick matches 14 if score @s gacha_shiny matches 1 run givepokemon @s nidoqueen shiny
execute if score @s gacha_pick matches 14 unless score @s gacha_shiny matches 1 run givepokemon @s nidoqueen
execute if score @s gacha_pick matches 15 if score @s gacha_shiny matches 1 run givepokemon @s nidoking shiny
execute if score @s gacha_pick matches 15 unless score @s gacha_shiny matches 1 run givepokemon @s nidoking
execute if score @s gacha_pick matches 16 if score @s gacha_shiny matches 1 run givepokemon @s clefable shiny
execute if score @s gacha_pick matches 16 unless score @s gacha_shiny matches 1 run givepokemon @s clefable
execute if score @s gacha_pick matches 17 if score @s gacha_shiny matches 1 run givepokemon @s ninetales shiny
execute if score @s gacha_pick matches 17 unless score @s gacha_shiny matches 1 run givepokemon @s ninetales
execute if score @s gacha_pick matches 18 if score @s gacha_shiny matches 1 run givepokemon @s wigglytuff shiny
execute if score @s gacha_pick matches 18 unless score @s gacha_shiny matches 1 run givepokemon @s wigglytuff
execute if score @s gacha_pick matches 19 if score @s gacha_shiny matches 1 run givepokemon @s golbat shiny
execute if score @s gacha_pick matches 19 unless score @s gacha_shiny matches 1 run givepokemon @s golbat
execute if score @s gacha_pick matches 20 if score @s gacha_shiny matches 1 run givepokemon @s vileplume shiny
execute if score @s gacha_pick matches 20 unless score @s gacha_shiny matches 1 run givepokemon @s vileplume
execute if score @s gacha_pick matches 21 if score @s gacha_shiny matches 1 run givepokemon @s parasect shiny
execute if score @s gacha_pick matches 21 unless score @s gacha_shiny matches 1 run givepokemon @s parasect
execute if score @s gacha_pick matches 22 if score @s gacha_shiny matches 1 run givepokemon @s venomoth shiny
execute if score @s gacha_pick matches 22 unless score @s gacha_shiny matches 1 run givepokemon @s venomoth
execute if score @s gacha_pick matches 23 if score @s gacha_shiny matches 1 run givepokemon @s dugtrio shiny
execute if score @s gacha_pick matches 23 unless score @s gacha_shiny matches 1 run givepokemon @s dugtrio
execute if score @s gacha_pick matches 24 if score @s gacha_shiny matches 1 run givepokemon @s persian shiny
execute if score @s gacha_pick matches 24 unless score @s gacha_shiny matches 1 run givepokemon @s persian
execute if score @s gacha_pick matches 25 if score @s gacha_shiny matches 1 run givepokemon @s golduck shiny
execute if score @s gacha_pick matches 25 unless score @s gacha_shiny matches 1 run givepokemon @s golduck
execute if score @s gacha_pick matches 26 if score @s gacha_shiny matches 1 run givepokemon @s primeape shiny
execute if score @s gacha_pick matches 26 unless score @s gacha_shiny matches 1 run givepokemon @s primeape
execute if score @s gacha_pick matches 27 if score @s gacha_shiny matches 1 run givepokemon @s arcanine shiny
execute if score @s gacha_pick matches 27 unless score @s gacha_shiny matches 1 run givepokemon @s arcanine
execute if score @s gacha_pick matches 28 if score @s gacha_shiny matches 1 run givepokemon @s poliwrath shiny
execute if score @s gacha_pick matches 28 unless score @s gacha_shiny matches 1 run givepokemon @s poliwrath
execute if score @s gacha_pick matches 29 if score @s gacha_shiny matches 1 run givepokemon @s alakazam shiny
execute if score @s gacha_pick matches 29 unless score @s gacha_shiny matches 1 run givepokemon @s alakazam
execute if score @s gacha_pick matches 30 if score @s gacha_shiny matches 1 run givepokemon @s machamp shiny
execute if score @s gacha_pick matches 30 unless score @s gacha_shiny matches 1 run givepokemon @s machamp
execute if score @s gacha_pick matches 31 if score @s gacha_shiny matches 1 run givepokemon @s victreebel shiny
execute if score @s gacha_pick matches 31 unless score @s gacha_shiny matches 1 run givepokemon @s victreebel
execute if score @s gacha_pick matches 32 if score @s gacha_shiny matches 1 run givepokemon @s tentacruel shiny
execute if score @s gacha_pick matches 32 unless score @s gacha_shiny matches 1 run givepokemon @s tentacruel
execute if score @s gacha_pick matches 33 if score @s gacha_shiny matches 1 run givepokemon @s golem shiny
execute if score @s gacha_pick matches 33 unless score @s gacha_shiny matches 1 run givepokemon @s golem
execute if score @s gacha_pick matches 34 if score @s gacha_shiny matches 1 run givepokemon @s rapidash shiny
execute if score @s gacha_pick matches 34 unless score @s gacha_shiny matches 1 run givepokemon @s rapidash
execute if score @s gacha_pick matches 35 if score @s gacha_shiny matches 1 run givepokemon @s slowbro shiny
execute if score @s gacha_pick matches 35 unless score @s gacha_shiny matches 1 run givepokemon @s slowbro
execute if score @s gacha_pick matches 36 if score @s gacha_shiny matches 1 run givepokemon @s magneton shiny
execute if score @s gacha_pick matches 36 unless score @s gacha_shiny matches 1 run givepokemon @s magneton
execute if score @s gacha_pick matches 37 if score @s gacha_shiny matches 1 run givepokemon @s dodrio shiny
execute if score @s gacha_pick matches 37 unless score @s gacha_shiny matches 1 run givepokemon @s dodrio
execute if score @s gacha_pick matches 38 if score @s gacha_shiny matches 1 run givepokemon @s dewgong shiny
execute if score @s gacha_pick matches 38 unless score @s gacha_shiny matches 1 run givepokemon @s dewgong
execute if score @s gacha_pick matches 39 if score @s gacha_shiny matches 1 run givepokemon @s muk shiny
execute if score @s gacha_pick matches 39 unless score @s gacha_shiny matches 1 run givepokemon @s muk
execute if score @s gacha_pick matches 40 if score @s gacha_shiny matches 1 run givepokemon @s cloyster shiny
execute if score @s gacha_pick matches 40 unless score @s gacha_shiny matches 1 run givepokemon @s cloyster
execute if score @s gacha_pick matches 41 if score @s gacha_shiny matches 1 run givepokemon @s gengar shiny
execute if score @s gacha_pick matches 41 unless score @s gacha_shiny matches 1 run givepokemon @s gengar
execute if score @s gacha_pick matches 42 if score @s gacha_shiny matches 1 run givepokemon @s hypno shiny
execute if score @s gacha_pick matches 42 unless score @s gacha_shiny matches 1 run givepokemon @s hypno
execute if score @s gacha_pick matches 43 if score @s gacha_shiny matches 1 run givepokemon @s kingler shiny
execute if score @s gacha_pick matches 43 unless score @s gacha_shiny matches 1 run givepokemon @s kingler
execute if score @s gacha_pick matches 44 if score @s gacha_shiny matches 1 run givepokemon @s electrode shiny
execute if score @s gacha_pick matches 44 unless score @s gacha_shiny matches 1 run givepokemon @s electrode
execute if score @s gacha_pick matches 45 if score @s gacha_shiny matches 1 run givepokemon @s exeggutor shiny
execute if score @s gacha_pick matches 45 unless score @s gacha_shiny matches 1 run givepokemon @s exeggutor
execute if score @s gacha_pick matches 46 if score @s gacha_shiny matches 1 run givepokemon @s marowak shiny
execute if score @s gacha_pick matches 46 unless score @s gacha_shiny matches 1 run givepokemon @s marowak
execute if score @s gacha_pick matches 47 if score @s gacha_shiny matches 1 run givepokemon @s weezing shiny
execute if score @s gacha_pick matches 47 unless score @s gacha_shiny matches 1 run givepokemon @s weezing
execute if score @s gacha_pick matches 48 if score @s gacha_shiny matches 1 run givepokemon @s rhydon shiny
execute if score @s gacha_pick matches 48 unless score @s gacha_shiny matches 1 run givepokemon @s rhydon
execute if score @s gacha_pick matches 49 if score @s gacha_shiny matches 1 run givepokemon @s chansey shiny
execute if score @s gacha_pick matches 49 unless score @s gacha_shiny matches 1 run givepokemon @s chansey
execute if score @s gacha_pick matches 50 if score @s gacha_shiny matches 1 run givepokemon @s seaking shiny
execute if score @s gacha_pick matches 50 unless score @s gacha_shiny matches 1 run givepokemon @s seaking
execute if score @s gacha_pick matches 51 if score @s gacha_shiny matches 1 run givepokemon @s starmie shiny
execute if score @s gacha_pick matches 51 unless score @s gacha_shiny matches 1 run givepokemon @s starmie
execute if score @s gacha_pick matches 52 if score @s gacha_shiny matches 1 run givepokemon @s gyarados shiny
execute if score @s gacha_pick matches 52 unless score @s gacha_shiny matches 1 run givepokemon @s gyarados
execute if score @s gacha_pick matches 53 if score @s gacha_shiny matches 1 run givepokemon @s lapras shiny
execute if score @s gacha_pick matches 53 unless score @s gacha_shiny matches 1 run givepokemon @s lapras
execute if score @s gacha_pick matches 54 if score @s gacha_shiny matches 1 run givepokemon @s snorlax shiny
execute if score @s gacha_pick matches 54 unless score @s gacha_shiny matches 1 run givepokemon @s snorlax
execute if score @s gacha_pick matches 55 if score @s gacha_shiny matches 1 run givepokemon @s meganium shiny
execute if score @s gacha_pick matches 55 unless score @s gacha_shiny matches 1 run givepokemon @s meganium
execute if score @s gacha_pick matches 56 if score @s gacha_shiny matches 1 run givepokemon @s typhlosion shiny
execute if score @s gacha_pick matches 56 unless score @s gacha_shiny matches 1 run givepokemon @s typhlosion
execute if score @s gacha_pick matches 57 if score @s gacha_shiny matches 1 run givepokemon @s feraligatr shiny
execute if score @s gacha_pick matches 57 unless score @s gacha_shiny matches 1 run givepokemon @s feraligatr
execute if score @s gacha_pick matches 58 if score @s gacha_shiny matches 1 run givepokemon @s noctowl shiny
execute if score @s gacha_pick matches 58 unless score @s gacha_shiny matches 1 run givepokemon @s noctowl
execute if score @s gacha_pick matches 59 if score @s gacha_shiny matches 1 run givepokemon @s ledian shiny
execute if score @s gacha_pick matches 59 unless score @s gacha_shiny matches 1 run givepokemon @s ledian
execute if score @s gacha_pick matches 60 if score @s gacha_shiny matches 1 run givepokemon @s ariados shiny
execute if score @s gacha_pick matches 60 unless score @s gacha_shiny matches 1 run givepokemon @s ariados
execute if score @s gacha_pick matches 61 if score @s gacha_shiny matches 1 run givepokemon @s lanturn shiny
execute if score @s gacha_pick matches 61 unless score @s gacha_shiny matches 1 run givepokemon @s lanturn
execute if score @s gacha_pick matches 62 if score @s gacha_shiny matches 1 run givepokemon @s togetic shiny
execute if score @s gacha_pick matches 62 unless score @s gacha_shiny matches 1 run givepokemon @s togetic
execute if score @s gacha_pick matches 63 if score @s gacha_shiny matches 1 run givepokemon @s ampharos shiny
execute if score @s gacha_pick matches 63 unless score @s gacha_shiny matches 1 run givepokemon @s ampharos
execute if score @s gacha_pick matches 64 if score @s gacha_shiny matches 1 run givepokemon @s bellossom shiny
execute if score @s gacha_pick matches 64 unless score @s gacha_shiny matches 1 run givepokemon @s bellossom
execute if score @s gacha_pick matches 65 if score @s gacha_shiny matches 1 run givepokemon @s azumarill shiny
execute if score @s gacha_pick matches 65 unless score @s gacha_shiny matches 1 run givepokemon @s azumarill
execute if score @s gacha_pick matches 66 if score @s gacha_shiny matches 1 run givepokemon @s politoed shiny
execute if score @s gacha_pick matches 66 unless score @s gacha_shiny matches 1 run givepokemon @s politoed
execute if score @s gacha_pick matches 67 if score @s gacha_shiny matches 1 run givepokemon @s jumpluff shiny
execute if score @s gacha_pick matches 67 unless score @s gacha_shiny matches 1 run givepokemon @s jumpluff
execute if score @s gacha_pick matches 68 if score @s gacha_shiny matches 1 run givepokemon @s sunflora shiny
execute if score @s gacha_pick matches 68 unless score @s gacha_shiny matches 1 run givepokemon @s sunflora
execute if score @s gacha_pick matches 69 if score @s gacha_shiny matches 1 run givepokemon @s quagsire shiny
execute if score @s gacha_pick matches 69 unless score @s gacha_shiny matches 1 run givepokemon @s quagsire
execute if score @s gacha_pick matches 70 if score @s gacha_shiny matches 1 run givepokemon @s espeon shiny
execute if score @s gacha_pick matches 70 unless score @s gacha_shiny matches 1 run givepokemon @s espeon
execute if score @s gacha_pick matches 71 if score @s gacha_shiny matches 1 run givepokemon @s umbreon shiny
execute if score @s gacha_pick matches 71 unless score @s gacha_shiny matches 1 run givepokemon @s umbreon
execute if score @s gacha_pick matches 72 if score @s gacha_shiny matches 1 run givepokemon @s murkrow shiny
execute if score @s gacha_pick matches 72 unless score @s gacha_shiny matches 1 run givepokemon @s murkrow
execute if score @s gacha_pick matches 73 if score @s gacha_shiny matches 1 run givepokemon @s slowking shiny
execute if score @s gacha_pick matches 73 unless score @s gacha_shiny matches 1 run givepokemon @s slowking
execute if score @s gacha_pick matches 74 if score @s gacha_shiny matches 1 run givepokemon @s forretress shiny
execute if score @s gacha_pick matches 74 unless score @s gacha_shiny matches 1 run givepokemon @s forretress
execute if score @s gacha_pick matches 75 if score @s gacha_shiny matches 1 run givepokemon @s steelix shiny
execute if score @s gacha_pick matches 75 unless score @s gacha_shiny matches 1 run givepokemon @s steelix
execute if score @s gacha_pick matches 76 if score @s gacha_shiny matches 1 run givepokemon @s granbull shiny
execute if score @s gacha_pick matches 76 unless score @s gacha_shiny matches 1 run givepokemon @s granbull
execute if score @s gacha_pick matches 77 if score @s gacha_shiny matches 1 run givepokemon @s qwilfish shiny
execute if score @s gacha_pick matches 77 unless score @s gacha_shiny matches 1 run givepokemon @s qwilfish
execute if score @s gacha_pick matches 78 if score @s gacha_shiny matches 1 run givepokemon @s scizor shiny
execute if score @s gacha_pick matches 78 unless score @s gacha_shiny matches 1 run givepokemon @s scizor
execute if score @s gacha_pick matches 79 if score @s gacha_shiny matches 1 run givepokemon @s shuckle shiny
execute if score @s gacha_pick matches 79 unless score @s gacha_shiny matches 1 run givepokemon @s shuckle
execute if score @s gacha_pick matches 80 if score @s gacha_shiny matches 1 run givepokemon @s heracross shiny
execute if score @s gacha_pick matches 80 unless score @s gacha_shiny matches 1 run givepokemon @s heracross
execute if score @s gacha_pick matches 81 if score @s gacha_shiny matches 1 run givepokemon @s ursaring shiny
execute if score @s gacha_pick matches 81 unless score @s gacha_shiny matches 1 run givepokemon @s ursaring
execute if score @s gacha_pick matches 82 if score @s gacha_shiny matches 1 run givepokemon @s magcargo shiny
execute if score @s gacha_pick matches 82 unless score @s gacha_shiny matches 1 run givepokemon @s magcargo
execute if score @s gacha_pick matches 83 if score @s gacha_shiny matches 1 run givepokemon @s piloswine shiny
execute if score @s gacha_pick matches 83 unless score @s gacha_shiny matches 1 run givepokemon @s piloswine
execute if score @s gacha_pick matches 84 if score @s gacha_shiny matches 1 run givepokemon @s octillery shiny
execute if score @s gacha_pick matches 84 unless score @s gacha_shiny matches 1 run givepokemon @s octillery
execute if score @s gacha_pick matches 85 if score @s gacha_shiny matches 1 run givepokemon @s houndoom shiny
execute if score @s gacha_pick matches 85 unless score @s gacha_shiny matches 1 run givepokemon @s houndoom
execute if score @s gacha_pick matches 86 if score @s gacha_shiny matches 1 run givepokemon @s kingdra shiny
execute if score @s gacha_pick matches 86 unless score @s gacha_shiny matches 1 run givepokemon @s kingdra
execute if score @s gacha_pick matches 87 if score @s gacha_shiny matches 1 run givepokemon @s donphan shiny
execute if score @s gacha_pick matches 87 unless score @s gacha_shiny matches 1 run givepokemon @s donphan
execute if score @s gacha_pick matches 88 if score @s gacha_shiny matches 1 run givepokemon @s blissey shiny
execute if score @s gacha_pick matches 88 unless score @s gacha_shiny matches 1 run givepokemon @s blissey
execute if score @s gacha_pick matches 89 if score @s gacha_shiny matches 1 run givepokemon @s mightyena shiny
execute if score @s gacha_pick matches 89 unless score @s gacha_shiny matches 1 run givepokemon @s mightyena
execute if score @s gacha_pick matches 90 if score @s gacha_shiny matches 1 run givepokemon @s linoone shiny
execute if score @s gacha_pick matches 90 unless score @s gacha_shiny matches 1 run givepokemon @s linoone
execute if score @s gacha_pick matches 91 if score @s gacha_shiny matches 1 run givepokemon @s beautifly shiny
execute if score @s gacha_pick matches 91 unless score @s gacha_shiny matches 1 run givepokemon @s beautifly
execute if score @s gacha_pick matches 92 if score @s gacha_shiny matches 1 run givepokemon @s dustox shiny
execute if score @s gacha_pick matches 92 unless score @s gacha_shiny matches 1 run givepokemon @s dustox
execute if score @s gacha_pick matches 93 if score @s gacha_shiny matches 1 run givepokemon @s ludicolo shiny
execute if score @s gacha_pick matches 93 unless score @s gacha_shiny matches 1 run givepokemon @s ludicolo
execute if score @s gacha_pick matches 94 if score @s gacha_shiny matches 1 run givepokemon @s shiftry shiny
execute if score @s gacha_pick matches 94 unless score @s gacha_shiny matches 1 run givepokemon @s shiftry
execute if score @s gacha_pick matches 95 if score @s gacha_shiny matches 1 run givepokemon @s swellow shiny
execute if score @s gacha_pick matches 95 unless score @s gacha_shiny matches 1 run givepokemon @s swellow
execute if score @s gacha_pick matches 96 if score @s gacha_shiny matches 1 run givepokemon @s pelipper shiny
execute if score @s gacha_pick matches 96 unless score @s gacha_shiny matches 1 run givepokemon @s pelipper
execute if score @s gacha_pick matches 97 if score @s gacha_shiny matches 1 run givepokemon @s gardevoir shiny
execute if score @s gacha_pick matches 97 unless score @s gacha_shiny matches 1 run givepokemon @s gardevoir
execute if score @s gacha_pick matches 98 if score @s gacha_shiny matches 1 run givepokemon @s masquerain shiny
execute if score @s gacha_pick matches 98 unless score @s gacha_shiny matches 1 run givepokemon @s masquerain
execute if score @s gacha_pick matches 99 if score @s gacha_shiny matches 1 run givepokemon @s breloom shiny
execute if score @s gacha_pick matches 99 unless score @s gacha_shiny matches 1 run givepokemon @s breloom
execute if score @s gacha_pick matches 100 if score @s gacha_shiny matches 1 run givepokemon @s slaking shiny
execute if score @s gacha_pick matches 100 unless score @s gacha_shiny matches 1 run givepokemon @s slaking
execute if score @s gacha_pick matches 101 if score @s gacha_shiny matches 1 run givepokemon @s shedinja shiny
execute if score @s gacha_pick matches 101 unless score @s gacha_shiny matches 1 run givepokemon @s shedinja
execute if score @s gacha_pick matches 102 if score @s gacha_shiny matches 1 run givepokemon @s exploud shiny
execute if score @s gacha_pick matches 102 unless score @s gacha_shiny matches 1 run givepokemon @s exploud
execute if score @s gacha_pick matches 103 if score @s gacha_shiny matches 1 run givepokemon @s hariyama shiny
execute if score @s gacha_pick matches 103 unless score @s gacha_shiny matches 1 run givepokemon @s hariyama
execute if score @s gacha_pick matches 104 if score @s gacha_shiny matches 1 run givepokemon @s delcatty shiny
execute if score @s gacha_pick matches 104 unless score @s gacha_shiny matches 1 run givepokemon @s delcatty
execute if score @s gacha_pick matches 105 if score @s gacha_shiny matches 1 run givepokemon @s aggron shiny
execute if score @s gacha_pick matches 105 unless score @s gacha_shiny matches 1 run givepokemon @s aggron
execute if score @s gacha_pick matches 106 if score @s gacha_shiny matches 1 run givepokemon @s medicham shiny
execute if score @s gacha_pick matches 106 unless score @s gacha_shiny matches 1 run givepokemon @s medicham
execute if score @s gacha_pick matches 107 if score @s gacha_shiny matches 1 run givepokemon @s manectric shiny
execute if score @s gacha_pick matches 107 unless score @s gacha_shiny matches 1 run givepokemon @s manectric
execute if score @s gacha_pick matches 108 if score @s gacha_shiny matches 1 run givepokemon @s sharpedo shiny
execute if score @s gacha_pick matches 108 unless score @s gacha_shiny matches 1 run givepokemon @s sharpedo
execute if score @s gacha_pick matches 109 if score @s gacha_shiny matches 1 run givepokemon @s wailord shiny
execute if score @s gacha_pick matches 109 unless score @s gacha_shiny matches 1 run givepokemon @s wailord
execute if score @s gacha_pick matches 110 if score @s gacha_shiny matches 1 run givepokemon @s camerupt shiny
execute if score @s gacha_pick matches 110 unless score @s gacha_shiny matches 1 run givepokemon @s camerupt
execute if score @s gacha_pick matches 111 if score @s gacha_shiny matches 1 run givepokemon @s grumpig shiny
execute if score @s gacha_pick matches 111 unless score @s gacha_shiny matches 1 run givepokemon @s grumpig
execute if score @s gacha_pick matches 112 if score @s gacha_shiny matches 1 run givepokemon @s flygon shiny
execute if score @s gacha_pick matches 112 unless score @s gacha_shiny matches 1 run givepokemon @s flygon
execute if score @s gacha_pick matches 113 if score @s gacha_shiny matches 1 run givepokemon @s cacturne shiny
execute if score @s gacha_pick matches 113 unless score @s gacha_shiny matches 1 run givepokemon @s cacturne
execute if score @s gacha_pick matches 114 if score @s gacha_shiny matches 1 run givepokemon @s altaria shiny
execute if score @s gacha_pick matches 114 unless score @s gacha_shiny matches 1 run givepokemon @s altaria
execute if score @s gacha_pick matches 115 if score @s gacha_shiny matches 1 run givepokemon @s whiscash shiny
execute if score @s gacha_pick matches 115 unless score @s gacha_shiny matches 1 run givepokemon @s whiscash
execute if score @s gacha_pick matches 116 if score @s gacha_shiny matches 1 run givepokemon @s crawdaunt shiny
execute if score @s gacha_pick matches 116 unless score @s gacha_shiny matches 1 run givepokemon @s crawdaunt
execute if score @s gacha_pick matches 117 if score @s gacha_shiny matches 1 run givepokemon @s claydol shiny
execute if score @s gacha_pick matches 117 unless score @s gacha_shiny matches 1 run givepokemon @s claydol
execute if score @s gacha_pick matches 118 if score @s gacha_shiny matches 1 run givepokemon @s cradily shiny
execute if score @s gacha_pick matches 118 unless score @s gacha_shiny matches 1 run givepokemon @s cradily
execute if score @s gacha_pick matches 119 if score @s gacha_shiny matches 1 run givepokemon @s armaldo shiny
execute if score @s gacha_pick matches 119 unless score @s gacha_shiny matches 1 run givepokemon @s armaldo
execute if score @s gacha_pick matches 120 if score @s gacha_shiny matches 1 run givepokemon @s milotic shiny
execute if score @s gacha_pick matches 120 unless score @s gacha_shiny matches 1 run givepokemon @s milotic
execute if score @s gacha_pick matches 121 if score @s gacha_shiny matches 1 run givepokemon @s banette shiny
execute if score @s gacha_pick matches 121 unless score @s gacha_shiny matches 1 run givepokemon @s banette
execute if score @s gacha_pick matches 122 if score @s gacha_shiny matches 1 run givepokemon @s dusclops shiny
execute if score @s gacha_pick matches 122 unless score @s gacha_shiny matches 1 run givepokemon @s dusclops
execute if score @s gacha_pick matches 123 if score @s gacha_shiny matches 1 run givepokemon @s glalie shiny
execute if score @s gacha_pick matches 123 unless score @s gacha_shiny matches 1 run givepokemon @s glalie
execute if score @s gacha_pick matches 124 if score @s gacha_shiny matches 1 run givepokemon @s walrein shiny
execute if score @s gacha_pick matches 124 unless score @s gacha_shiny matches 1 run givepokemon @s walrein
execute if score @s gacha_pick matches 125 if score @s gacha_shiny matches 1 run givepokemon @s gorebyss shiny
execute if score @s gacha_pick matches 125 unless score @s gacha_shiny matches 1 run givepokemon @s gorebyss
execute if score @s gacha_pick matches 126 if score @s gacha_shiny matches 1 run givepokemon @s relicanth shiny
execute if score @s gacha_pick matches 126 unless score @s gacha_shiny matches 1 run givepokemon @s relicanth
execute if score @s gacha_pick matches 127 if score @s gacha_shiny matches 1 run givepokemon @s torterra shiny
execute if score @s gacha_pick matches 127 unless score @s gacha_shiny matches 1 run givepokemon @s torterra
execute if score @s gacha_pick matches 128 if score @s gacha_shiny matches 1 run givepokemon @s staraptor shiny
execute if score @s gacha_pick matches 128 unless score @s gacha_shiny matches 1 run givepokemon @s staraptor
execute if score @s gacha_pick matches 129 if score @s gacha_shiny matches 1 run givepokemon @s bibarel shiny
execute if score @s gacha_pick matches 129 unless score @s gacha_shiny matches 1 run givepokemon @s bibarel
execute if score @s gacha_pick matches 130 if score @s gacha_shiny matches 1 run givepokemon @s luxray shiny
execute if score @s gacha_pick matches 130 unless score @s gacha_shiny matches 1 run givepokemon @s luxray
execute if score @s gacha_pick matches 131 if score @s gacha_shiny matches 1 run givepokemon @s roserade shiny
execute if score @s gacha_pick matches 131 unless score @s gacha_shiny matches 1 run givepokemon @s roserade
execute if score @s gacha_pick matches 132 if score @s gacha_shiny matches 1 run givepokemon @s rampardos shiny
execute if score @s gacha_pick matches 132 unless score @s gacha_shiny matches 1 run givepokemon @s rampardos
execute if score @s gacha_pick matches 133 if score @s gacha_shiny matches 1 run givepokemon @s bastiodon shiny
execute if score @s gacha_pick matches 133 unless score @s gacha_shiny matches 1 run givepokemon @s bastiodon
execute if score @s gacha_pick matches 134 if score @s gacha_shiny matches 1 run givepokemon @s wormadam shiny
execute if score @s gacha_pick matches 134 unless score @s gacha_shiny matches 1 run givepokemon @s wormadam
execute if score @s gacha_pick matches 135 if score @s gacha_shiny matches 1 run givepokemon @s mothim shiny
execute if score @s gacha_pick matches 135 unless score @s gacha_shiny matches 1 run givepokemon @s mothim
execute if score @s gacha_pick matches 136 if score @s gacha_shiny matches 1 run givepokemon @s vespiquen shiny
execute if score @s gacha_pick matches 136 unless score @s gacha_shiny matches 1 run givepokemon @s vespiquen
execute if score @s gacha_pick matches 137 if score @s gacha_shiny matches 1 run givepokemon @s floatzel shiny
execute if score @s gacha_pick matches 137 unless score @s gacha_shiny matches 1 run givepokemon @s floatzel
execute if score @s gacha_pick matches 138 if score @s gacha_shiny matches 1 run givepokemon @s cherrim shiny
execute if score @s gacha_pick matches 138 unless score @s gacha_shiny matches 1 run givepokemon @s cherrim
execute if score @s gacha_pick matches 139 if score @s gacha_shiny matches 1 run givepokemon @s gastrodon shiny
execute if score @s gacha_pick matches 139 unless score @s gacha_shiny matches 1 run givepokemon @s gastrodon
execute if score @s gacha_pick matches 140 if score @s gacha_shiny matches 1 run givepokemon @s ambipom shiny
execute if score @s gacha_pick matches 140 unless score @s gacha_shiny matches 1 run givepokemon @s ambipom
execute if score @s gacha_pick matches 141 if score @s gacha_shiny matches 1 run givepokemon @s drifblim shiny
execute if score @s gacha_pick matches 141 unless score @s gacha_shiny matches 1 run givepokemon @s drifblim
execute if score @s gacha_pick matches 142 if score @s gacha_shiny matches 1 run givepokemon @s lopunny shiny
execute if score @s gacha_pick matches 142 unless score @s gacha_shiny matches 1 run givepokemon @s lopunny
execute if score @s gacha_pick matches 143 if score @s gacha_shiny matches 1 run givepokemon @s honchkrow shiny
execute if score @s gacha_pick matches 143 unless score @s gacha_shiny matches 1 run givepokemon @s honchkrow
execute if score @s gacha_pick matches 144 if score @s gacha_shiny matches 1 run givepokemon @s purugly shiny
execute if score @s gacha_pick matches 144 unless score @s gacha_shiny matches 1 run givepokemon @s purugly
execute if score @s gacha_pick matches 145 if score @s gacha_shiny matches 1 run givepokemon @s skuntank shiny
execute if score @s gacha_pick matches 145 unless score @s gacha_shiny matches 1 run givepokemon @s skuntank
execute if score @s gacha_pick matches 146 if score @s gacha_shiny matches 1 run givepokemon @s bronzong shiny
execute if score @s gacha_pick matches 146 unless score @s gacha_shiny matches 1 run givepokemon @s bronzong
execute if score @s gacha_pick matches 147 if score @s gacha_shiny matches 1 run givepokemon @s chatot shiny
execute if score @s gacha_pick matches 147 unless score @s gacha_shiny matches 1 run givepokemon @s chatot
execute if score @s gacha_pick matches 148 if score @s gacha_shiny matches 1 run givepokemon @s spiritomb shiny
execute if score @s gacha_pick matches 148 unless score @s gacha_shiny matches 1 run givepokemon @s spiritomb
execute if score @s gacha_pick matches 149 if score @s gacha_shiny matches 1 run givepokemon @s hippowdon shiny
execute if score @s gacha_pick matches 149 unless score @s gacha_shiny matches 1 run givepokemon @s hippowdon
execute if score @s gacha_pick matches 150 if score @s gacha_shiny matches 1 run givepokemon @s drapion shiny
execute if score @s gacha_pick matches 150 unless score @s gacha_shiny matches 1 run givepokemon @s drapion
execute if score @s gacha_pick matches 151 if score @s gacha_shiny matches 1 run givepokemon @s toxicroak shiny
execute if score @s gacha_pick matches 151 unless score @s gacha_shiny matches 1 run givepokemon @s toxicroak
execute if score @s gacha_pick matches 152 if score @s gacha_shiny matches 1 run givepokemon @s lumineon shiny
execute if score @s gacha_pick matches 152 unless score @s gacha_shiny matches 1 run givepokemon @s lumineon
execute if score @s gacha_pick matches 153 if score @s gacha_shiny matches 1 run givepokemon @s abomasnow shiny
execute if score @s gacha_pick matches 153 unless score @s gacha_shiny matches 1 run givepokemon @s abomasnow
execute if score @s gacha_pick matches 154 if score @s gacha_shiny matches 1 run givepokemon @s weavile shiny
execute if score @s gacha_pick matches 154 unless score @s gacha_shiny matches 1 run givepokemon @s weavile
execute if score @s gacha_pick matches 155 if score @s gacha_shiny matches 1 run givepokemon @s magnezone shiny
execute if score @s gacha_pick matches 155 unless score @s gacha_shiny matches 1 run givepokemon @s magnezone
execute if score @s gacha_pick matches 156 if score @s gacha_shiny matches 1 run givepokemon @s lickilicky shiny
execute if score @s gacha_pick matches 156 unless score @s gacha_shiny matches 1 run givepokemon @s lickilicky
execute if score @s gacha_pick matches 157 if score @s gacha_shiny matches 1 run givepokemon @s rhyperior shiny
execute if score @s gacha_pick matches 157 unless score @s gacha_shiny matches 1 run givepokemon @s rhyperior
execute if score @s gacha_pick matches 158 if score @s gacha_shiny matches 1 run givepokemon @s tangrowth shiny
execute if score @s gacha_pick matches 158 unless score @s gacha_shiny matches 1 run givepokemon @s tangrowth
execute if score @s gacha_pick matches 159 if score @s gacha_shiny matches 1 run givepokemon @s electivire shiny
execute if score @s gacha_pick matches 159 unless score @s gacha_shiny matches 1 run givepokemon @s electivire
execute if score @s gacha_pick matches 160 if score @s gacha_shiny matches 1 run givepokemon @s magmortar shiny
execute if score @s gacha_pick matches 160 unless score @s gacha_shiny matches 1 run givepokemon @s magmortar
execute if score @s gacha_pick matches 161 if score @s gacha_shiny matches 1 run givepokemon @s togekiss shiny
execute if score @s gacha_pick matches 161 unless score @s gacha_shiny matches 1 run givepokemon @s togekiss
execute if score @s gacha_pick matches 162 if score @s gacha_shiny matches 1 run givepokemon @s yanmega shiny
execute if score @s gacha_pick matches 162 unless score @s gacha_shiny matches 1 run givepokemon @s yanmega
execute if score @s gacha_pick matches 163 if score @s gacha_shiny matches 1 run givepokemon @s gliscor shiny
execute if score @s gacha_pick matches 163 unless score @s gacha_shiny matches 1 run givepokemon @s gliscor
execute if score @s gacha_pick matches 164 if score @s gacha_shiny matches 1 run givepokemon @s mamoswine shiny
execute if score @s gacha_pick matches 164 unless score @s gacha_shiny matches 1 run givepokemon @s mamoswine
execute if score @s gacha_pick matches 165 if score @s gacha_shiny matches 1 run givepokemon @s porygonz shiny
execute if score @s gacha_pick matches 165 unless score @s gacha_shiny matches 1 run givepokemon @s porygonz
execute if score @s gacha_pick matches 166 if score @s gacha_shiny matches 1 run givepokemon @s gallade shiny
execute if score @s gacha_pick matches 166 unless score @s gacha_shiny matches 1 run givepokemon @s gallade
execute if score @s gacha_pick matches 167 if score @s gacha_shiny matches 1 run givepokemon @s probopass shiny
execute if score @s gacha_pick matches 167 unless score @s gacha_shiny matches 1 run givepokemon @s probopass
execute if score @s gacha_pick matches 168 if score @s gacha_shiny matches 1 run givepokemon @s dusknoir shiny
execute if score @s gacha_pick matches 168 unless score @s gacha_shiny matches 1 run givepokemon @s dusknoir
execute if score @s gacha_pick matches 169 if score @s gacha_shiny matches 1 run givepokemon @s froslass shiny
execute if score @s gacha_pick matches 169 unless score @s gacha_shiny matches 1 run givepokemon @s froslass
execute if score @s gacha_pick matches 170 if score @s gacha_shiny matches 1 run givepokemon @s rotom shiny
execute if score @s gacha_pick matches 170 unless score @s gacha_shiny matches 1 run givepokemon @s rotom
execute if score @s gacha_pick matches 171 if score @s gacha_shiny matches 1 run givepokemon @s stoutland shiny
execute if score @s gacha_pick matches 171 unless score @s gacha_shiny matches 1 run givepokemon @s stoutland
execute if score @s gacha_pick matches 172 if score @s gacha_shiny matches 1 run givepokemon @s liepard shiny
execute if score @s gacha_pick matches 172 unless score @s gacha_shiny matches 1 run givepokemon @s liepard
execute if score @s gacha_pick matches 173 if score @s gacha_shiny matches 1 run givepokemon @s simisage shiny
execute if score @s gacha_pick matches 173 unless score @s gacha_shiny matches 1 run givepokemon @s simisage
execute if score @s gacha_pick matches 174 if score @s gacha_shiny matches 1 run givepokemon @s simisear shiny
execute if score @s gacha_pick matches 174 unless score @s gacha_shiny matches 1 run givepokemon @s simisear
execute if score @s gacha_pick matches 175 if score @s gacha_shiny matches 1 run givepokemon @s simipour shiny
execute if score @s gacha_pick matches 175 unless score @s gacha_shiny matches 1 run givepokemon @s simipour
execute if score @s gacha_pick matches 176 if score @s gacha_shiny matches 1 run givepokemon @s musharna shiny
execute if score @s gacha_pick matches 176 unless score @s gacha_shiny matches 1 run givepokemon @s musharna
execute if score @s gacha_pick matches 177 if score @s gacha_shiny matches 1 run givepokemon @s unfezant shiny
execute if score @s gacha_pick matches 177 unless score @s gacha_shiny matches 1 run givepokemon @s unfezant
execute if score @s gacha_pick matches 178 if score @s gacha_shiny matches 1 run givepokemon @s zebstrika shiny
execute if score @s gacha_pick matches 178 unless score @s gacha_shiny matches 1 run givepokemon @s zebstrika
execute if score @s gacha_pick matches 179 if score @s gacha_shiny matches 1 run givepokemon @s gigalith shiny
execute if score @s gacha_pick matches 179 unless score @s gacha_shiny matches 1 run givepokemon @s gigalith
execute if score @s gacha_pick matches 180 if score @s gacha_shiny matches 1 run givepokemon @s excadrill shiny
execute if score @s gacha_pick matches 180 unless score @s gacha_shiny matches 1 run givepokemon @s excadrill
execute if score @s gacha_pick matches 181 if score @s gacha_shiny matches 1 run givepokemon @s conkeldurr shiny
execute if score @s gacha_pick matches 181 unless score @s gacha_shiny matches 1 run givepokemon @s conkeldurr
execute if score @s gacha_pick matches 182 if score @s gacha_shiny matches 1 run givepokemon @s seismitoad shiny
execute if score @s gacha_pick matches 182 unless score @s gacha_shiny matches 1 run givepokemon @s seismitoad
execute if score @s gacha_pick matches 183 if score @s gacha_shiny matches 1 run givepokemon @s leavanny shiny
execute if score @s gacha_pick matches 183 unless score @s gacha_shiny matches 1 run givepokemon @s leavanny
execute if score @s gacha_pick matches 184 if score @s gacha_shiny matches 1 run givepokemon @s scolipede shiny
execute if score @s gacha_pick matches 184 unless score @s gacha_shiny matches 1 run givepokemon @s scolipede
execute if score @s gacha_pick matches 185 if score @s gacha_shiny matches 1 run givepokemon @s whimsicott shiny
execute if score @s gacha_pick matches 185 unless score @s gacha_shiny matches 1 run givepokemon @s whimsicott
execute if score @s gacha_pick matches 186 if score @s gacha_shiny matches 1 run givepokemon @s lilligant shiny
execute if score @s gacha_pick matches 186 unless score @s gacha_shiny matches 1 run givepokemon @s lilligant
execute if score @s gacha_pick matches 187 if score @s gacha_shiny matches 1 run givepokemon @s krookodile shiny
execute if score @s gacha_pick matches 187 unless score @s gacha_shiny matches 1 run givepokemon @s krookodile
execute if score @s gacha_pick matches 188 if score @s gacha_shiny matches 1 run givepokemon @s darmanitan shiny
execute if score @s gacha_pick matches 188 unless score @s gacha_shiny matches 1 run givepokemon @s darmanitan
execute if score @s gacha_pick matches 189 if score @s gacha_shiny matches 1 run givepokemon @s crustle shiny
execute if score @s gacha_pick matches 189 unless score @s gacha_shiny matches 1 run givepokemon @s crustle
execute if score @s gacha_pick matches 190 if score @s gacha_shiny matches 1 run givepokemon @s scrafty shiny
execute if score @s gacha_pick matches 190 unless score @s gacha_shiny matches 1 run givepokemon @s scrafty
execute if score @s gacha_pick matches 191 if score @s gacha_shiny matches 1 run givepokemon @s cofagrigus shiny
execute if score @s gacha_pick matches 191 unless score @s gacha_shiny matches 1 run givepokemon @s cofagrigus
execute if score @s gacha_pick matches 192 if score @s gacha_shiny matches 1 run givepokemon @s carracosta shiny
execute if score @s gacha_pick matches 192 unless score @s gacha_shiny matches 1 run givepokemon @s carracosta
execute if score @s gacha_pick matches 193 if score @s gacha_shiny matches 1 run givepokemon @s archeops shiny
execute if score @s gacha_pick matches 193 unless score @s gacha_shiny matches 1 run givepokemon @s archeops
execute if score @s gacha_pick matches 194 if score @s gacha_shiny matches 1 run givepokemon @s garbodor shiny
execute if score @s gacha_pick matches 194 unless score @s gacha_shiny matches 1 run givepokemon @s garbodor
execute if score @s gacha_pick matches 195 if score @s gacha_shiny matches 1 run givepokemon @s zoroark shiny
execute if score @s gacha_pick matches 195 unless score @s gacha_shiny matches 1 run givepokemon @s zoroark
execute if score @s gacha_pick matches 196 if score @s gacha_shiny matches 1 run givepokemon @s cinccino shiny
execute if score @s gacha_pick matches 196 unless score @s gacha_shiny matches 1 run givepokemon @s cinccino
execute if score @s gacha_pick matches 197 if score @s gacha_shiny matches 1 run givepokemon @s gothitelle shiny
execute if score @s gacha_pick matches 197 unless score @s gacha_shiny matches 1 run givepokemon @s gothitelle
execute if score @s gacha_pick matches 198 if score @s gacha_shiny matches 1 run givepokemon @s reuniclus shiny
execute if score @s gacha_pick matches 198 unless score @s gacha_shiny matches 1 run givepokemon @s reuniclus
execute if score @s gacha_pick matches 199 if score @s gacha_shiny matches 1 run givepokemon @s swanna shiny
execute if score @s gacha_pick matches 199 unless score @s gacha_shiny matches 1 run givepokemon @s swanna
execute if score @s gacha_pick matches 200 if score @s gacha_shiny matches 1 run givepokemon @s vanilluxe shiny
execute if score @s gacha_pick matches 200 unless score @s gacha_shiny matches 1 run givepokemon @s vanilluxe
execute if score @s gacha_pick matches 201 if score @s gacha_shiny matches 1 run givepokemon @s sawsbuck shiny
execute if score @s gacha_pick matches 201 unless score @s gacha_shiny matches 1 run givepokemon @s sawsbuck
execute if score @s gacha_pick matches 202 if score @s gacha_shiny matches 1 run givepokemon @s karrablast shiny
execute if score @s gacha_pick matches 202 unless score @s gacha_shiny matches 1 run givepokemon @s karrablast
execute if score @s gacha_pick matches 203 if score @s gacha_shiny matches 1 run givepokemon @s escavalier shiny
execute if score @s gacha_pick matches 203 unless score @s gacha_shiny matches 1 run givepokemon @s escavalier
execute if score @s gacha_pick matches 204 if score @s gacha_shiny matches 1 run givepokemon @s amoonguss shiny
execute if score @s gacha_pick matches 204 unless score @s gacha_shiny matches 1 run givepokemon @s amoonguss
execute if score @s gacha_pick matches 205 if score @s gacha_shiny matches 1 run givepokemon @s jellicent shiny
execute if score @s gacha_pick matches 205 unless score @s gacha_shiny matches 1 run givepokemon @s jellicent
execute if score @s gacha_pick matches 206 if score @s gacha_shiny matches 1 run givepokemon @s galvantula shiny
execute if score @s gacha_pick matches 206 unless score @s gacha_shiny matches 1 run givepokemon @s galvantula
execute if score @s gacha_pick matches 207 if score @s gacha_shiny matches 1 run givepokemon @s ferrothorn shiny
execute if score @s gacha_pick matches 207 unless score @s gacha_shiny matches 1 run givepokemon @s ferrothorn
execute if score @s gacha_pick matches 208 if score @s gacha_shiny matches 1 run givepokemon @s eelektross shiny
execute if score @s gacha_pick matches 208 unless score @s gacha_shiny matches 1 run givepokemon @s eelektross
execute if score @s gacha_pick matches 209 if score @s gacha_shiny matches 1 run givepokemon @s beheeyem shiny
execute if score @s gacha_pick matches 209 unless score @s gacha_shiny matches 1 run givepokemon @s beheeyem
execute if score @s gacha_pick matches 210 if score @s gacha_shiny matches 1 run givepokemon @s chandelure shiny
execute if score @s gacha_pick matches 210 unless score @s gacha_shiny matches 1 run givepokemon @s chandelure
execute if score @s gacha_pick matches 211 if score @s gacha_shiny matches 1 run givepokemon @s beartic shiny
execute if score @s gacha_pick matches 211 unless score @s gacha_shiny matches 1 run givepokemon @s beartic
execute if score @s gacha_pick matches 212 if score @s gacha_shiny matches 1 run givepokemon @s accelgor shiny
execute if score @s gacha_pick matches 212 unless score @s gacha_shiny matches 1 run givepokemon @s accelgor
execute if score @s gacha_pick matches 213 if score @s gacha_shiny matches 1 run givepokemon @s mienshao shiny
execute if score @s gacha_pick matches 213 unless score @s gacha_shiny matches 1 run givepokemon @s mienshao
execute if score @s gacha_pick matches 214 if score @s gacha_shiny matches 1 run givepokemon @s golurk shiny
execute if score @s gacha_pick matches 214 unless score @s gacha_shiny matches 1 run givepokemon @s golurk
execute if score @s gacha_pick matches 215 if score @s gacha_shiny matches 1 run givepokemon @s bisharp shiny
execute if score @s gacha_pick matches 215 unless score @s gacha_shiny matches 1 run givepokemon @s bisharp
execute if score @s gacha_pick matches 216 if score @s gacha_shiny matches 1 run givepokemon @s braviary shiny
execute if score @s gacha_pick matches 216 unless score @s gacha_shiny matches 1 run givepokemon @s braviary
execute if score @s gacha_pick matches 217 if score @s gacha_shiny matches 1 run givepokemon @s mandibuzz shiny
execute if score @s gacha_pick matches 217 unless score @s gacha_shiny matches 1 run givepokemon @s mandibuzz
execute if score @s gacha_pick matches 218 if score @s gacha_shiny matches 1 run givepokemon @s chesnaught shiny
execute if score @s gacha_pick matches 218 unless score @s gacha_shiny matches 1 run givepokemon @s chesnaught
execute if score @s gacha_pick matches 219 if score @s gacha_shiny matches 1 run givepokemon @s delphox shiny
execute if score @s gacha_pick matches 219 unless score @s gacha_shiny matches 1 run givepokemon @s delphox
execute if score @s gacha_pick matches 220 if score @s gacha_shiny matches 1 run givepokemon @s diggersby shiny
execute if score @s gacha_pick matches 220 unless score @s gacha_shiny matches 1 run givepokemon @s diggersby
execute if score @s gacha_pick matches 221 if score @s gacha_shiny matches 1 run givepokemon @s talonflame shiny
execute if score @s gacha_pick matches 221 unless score @s gacha_shiny matches 1 run givepokemon @s talonflame
execute if score @s gacha_pick matches 222 if score @s gacha_shiny matches 1 run givepokemon @s vivillon shiny
execute if score @s gacha_pick matches 222 unless score @s gacha_shiny matches 1 run givepokemon @s vivillon
execute if score @s gacha_pick matches 223 if score @s gacha_shiny matches 1 run givepokemon @s pyroar shiny
execute if score @s gacha_pick matches 223 unless score @s gacha_shiny matches 1 run givepokemon @s pyroar
execute if score @s gacha_pick matches 224 if score @s gacha_shiny matches 1 run givepokemon @s florges shiny
execute if score @s gacha_pick matches 224 unless score @s gacha_shiny matches 1 run givepokemon @s florges
execute if score @s gacha_pick matches 225 if score @s gacha_shiny matches 1 run givepokemon @s gogoat shiny
execute if score @s gacha_pick matches 225 unless score @s gacha_shiny matches 1 run givepokemon @s gogoat
execute if score @s gacha_pick matches 226 if score @s gacha_shiny matches 1 run givepokemon @s pangoro shiny
execute if score @s gacha_pick matches 226 unless score @s gacha_shiny matches 1 run givepokemon @s pangoro
execute if score @s gacha_pick matches 227 if score @s gacha_shiny matches 1 run givepokemon @s meowstic shiny
execute if score @s gacha_pick matches 227 unless score @s gacha_shiny matches 1 run givepokemon @s meowstic
execute if score @s gacha_pick matches 228 if score @s gacha_shiny matches 1 run givepokemon @s aromatisse shiny
execute if score @s gacha_pick matches 228 unless score @s gacha_shiny matches 1 run givepokemon @s aromatisse
execute if score @s gacha_pick matches 229 if score @s gacha_shiny matches 1 run givepokemon @s slurpuff shiny
execute if score @s gacha_pick matches 229 unless score @s gacha_shiny matches 1 run givepokemon @s slurpuff
execute if score @s gacha_pick matches 230 if score @s gacha_shiny matches 1 run givepokemon @s malamar shiny
execute if score @s gacha_pick matches 230 unless score @s gacha_shiny matches 1 run givepokemon @s malamar
execute if score @s gacha_pick matches 231 if score @s gacha_shiny matches 1 run givepokemon @s barbaracle shiny
execute if score @s gacha_pick matches 231 unless score @s gacha_shiny matches 1 run givepokemon @s barbaracle
execute if score @s gacha_pick matches 232 if score @s gacha_shiny matches 1 run givepokemon @s dragalge shiny
execute if score @s gacha_pick matches 232 unless score @s gacha_shiny matches 1 run givepokemon @s dragalge
execute if score @s gacha_pick matches 233 if score @s gacha_shiny matches 1 run givepokemon @s clawitzer shiny
execute if score @s gacha_pick matches 233 unless score @s gacha_shiny matches 1 run givepokemon @s clawitzer
execute if score @s gacha_pick matches 234 if score @s gacha_shiny matches 1 run givepokemon @s heliolisk shiny
execute if score @s gacha_pick matches 234 unless score @s gacha_shiny matches 1 run givepokemon @s heliolisk
execute if score @s gacha_pick matches 235 if score @s gacha_shiny matches 1 run givepokemon @s tyrantrum shiny
execute if score @s gacha_pick matches 235 unless score @s gacha_shiny matches 1 run givepokemon @s tyrantrum
execute if score @s gacha_pick matches 236 if score @s gacha_shiny matches 1 run givepokemon @s aurorus shiny
execute if score @s gacha_pick matches 236 unless score @s gacha_shiny matches 1 run givepokemon @s aurorus
execute if score @s gacha_pick matches 237 if score @s gacha_shiny matches 1 run givepokemon @s sylveon shiny
execute if score @s gacha_pick matches 237 unless score @s gacha_shiny matches 1 run givepokemon @s sylveon
execute if score @s gacha_pick matches 238 if score @s gacha_shiny matches 1 run givepokemon @s hawlucha shiny
execute if score @s gacha_pick matches 238 unless score @s gacha_shiny matches 1 run givepokemon @s hawlucha
execute if score @s gacha_pick matches 239 if score @s gacha_shiny matches 1 run givepokemon @s carbink shiny
execute if score @s gacha_pick matches 239 unless score @s gacha_shiny matches 1 run givepokemon @s carbink
execute if score @s gacha_pick matches 240 if score @s gacha_shiny matches 1 run givepokemon @s klefki shiny
execute if score @s gacha_pick matches 240 unless score @s gacha_shiny matches 1 run givepokemon @s klefki
execute if score @s gacha_pick matches 241 if score @s gacha_shiny matches 1 run givepokemon @s trevenant shiny
execute if score @s gacha_pick matches 241 unless score @s gacha_shiny matches 1 run givepokemon @s trevenant
execute if score @s gacha_pick matches 242 if score @s gacha_shiny matches 1 run givepokemon @s gourgeist shiny
execute if score @s gacha_pick matches 242 unless score @s gacha_shiny matches 1 run givepokemon @s gourgeist
execute if score @s gacha_pick matches 243 if score @s gacha_shiny matches 1 run givepokemon @s avalugg shiny
execute if score @s gacha_pick matches 243 unless score @s gacha_shiny matches 1 run givepokemon @s avalugg
execute if score @s gacha_pick matches 244 if score @s gacha_shiny matches 1 run givepokemon @s noivern shiny
execute if score @s gacha_pick matches 244 unless score @s gacha_shiny matches 1 run givepokemon @s noivern
execute if score @s gacha_pick matches 245 if score @s gacha_shiny matches 1 run givepokemon @s toucannon shiny
execute if score @s gacha_pick matches 245 unless score @s gacha_shiny matches 1 run givepokemon @s toucannon
execute if score @s gacha_pick matches 246 if score @s gacha_shiny matches 1 run givepokemon @s gumshoos shiny
execute if score @s gacha_pick matches 246 unless score @s gacha_shiny matches 1 run givepokemon @s gumshoos
execute if score @s gacha_pick matches 247 if score @s gacha_shiny matches 1 run givepokemon @s vikavolt shiny
execute if score @s gacha_pick matches 247 unless score @s gacha_shiny matches 1 run givepokemon @s vikavolt
execute if score @s gacha_pick matches 248 if score @s gacha_shiny matches 1 run givepokemon @s crabominable shiny
execute if score @s gacha_pick matches 248 unless score @s gacha_shiny matches 1 run givepokemon @s crabominable
execute if score @s gacha_pick matches 249 if score @s gacha_shiny matches 1 run givepokemon @s lycanroc shiny
execute if score @s gacha_pick matches 249 unless score @s gacha_shiny matches 1 run givepokemon @s lycanroc
execute if score @s gacha_pick matches 250 if score @s gacha_shiny matches 1 run givepokemon @s toxapex shiny
execute if score @s gacha_pick matches 250 unless score @s gacha_shiny matches 1 run givepokemon @s toxapex
execute if score @s gacha_pick matches 251 if score @s gacha_shiny matches 1 run givepokemon @s mudsdale shiny
execute if score @s gacha_pick matches 251 unless score @s gacha_shiny matches 1 run givepokemon @s mudsdale
execute if score @s gacha_pick matches 252 if score @s gacha_shiny matches 1 run givepokemon @s araquanid shiny
execute if score @s gacha_pick matches 252 unless score @s gacha_shiny matches 1 run givepokemon @s araquanid
execute if score @s gacha_pick matches 253 if score @s gacha_shiny matches 1 run givepokemon @s lurantis shiny
execute if score @s gacha_pick matches 253 unless score @s gacha_shiny matches 1 run givepokemon @s lurantis
execute if score @s gacha_pick matches 254 if score @s gacha_shiny matches 1 run givepokemon @s shiinotic shiny
execute if score @s gacha_pick matches 254 unless score @s gacha_shiny matches 1 run givepokemon @s shiinotic
execute if score @s gacha_pick matches 255 if score @s gacha_shiny matches 1 run givepokemon @s salazzle shiny
execute if score @s gacha_pick matches 255 unless score @s gacha_shiny matches 1 run givepokemon @s salazzle
execute if score @s gacha_pick matches 256 if score @s gacha_shiny matches 1 run givepokemon @s bewear shiny
execute if score @s gacha_pick matches 256 unless score @s gacha_shiny matches 1 run givepokemon @s bewear
execute if score @s gacha_pick matches 257 if score @s gacha_shiny matches 1 run givepokemon @s tsareena shiny
execute if score @s gacha_pick matches 257 unless score @s gacha_shiny matches 1 run givepokemon @s tsareena
execute if score @s gacha_pick matches 258 if score @s gacha_shiny matches 1 run givepokemon @s comfey shiny
execute if score @s gacha_pick matches 258 unless score @s gacha_shiny matches 1 run givepokemon @s comfey
execute if score @s gacha_pick matches 259 if score @s gacha_shiny matches 1 run givepokemon @s golisopod shiny
execute if score @s gacha_pick matches 259 unless score @s gacha_shiny matches 1 run givepokemon @s golisopod
execute if score @s gacha_pick matches 260 if score @s gacha_shiny matches 1 run givepokemon @s palossand shiny
execute if score @s gacha_pick matches 260 unless score @s gacha_shiny matches 1 run givepokemon @s palossand
execute if score @s gacha_pick matches 261 if score @s gacha_shiny matches 1 run givepokemon @s mimikyu shiny
execute if score @s gacha_pick matches 261 unless score @s gacha_shiny matches 1 run givepokemon @s mimikyu
execute if score @s gacha_pick matches 262 if score @s gacha_shiny matches 1 run givepokemon @s dhelmise shiny
execute if score @s gacha_pick matches 262 unless score @s gacha_shiny matches 1 run givepokemon @s dhelmise
execute if score @s gacha_pick matches 263 if score @s gacha_shiny matches 1 run givepokemon @s greedent shiny
execute if score @s gacha_pick matches 263 unless score @s gacha_shiny matches 1 run givepokemon @s greedent
execute if score @s gacha_pick matches 264 if score @s gacha_shiny matches 1 run givepokemon @s corviknight shiny
execute if score @s gacha_pick matches 264 unless score @s gacha_shiny matches 1 run givepokemon @s corviknight
execute if score @s gacha_pick matches 265 if score @s gacha_shiny matches 1 run givepokemon @s orbeetle shiny
execute if score @s gacha_pick matches 265 unless score @s gacha_shiny matches 1 run givepokemon @s orbeetle
execute if score @s gacha_pick matches 266 if score @s gacha_shiny matches 1 run givepokemon @s thievul shiny
execute if score @s gacha_pick matches 266 unless score @s gacha_shiny matches 1 run givepokemon @s thievul
execute if score @s gacha_pick matches 267 if score @s gacha_shiny matches 1 run givepokemon @s eldegoss shiny
execute if score @s gacha_pick matches 267 unless score @s gacha_shiny matches 1 run givepokemon @s eldegoss
execute if score @s gacha_pick matches 268 if score @s gacha_shiny matches 1 run givepokemon @s dubwool shiny
execute if score @s gacha_pick matches 268 unless score @s gacha_shiny matches 1 run givepokemon @s dubwool
execute if score @s gacha_pick matches 269 if score @s gacha_shiny matches 1 run givepokemon @s drednaw shiny
execute if score @s gacha_pick matches 269 unless score @s gacha_shiny matches 1 run givepokemon @s drednaw
execute if score @s gacha_pick matches 270 if score @s gacha_shiny matches 1 run givepokemon @s boltund shiny
execute if score @s gacha_pick matches 270 unless score @s gacha_shiny matches 1 run givepokemon @s boltund
execute if score @s gacha_pick matches 271 if score @s gacha_shiny matches 1 run givepokemon @s coalossal shiny
execute if score @s gacha_pick matches 271 unless score @s gacha_shiny matches 1 run givepokemon @s coalossal
execute if score @s gacha_pick matches 272 if score @s gacha_shiny matches 1 run givepokemon @s appletun shiny
execute if score @s gacha_pick matches 272 unless score @s gacha_shiny matches 1 run givepokemon @s appletun
execute if score @s gacha_pick matches 273 if score @s gacha_shiny matches 1 run givepokemon @s sandaconda shiny
execute if score @s gacha_pick matches 273 unless score @s gacha_shiny matches 1 run givepokemon @s sandaconda
execute if score @s gacha_pick matches 274 if score @s gacha_shiny matches 1 run givepokemon @s barraskewda shiny
execute if score @s gacha_pick matches 274 unless score @s gacha_shiny matches 1 run givepokemon @s barraskewda
execute if score @s gacha_pick matches 275 if score @s gacha_shiny matches 1 run givepokemon @s toxtricity shiny
execute if score @s gacha_pick matches 275 unless score @s gacha_shiny matches 1 run givepokemon @s toxtricity
execute if score @s gacha_pick matches 276 if score @s gacha_shiny matches 1 run givepokemon @s centiskorch shiny
execute if score @s gacha_pick matches 276 unless score @s gacha_shiny matches 1 run givepokemon @s centiskorch
execute if score @s gacha_pick matches 277 if score @s gacha_shiny matches 1 run givepokemon @s grapploct shiny
execute if score @s gacha_pick matches 277 unless score @s gacha_shiny matches 1 run givepokemon @s grapploct
execute if score @s gacha_pick matches 278 if score @s gacha_shiny matches 1 run givepokemon @s polteageist shiny
execute if score @s gacha_pick matches 278 unless score @s gacha_shiny matches 1 run givepokemon @s polteageist
execute if score @s gacha_pick matches 279 if score @s gacha_shiny matches 1 run givepokemon @s hatterene shiny
execute if score @s gacha_pick matches 279 unless score @s gacha_shiny matches 1 run givepokemon @s hatterene
execute if score @s gacha_pick matches 280 if score @s gacha_shiny matches 1 run givepokemon @s grimmsnarl shiny
execute if score @s gacha_pick matches 280 unless score @s gacha_shiny matches 1 run givepokemon @s grimmsnarl
execute if score @s gacha_pick matches 281 if score @s gacha_shiny matches 1 run givepokemon @s obstagoon shiny
execute if score @s gacha_pick matches 281 unless score @s gacha_shiny matches 1 run givepokemon @s obstagoon
execute if score @s gacha_pick matches 282 if score @s gacha_shiny matches 1 run givepokemon @s perrserker shiny
execute if score @s gacha_pick matches 282 unless score @s gacha_shiny matches 1 run givepokemon @s perrserker
execute if score @s gacha_pick matches 283 if score @s gacha_shiny matches 1 run givepokemon @s runerigus shiny
execute if score @s gacha_pick matches 283 unless score @s gacha_shiny matches 1 run givepokemon @s runerigus
execute if score @s gacha_pick matches 284 if score @s gacha_shiny matches 1 run givepokemon @s alcremie shiny
execute if score @s gacha_pick matches 284 unless score @s gacha_shiny matches 1 run givepokemon @s alcremie
execute if score @s gacha_pick matches 285 if score @s gacha_shiny matches 1 run givepokemon @s frosmoth shiny
execute if score @s gacha_pick matches 285 unless score @s gacha_shiny matches 1 run givepokemon @s frosmoth
execute if score @s gacha_pick matches 286 if score @s gacha_shiny matches 1 run givepokemon @s copperajah shiny
execute if score @s gacha_pick matches 286 unless score @s gacha_shiny matches 1 run givepokemon @s copperajah
execute if score @s gacha_pick matches 287 if score @s gacha_shiny matches 1 run givepokemon @s duraludon shiny
execute if score @s gacha_pick matches 287 unless score @s gacha_shiny matches 1 run givepokemon @s duraludon
execute if score @s gacha_pick matches 288 if score @s gacha_shiny matches 1 run givepokemon @s ursaluna shiny
execute if score @s gacha_pick matches 288 unless score @s gacha_shiny matches 1 run givepokemon @s ursaluna
execute if score @s gacha_pick matches 289 if score @s gacha_shiny matches 1 run givepokemon @s basculegion shiny
execute if score @s gacha_pick matches 289 unless score @s gacha_shiny matches 1 run givepokemon @s basculegion
execute if score @s gacha_pick matches 290 if score @s gacha_shiny matches 1 run givepokemon @s sneasler shiny
execute if score @s gacha_pick matches 290 unless score @s gacha_shiny matches 1 run givepokemon @s sneasler
execute if score @s gacha_pick matches 291 if score @s gacha_shiny matches 1 run givepokemon @s overqwil shiny
execute if score @s gacha_pick matches 291 unless score @s gacha_shiny matches 1 run givepokemon @s overqwil
tellraw @s {"text":"🎁 RARE reward!","color":"white"}
