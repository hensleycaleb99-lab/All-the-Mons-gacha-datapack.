scoreboard players set @s gacha_pick 0
execute store result score @s gacha_pick run random roll 1..69
execute if score @s gacha_pick matches 1 if score @s gacha_shiny matches 1 run givepokemon @s dragonite shiny
execute if score @s gacha_pick matches 1 unless score @s gacha_shiny matches 1 run givepokemon @s dragonite
execute if score @s gacha_pick matches 2 if score @s gacha_shiny matches 1 run givepokemon @s tyranitar shiny
execute if score @s gacha_pick matches 2 unless score @s gacha_shiny matches 1 run givepokemon @s tyranitar
execute if score @s gacha_pick matches 3 if score @s gacha_shiny matches 1 run givepokemon @s sceptile shiny
execute if score @s gacha_pick matches 3 unless score @s gacha_shiny matches 1 run givepokemon @s sceptile
execute if score @s gacha_pick matches 4 if score @s gacha_shiny matches 1 run givepokemon @s blaziken shiny
execute if score @s gacha_pick matches 4 unless score @s gacha_shiny matches 1 run givepokemon @s blaziken
execute if score @s gacha_pick matches 5 if score @s gacha_shiny matches 1 run givepokemon @s swampert shiny
execute if score @s gacha_pick matches 5 unless score @s gacha_shiny matches 1 run givepokemon @s swampert
execute if score @s gacha_pick matches 6 if score @s gacha_shiny matches 1 run givepokemon @s salamence shiny
execute if score @s gacha_pick matches 6 unless score @s gacha_shiny matches 1 run givepokemon @s salamence
execute if score @s gacha_pick matches 7 if score @s gacha_shiny matches 1 run givepokemon @s metagross shiny
execute if score @s gacha_pick matches 7 unless score @s gacha_shiny matches 1 run givepokemon @s metagross
execute if score @s gacha_pick matches 8 if score @s gacha_shiny matches 1 run givepokemon @s infernape shiny
execute if score @s gacha_pick matches 8 unless score @s gacha_shiny matches 1 run givepokemon @s infernape
execute if score @s gacha_pick matches 9 if score @s gacha_shiny matches 1 run givepokemon @s empoleon shiny
execute if score @s gacha_pick matches 9 unless score @s gacha_shiny matches 1 run givepokemon @s empoleon
execute if score @s gacha_pick matches 10 if score @s gacha_shiny matches 1 run givepokemon @s garchomp shiny
execute if score @s gacha_pick matches 10 unless score @s gacha_shiny matches 1 run givepokemon @s garchomp
execute if score @s gacha_pick matches 11 if score @s gacha_shiny matches 1 run givepokemon @s lucario shiny
execute if score @s gacha_pick matches 11 unless score @s gacha_shiny matches 1 run givepokemon @s lucario
execute if score @s gacha_pick matches 12 if score @s gacha_shiny matches 1 run givepokemon @s serperior shiny
execute if score @s gacha_pick matches 12 unless score @s gacha_shiny matches 1 run givepokemon @s serperior
execute if score @s gacha_pick matches 13 if score @s gacha_shiny matches 1 run givepokemon @s emboar shiny
execute if score @s gacha_pick matches 13 unless score @s gacha_shiny matches 1 run givepokemon @s emboar
execute if score @s gacha_pick matches 14 if score @s gacha_shiny matches 1 run givepokemon @s samurott shiny
execute if score @s gacha_pick matches 14 unless score @s gacha_shiny matches 1 run givepokemon @s samurott
execute if score @s gacha_pick matches 15 if score @s gacha_shiny matches 1 run givepokemon @s haxorus shiny
execute if score @s gacha_pick matches 15 unless score @s gacha_shiny matches 1 run givepokemon @s haxorus
execute if score @s gacha_pick matches 16 if score @s gacha_shiny matches 1 run givepokemon @s hydreigon shiny
execute if score @s gacha_pick matches 16 unless score @s gacha_shiny matches 1 run givepokemon @s hydreigon
execute if score @s gacha_pick matches 17 if score @s gacha_shiny matches 1 run givepokemon @s volcarona shiny
execute if score @s gacha_pick matches 17 unless score @s gacha_shiny matches 1 run givepokemon @s volcarona
execute if score @s gacha_pick matches 18 if score @s gacha_shiny matches 1 run givepokemon @s greninja shiny
execute if score @s gacha_pick matches 18 unless score @s gacha_shiny matches 1 run givepokemon @s greninja
execute if score @s gacha_pick matches 19 if score @s gacha_shiny matches 1 run givepokemon @s aegislash shiny
execute if score @s gacha_pick matches 19 unless score @s gacha_shiny matches 1 run givepokemon @s aegislash
execute if score @s gacha_pick matches 20 if score @s gacha_shiny matches 1 run givepokemon @s goodra shiny
execute if score @s gacha_pick matches 20 unless score @s gacha_shiny matches 1 run givepokemon @s goodra
execute if score @s gacha_pick matches 21 if score @s gacha_shiny matches 1 run givepokemon @s decidueye shiny
execute if score @s gacha_pick matches 21 unless score @s gacha_shiny matches 1 run givepokemon @s decidueye
execute if score @s gacha_pick matches 22 if score @s gacha_shiny matches 1 run givepokemon @s incineroar shiny
execute if score @s gacha_pick matches 22 unless score @s gacha_shiny matches 1 run givepokemon @s incineroar
execute if score @s gacha_pick matches 23 if score @s gacha_shiny matches 1 run givepokemon @s primarina shiny
execute if score @s gacha_pick matches 23 unless score @s gacha_shiny matches 1 run givepokemon @s primarina
execute if score @s gacha_pick matches 24 if score @s gacha_shiny matches 1 run givepokemon @s kommo-o shiny
execute if score @s gacha_pick matches 24 unless score @s gacha_shiny matches 1 run givepokemon @s kommo-o
execute if score @s gacha_pick matches 25 if score @s gacha_shiny matches 1 run givepokemon @s nihilego shiny
execute if score @s gacha_pick matches 25 unless score @s gacha_shiny matches 1 run givepokemon @s nihilego
execute if score @s gacha_pick matches 26 if score @s gacha_shiny matches 1 run givepokemon @s buzzwole shiny
execute if score @s gacha_pick matches 26 unless score @s gacha_shiny matches 1 run givepokemon @s buzzwole
execute if score @s gacha_pick matches 27 if score @s gacha_shiny matches 1 run givepokemon @s pheromosa shiny
execute if score @s gacha_pick matches 27 unless score @s gacha_shiny matches 1 run givepokemon @s pheromosa
execute if score @s gacha_pick matches 28 if score @s gacha_shiny matches 1 run givepokemon @s xurkitree shiny
execute if score @s gacha_pick matches 28 unless score @s gacha_shiny matches 1 run givepokemon @s xurkitree
execute if score @s gacha_pick matches 29 if score @s gacha_shiny matches 1 run givepokemon @s celesteela shiny
execute if score @s gacha_pick matches 29 unless score @s gacha_shiny matches 1 run givepokemon @s celesteela
execute if score @s gacha_pick matches 30 if score @s gacha_shiny matches 1 run givepokemon @s kartana shiny
execute if score @s gacha_pick matches 30 unless score @s gacha_shiny matches 1 run givepokemon @s kartana
execute if score @s gacha_pick matches 31 if score @s gacha_shiny matches 1 run givepokemon @s guzzlord shiny
execute if score @s gacha_pick matches 31 unless score @s gacha_shiny matches 1 run givepokemon @s guzzlord
execute if score @s gacha_pick matches 32 if score @s gacha_shiny matches 1 run givepokemon @s poipole shiny
execute if score @s gacha_pick matches 32 unless score @s gacha_shiny matches 1 run givepokemon @s poipole
execute if score @s gacha_pick matches 33 if score @s gacha_shiny matches 1 run givepokemon @s naganadel shiny
execute if score @s gacha_pick matches 33 unless score @s gacha_shiny matches 1 run givepokemon @s naganadel
execute if score @s gacha_pick matches 34 if score @s gacha_shiny matches 1 run givepokemon @s stakataka shiny
execute if score @s gacha_pick matches 34 unless score @s gacha_shiny matches 1 run givepokemon @s stakataka
execute if score @s gacha_pick matches 35 if score @s gacha_shiny matches 1 run givepokemon @s blacephalon shiny
execute if score @s gacha_pick matches 35 unless score @s gacha_shiny matches 1 run givepokemon @s blacephalon
execute if score @s gacha_pick matches 36 if score @s gacha_shiny matches 1 run givepokemon @s rillaboom shiny
execute if score @s gacha_pick matches 36 unless score @s gacha_shiny matches 1 run givepokemon @s rillaboom
execute if score @s gacha_pick matches 37 if score @s gacha_shiny matches 1 run givepokemon @s cinderace shiny
execute if score @s gacha_pick matches 37 unless score @s gacha_shiny matches 1 run givepokemon @s cinderace
execute if score @s gacha_pick matches 38 if score @s gacha_shiny matches 1 run givepokemon @s inteleon shiny
execute if score @s gacha_pick matches 38 unless score @s gacha_shiny matches 1 run givepokemon @s inteleon
execute if score @s gacha_pick matches 39 if score @s gacha_shiny matches 1 run givepokemon @s dragapult shiny
execute if score @s gacha_pick matches 39 unless score @s gacha_shiny matches 1 run givepokemon @s dragapult
execute if score @s gacha_pick matches 40 if score @s gacha_shiny matches 1 run givepokemon @s meowscarada shiny
execute if score @s gacha_pick matches 40 unless score @s gacha_shiny matches 1 run givepokemon @s meowscarada
execute if score @s gacha_pick matches 41 if score @s gacha_shiny matches 1 run givepokemon @s skeledirge shiny
execute if score @s gacha_pick matches 41 unless score @s gacha_shiny matches 1 run givepokemon @s skeledirge
execute if score @s gacha_pick matches 42 if score @s gacha_shiny matches 1 run givepokemon @s quaquaval shiny
execute if score @s gacha_pick matches 42 unless score @s gacha_shiny matches 1 run givepokemon @s quaquaval
execute if score @s gacha_pick matches 43 if score @s gacha_shiny matches 1 run givepokemon @s armarouge shiny
execute if score @s gacha_pick matches 43 unless score @s gacha_shiny matches 1 run givepokemon @s armarouge
execute if score @s gacha_pick matches 44 if score @s gacha_shiny matches 1 run givepokemon @s ceruledge shiny
execute if score @s gacha_pick matches 44 unless score @s gacha_shiny matches 1 run givepokemon @s ceruledge
execute if score @s gacha_pick matches 45 if score @s gacha_shiny matches 1 run givepokemon @s palafin shiny
execute if score @s gacha_pick matches 45 unless score @s gacha_shiny matches 1 run givepokemon @s palafin
execute if score @s gacha_pick matches 46 if score @s gacha_shiny matches 1 run givepokemon @s annihilape shiny
execute if score @s gacha_pick matches 46 unless score @s gacha_shiny matches 1 run givepokemon @s annihilape
execute if score @s gacha_pick matches 47 if score @s gacha_shiny matches 1 run givepokemon @s kingambit shiny
execute if score @s gacha_pick matches 47 unless score @s gacha_shiny matches 1 run givepokemon @s kingambit
execute if score @s gacha_pick matches 48 if score @s gacha_shiny matches 1 run givepokemon @s greattusk shiny
execute if score @s gacha_pick matches 48 unless score @s gacha_shiny matches 1 run givepokemon @s greattusk
execute if score @s gacha_pick matches 49 if score @s gacha_shiny matches 1 run givepokemon @s screamtail shiny
execute if score @s gacha_pick matches 49 unless score @s gacha_shiny matches 1 run givepokemon @s screamtail
execute if score @s gacha_pick matches 50 if score @s gacha_shiny matches 1 run givepokemon @s brutebonnet shiny
execute if score @s gacha_pick matches 50 unless score @s gacha_shiny matches 1 run givepokemon @s brutebonnet
execute if score @s gacha_pick matches 51 if score @s gacha_shiny matches 1 run givepokemon @s fluttermane shiny
execute if score @s gacha_pick matches 51 unless score @s gacha_shiny matches 1 run givepokemon @s fluttermane
execute if score @s gacha_pick matches 52 if score @s gacha_shiny matches 1 run givepokemon @s slitherwing shiny
execute if score @s gacha_pick matches 52 unless score @s gacha_shiny matches 1 run givepokemon @s slitherwing
execute if score @s gacha_pick matches 53 if score @s gacha_shiny matches 1 run givepokemon @s sandyshocks shiny
execute if score @s gacha_pick matches 53 unless score @s gacha_shiny matches 1 run givepokemon @s sandyshocks
execute if score @s gacha_pick matches 54 if score @s gacha_shiny matches 1 run givepokemon @s irontreads shiny
execute if score @s gacha_pick matches 54 unless score @s gacha_shiny matches 1 run givepokemon @s irontreads
execute if score @s gacha_pick matches 55 if score @s gacha_shiny matches 1 run givepokemon @s ironbundle shiny
execute if score @s gacha_pick matches 55 unless score @s gacha_shiny matches 1 run givepokemon @s ironbundle
execute if score @s gacha_pick matches 56 if score @s gacha_shiny matches 1 run givepokemon @s ironhands shiny
execute if score @s gacha_pick matches 56 unless score @s gacha_shiny matches 1 run givepokemon @s ironhands
execute if score @s gacha_pick matches 57 if score @s gacha_shiny matches 1 run givepokemon @s ironjugulis shiny
execute if score @s gacha_pick matches 57 unless score @s gacha_shiny matches 1 run givepokemon @s ironjugulis
execute if score @s gacha_pick matches 58 if score @s gacha_shiny matches 1 run givepokemon @s ironmoth shiny
execute if score @s gacha_pick matches 58 unless score @s gacha_shiny matches 1 run givepokemon @s ironmoth
execute if score @s gacha_pick matches 59 if score @s gacha_shiny matches 1 run givepokemon @s ironthorns shiny
execute if score @s gacha_pick matches 59 unless score @s gacha_shiny matches 1 run givepokemon @s ironthorns
execute if score @s gacha_pick matches 60 if score @s gacha_shiny matches 1 run givepokemon @s baxcalibur shiny
execute if score @s gacha_pick matches 60 unless score @s gacha_shiny matches 1 run givepokemon @s baxcalibur
execute if score @s gacha_pick matches 61 if score @s gacha_shiny matches 1 run givepokemon @s gholdengo shiny
execute if score @s gacha_pick matches 61 unless score @s gacha_shiny matches 1 run givepokemon @s gholdengo
execute if score @s gacha_pick matches 62 if score @s gacha_shiny matches 1 run givepokemon @s roaringmoon shiny
execute if score @s gacha_pick matches 62 unless score @s gacha_shiny matches 1 run givepokemon @s roaringmoon
execute if score @s gacha_pick matches 63 if score @s gacha_shiny matches 1 run givepokemon @s ironvaliant shiny
execute if score @s gacha_pick matches 63 unless score @s gacha_shiny matches 1 run givepokemon @s ironvaliant
execute if score @s gacha_pick matches 64 if score @s gacha_shiny matches 1 run givepokemon @s walkingwake shiny
execute if score @s gacha_pick matches 64 unless score @s gacha_shiny matches 1 run givepokemon @s walkingwake
execute if score @s gacha_pick matches 65 if score @s gacha_shiny matches 1 run givepokemon @s ironleaves shiny
execute if score @s gacha_pick matches 65 unless score @s gacha_shiny matches 1 run givepokemon @s ironleaves
execute if score @s gacha_pick matches 66 if score @s gacha_shiny matches 1 run givepokemon @s gougingfire shiny
execute if score @s gacha_pick matches 66 unless score @s gacha_shiny matches 1 run givepokemon @s gougingfire
execute if score @s gacha_pick matches 67 if score @s gacha_shiny matches 1 run givepokemon @s ragingbolt shiny
execute if score @s gacha_pick matches 67 unless score @s gacha_shiny matches 1 run givepokemon @s ragingbolt
execute if score @s gacha_pick matches 68 if score @s gacha_shiny matches 1 run givepokemon @s ironboulder shiny
execute if score @s gacha_pick matches 68 unless score @s gacha_shiny matches 1 run givepokemon @s ironboulder
execute if score @s gacha_pick matches 69 if score @s gacha_shiny matches 1 run givepokemon @s ironcrown shiny
execute if score @s gacha_pick matches 69 unless score @s gacha_shiny matches 1 run givepokemon @s ironcrown
tellraw @s {"text":"🎁 ULTRA reward!","color":"white"}
