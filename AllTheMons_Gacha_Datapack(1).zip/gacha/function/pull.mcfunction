advancement revoke @s only gacha:pull
clear @s minecraft:paper[minecraft:custom_data={gacha_ticket:1b}] 1
scoreboard players add @s gacha_pity 1
scoreboard players set @s gacha_shiny 0
execute store result score @s gacha_roll run random roll 1..100
execute if score @s gacha_pity matches 100.. run scoreboard players set @s gacha_rarity 5
execute if score @s gacha_pity matches 50..99 run scoreboard players set @s gacha_rarity 4
execute if score @s gacha_pity matches 10..49 run scoreboard players set @s gacha_rarity 3
execute if score @s gacha_pity matches 1..9 if score @s gacha_roll matches 1..60 run scoreboard players set @s gacha_rarity 1
execute if score @s gacha_pity matches 1..9 if score @s gacha_roll matches 61..85 run scoreboard players set @s gacha_rarity 2
execute if score @s gacha_pity matches 1..9 if score @s gacha_roll matches 86..95 run scoreboard players set @s gacha_rarity 3
execute if score @s gacha_pity matches 1..9 if score @s gacha_roll matches 96..99 run scoreboard players set @s gacha_rarity 4
execute if score @s gacha_pity matches 1..9 if score @s gacha_roll matches 100 run scoreboard players set @s gacha_rarity 5
execute store result score @s gacha_shiny run random roll 1..100
execute if score @s gacha_shiny matches 1 run function gacha:ui/shiny_notice
execute if score @s gacha_rarity matches 1 run function gacha:reward/common
execute if score @s gacha_rarity matches 2 run function gacha:reward/uncommon
execute if score @s gacha_rarity matches 3 run function gacha:reward/rare
execute if score @s gacha_rarity matches 4 run function gacha:reward/ultra
execute if score @s gacha_rarity matches 5 run function gacha:reward/legendary
execute if score @s gacha_rarity matches 5 run scoreboard players set @s gacha_pity 0
