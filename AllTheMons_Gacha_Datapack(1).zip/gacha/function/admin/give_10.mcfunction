give @s minecraft:paper[minecraft:custom_name={"text":"Gacha Ticket","color":"gold","bold":true},minecraft:custom_data={gacha_ticket:1b}] 10
tellraw @s {"text":"Gave 10 Gacha Tickets.","color":"green"}
