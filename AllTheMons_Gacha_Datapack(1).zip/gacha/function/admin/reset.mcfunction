scoreboard players set @s gacha_pity 0
scoreboard players set @s gacha_roll 0
scoreboard players set @s gacha_pick 0
scoreboard players set @s gacha_shiny 0
scoreboard players set @s gacha_rarity 0
tellraw @s {"text":"Your gacha pity counter was reset.","color":"yellow"}
