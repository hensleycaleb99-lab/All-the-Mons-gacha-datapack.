function gacha:admin/give_10
tellraw @s {"text":"Use the tickets on a Lodestone to test the gacha.","color":"yellow"}
