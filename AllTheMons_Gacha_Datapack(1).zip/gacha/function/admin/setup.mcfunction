scoreboard players set @s gacha_pity 0
give @s minecraft:lodestone
tellraw @s {"text":"Gacha machine setup ready. Place the Lodestone and use Gacha Tickets on it.","color":"green"}
