scoreboard objectives add gacha_pity dummy
scoreboard objectives add gacha_roll dummy
scoreboard objectives add gacha_pick dummy
scoreboard objectives add gacha_shiny dummy
scoreboard objectives add gacha_rarity dummy
